package com.meetmate.app;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Sends bug reports, fix suggestions, support requests and safety reports to the
 * developer, so the user never has to open an email app.
 *
 * Route 1, when {@link BuildConfig#FORMSPREE_FORM_ID} is set (meetmate.formspreeId in
 * local.properties): a Formspree form that forwards to the team inbox.
 * Route 2, otherwise: the MeetMate events server's /reports endpoint, which saves the
 * report and emails it using mail settings kept on the server.
 */
final class FeedbackSender {
    interface Callback {
        void done(boolean success, String error);
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private FeedbackSender() {}

    /**
     * Sends asynchronously; the callback runs on the main thread.
     *
     * @param eventsServer normalized events server address, or "" when not connected
     * @param kind one of "bug", "fix", "support" or "safety"
     */
    static void send(String eventsServer, String kind, String subject, String message,
                     Callback callback) {
        boolean formspree = !BuildConfig.FORMSPREE_FORM_ID.isEmpty();
        if (!formspree && (eventsServer == null || eventsServer.isEmpty())) {
            callback.done(false, "Connect to the events server in Settings to send this. "
                    + "Your text is saved.");
            return;
        }
        new Thread(() -> {
            String error;
            try {
                JSONObject payload = new JSONObject();
                String url;
                if (formspree) {
                    url = "https://formspree.io/f/" + BuildConfig.FORMSPREE_FORM_ID;
                    payload.put("_subject", subject);
                    payload.put("subject", subject);
                    payload.put("message", message);
                } else {
                    url = eventsServer + "/reports";
                    payload.put("kind", kind);
                    payload.put("message", message);
                    payload.put("app_version", BuildConfig.VERSION_NAME);
                }
                error = post(url, payload);
            } catch (JSONException e) {
                error = "The message couldn’t be prepared. Your text is saved.";
            }
            String result = error;
            MAIN.post(() -> callback.done(result == null, result));
        }, "feedback-sender").start();
    }

    /** Returns null on success, or a user-facing error message. */
    private static String post(String address, JSONObject payload) {
        HttpURLConnection connection = null;
        try {
            byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.setInstanceFollowRedirects(false);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(body);
            }
            int status = connection.getResponseCode();
            if (status >= 200 && status < 300) return null;
            if (status == 429) {
                return "Too many reports were sent just now. Your text is saved; try again in "
                        + "a few minutes.";
            }
            return "The message couldn’t be sent (error " + status + "). Your text is saved.";
        } catch (IOException e) {
            return "Can’t reach the server. Your text is saved; try again in a moment.";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
