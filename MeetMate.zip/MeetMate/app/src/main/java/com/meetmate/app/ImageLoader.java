package com.meetmate.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Loads event photos from https links into ImageViews. Photos are downscaled to the size
 * they are shown at, kept in memory while the app runs, and saved in the app's cache folder
 * so they show offline and aren't downloaded again.
 */
final class ImageLoader {
    private static final int MAX_DOWNLOAD_BYTES = 8_000_000;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService IO = Executors.newFixedThreadPool(3);
    private static final LruCache<String, Bitmap> MEMORY =
            new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 8)) {
                @Override
                protected int sizeOf(String key, Bitmap bitmap) {
                    return bitmap.getAllocationByteCount();
                }
            };

    private ImageLoader() {}

    /** Shows the photo at url in view, decoded to about targetWidth pixels wide. */
    static void load(Context context, ImageView view, String url, int targetWidth) {
        if (url == null || !url.startsWith("https://")) return;
        String key = url + "@" + targetWidth;
        view.setTag(key);
        Bitmap cached = MEMORY.get(key);
        if (cached != null) {
            view.setImageBitmap(cached);
            return;
        }
        File cacheDir = new File(context.getCacheDir(), "event-photos");
        IO.execute(() -> {
            Bitmap bitmap = null;
            try {
                bitmap = decode(readPhoto(cacheDir, url), targetWidth);
            } catch (IOException | RuntimeException | OutOfMemoryError ignored) {
                // No photo: the coloured cover stays.
            }
            if (bitmap == null) return;
            MEMORY.put(key, bitmap);
            Bitmap finalBitmap = bitmap;
            MAIN.post(() -> {
                if (key.equals(view.getTag())) {
                    view.setAlpha(0f);
                    view.setImageBitmap(finalBitmap);
                    view.animate().alpha(1f).setDuration(180).start();
                }
            });
        });
    }

    private static byte[] readPhoto(File cacheDir, String url) throws IOException {
        File file = new File(cacheDir, sha1(url));
        if (file.isFile() && file.length() > 0) {
            return readAll(new java.io.FileInputStream(file));
        }
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        try {
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(15000);
            connection.setRequestProperty("User-Agent", "MeetMate/1.0");
            if (connection.getResponseCode() != 200) throw new IOException("HTTP " + connection.getResponseCode());
            byte[] bytes = readAll(connection.getInputStream());
            if (cacheDir.isDirectory() || cacheDir.mkdirs()) {
                File temp = new File(cacheDir, file.getName() + ".tmp");
                try (FileOutputStream out = new FileOutputStream(temp)) {
                    out.write(bytes);
                }
                if (!temp.renameTo(file)) temp.delete();
            }
            return bytes;
        } finally {
            connection.disconnect();
        }
    }

    private static Bitmap decode(byte[] bytes, int targetWidth) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
        // Shrink by width for sharpness, and also until neither side exceeds 2048 px and the
        // whole photo is at most about 4 megapixels, so odd shapes can't exhaust memory.
        int sample = 1;
        while (bounds.outWidth / (sample * 2) >= targetWidth) sample *= 2;
        while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048
                || (long) (bounds.outWidth / sample) * (bounds.outHeight / sample) > 4_000_000L) {
            sample *= 2;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
    }

    private static byte[] readAll(InputStream input) throws IOException {
        try (InputStream in = input) {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[16384];
            int read;
            while ((read = in.read(chunk)) != -1) {
                if (buffer.size() + read > MAX_DOWNLOAD_BYTES) throw new IOException("Photo too large");
                buffer.write(chunk, 0, read);
            }
            return buffer.toByteArray();
        }
    }

    private static String sha1(String text) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-1").digest(text.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : digest) hex.append(String.format("%02x", b));
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            return Integer.toHexString(text.hashCode());
        }
    }
}
