package com.meetmate.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.TextUtils;
import android.text.InputFilter;
import android.text.InputType;
import android.view.inputmethod.EditorInfo;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    // Colours that are the same in light and dark mode.
    private static final int ACCENT = Color.parseColor("#EE4444");      // buttons, others' bubbles
    private static final int OWN_BUBBLE = Color.parseColor("#BB3030");  // your chat bubbles
    private static final int BUBBLE_TEXT = Color.parseColor("#EEEEEE"); // text on all chat bubbles
    private static final int NAV_ICON = Color.parseColor("#EECC66");    // bottom-bar icons and labels
    private static final int NAV_BAR = Color.parseColor("#333388");     // bottom bar
    /** Text and icons on red buttons; dark in both modes for contrast on red. */
    private static final int ON_RED = Color.parseColor("#000033");

    // Colours that change with dark mode; set by applyPalette().
    private int TEXT, INK, MUTED;   // all text
    private int ICON;               // icons and emojis
    private int PAPER;              // page background
    private int CARD, PALE;         // event boxes and other cards
    private int FIELD;              // text boxes
    private int TILE;               // squares behind avatar emojis
    private int LINE;               // outlines
    private boolean darkMode;
    /** Unicode variation selector: draw the preceding symbol as tintable text, not a colour emoji. */
    private static final String TEXT_STYLE = "\uFE0E";
    /** Height of single-line inputs, matching the chat message box. */
    private static final int INPUT_HEIGHT = 46;
    /** Floating bottom bar size and its gap from the screen edges, in dp. */
    private static final int NAV_HEIGHT = 64;
    private static final int NAV_MARGIN = 12;
    private static final String[] INTERESTS = {
            "Theatre", "Live music", "Art", "Books", "Foodie", "Outdoors", "Fitness",
            "Movies", "Dancing", "Coffee", "Gaming"
    };

    /** Timișoara events: live from the events server, the last list saved, or the copy in the app. */
    private List<Event> events = new ArrayList<>();
    private String eventsSource = "bundled";   // "server", "saved" or "bundled"
    private long eventsUpdatedAt;
    private boolean eventsRefreshing;
    /** Sample people, used for matching only while no events server is connected. */
    private final List<LocalPerson> people = Arrays.asList(
            new LocalPerson("Ioana", "🎭", "Theatre", "Books", "Coffee", "Art"),
            new LocalPerson("Mihai", "🎸", "Live music", "Theatre", "Gaming", "Movies"),
            new LocalPerson("Elena", "🎨", "Art", "Live music", "Foodie", "Books"),
            new LocalPerson("Andrei", "📷", "Outdoors", "Art", "Coffee", "Movies"),
            new LocalPerson("Sara", "✨", "Dancing", "Theatre", "Live music", "Fitness")
    );
    private final Set<String> joinedEvents = new LinkedHashSet<>();
    private final Map<String, List<EventsApi.Person>> attendeesByEvent = new HashMap<>();
    private final Set<String> attendeeRequests = new HashSet<>();
    private String userId;
    private String eventsServer = "";
    private boolean profileDirty;
    private String openEventId;
    private String eventReturnTab = "Explore";
    private boolean matchesFromServer;
    /** Fixed top bar with the screen title; rebuilt by each screen through setAppBar(). */
    private LinearLayout appBar;
    /** What the back button and back gesture do on the current screen; null = go to Explore. */
    private Runnable backAction;
    /** True when the bottom tab bar is replaced (open chat, event page). */
    private boolean navHidden;
    /** When set, settings and action rows are added into this grouped card. */
    private LinearLayout rowGroup;
    private boolean matchLoading;
    private final List<LocalChat> chats = new ArrayList<>();
    private final Set<String> selectedInterests = new LinkedHashSet<>();
    private SharedPreferences preferences;
    private SharedPreferences chatPreferences;
    private SharedPreferences draftPreferences;
    private LinearLayout chatMessagesContainer;
    private LinearLayout page;
    private LinearLayout navigation;
    private ScrollView contentScroll;
    private String lastRenderedTab;
    private boolean lastRenderWasChat;
    private String currentTab = "Explore";
    private String userName = "Jamie";
    private String userAge = "26";
    private String userContact = "jamie@email.com";
    private String selectedEventId;
    private int profileVersion;
    private int groupSize = 3;
    private List<LocalPerson> currentMatches = new ArrayList<>();
    private int matchOffset = 0;
    private String selectedCategory = "";
    private String eventSearchQuery = "";
    private boolean matchReady = false;
    private LocalChat openChat;
    private LocalChat feedbackChat;
    private LocalChat safetyReturnChat;
    private String safetyReturnTab = "Settings";
    private String bugFixTopic = "Bug report";
    private boolean notificationsEnabled = true;
    private boolean locationEnabled = true;
    /** False until the person creates their account on the first launch. */
    private boolean signedUp;
    /** Screen to return to from Profile, when it was opened from Settings. */
    private String profileReturnTab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setDecorFitsSystemWindows(false);
        getWindow().getDecorView().setForceDarkAllowed(false);
        preferences = getSharedPreferences("meetmate_profile", MODE_PRIVATE);
        chatPreferences = getSharedPreferences("meetmate_chat_history", MODE_PRIVATE);
        draftPreferences = getSharedPreferences("meetmate_drafts", MODE_PRIVATE);
        // People who already saved a profile in an earlier version count as signed up.
        signedUp = preferences.getBoolean("signed_up", false);
        userName = preferences.getString("name", userName);
        userAge = preferences.getString("age", userAge);
        userContact = preferences.getString("contact", userContact);
        notificationsEnabled = preferences.getBoolean("notifications", notificationsEnabled);
        locationEnabled = preferences.getBoolean("location", locationEnabled);
        applyPalette(preferences.getBoolean("dark_mode", systemIsDark()));
        selectedInterests.addAll(preferences.getStringSet("interests",
                new LinkedHashSet<>(Arrays.asList("Live music", "Coffee", "Foodie", "Outdoors"))));
        if (selectedInterests.isEmpty()) {
            selectedInterests.addAll(Arrays.asList("Live music", "Coffee", "Foodie", "Outdoors"));
        }
        userId = preferences.getString("user_id", null);
        if (userId == null) {
            userId = "mm-" + UUID.randomUUID().toString().replace("-", "");
            preferences.edit().putString("user_id", userId).apply();
        }
        try {
            JSONArray joinedList = new JSONArray(preferences.getString("joined_events_list", "[]"));
            for (int i = 0; i < joinedList.length(); i++) joinedEvents.add(joinedList.optString(i));
        } catch (JSONException ignored) {
            // Start with no joined events.
        }
        joinedEvents.remove("");
        if (joinedEvents.isEmpty()) {
            joinedEvents.addAll(preferences.getStringSet("joined_events", new LinkedHashSet<String>()));
        }
        profileDirty = preferences.getBoolean("profile_dirty", false);
        String server = EventsApi.normalizeServer(
                preferences.getString("events_server", BuildConfig.EVENTS_SERVER_URL));
        eventsServer = server == null ? "" : server;
        loadChats();
        loadSavedEvents();
        refreshEvents(false);
        getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        render();
    }

    /** Rotation and system dark-mode changes redraw the screen instead of restarting it. */
    @Override
    public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (!preferences.contains("dark_mode")) applyPalette(systemIsDark());
        render();
    }

    /** Back gesture and back button: step back through screens like a native app. */
    private void handleBack() {
        if (openChat != null) {
            openChat = null;
            chatMessagesContainer = null;
            currentTab = "Chats";
            render();
        } else if (backAction != null) {
            backAction.run();
        } else if (!currentTab.equals("Explore")) {
            currentTab = "Explore";
            render();
        } else {
            finish();
        }
    }

    private void loadChats() {
        String saved = chatPreferences.getString("chats", null);
        boolean migratingLegacyChats = false;
        if (saved == null) {
            saved = preferences.getString("chats", null);
            migratingLegacyChats = saved != null;
        }
        if (saved == null) return;
        List<LocalChat> loadedChats = new ArrayList<>();
        try {
            JSONArray savedChats = new JSONArray(saved);
            for (int i = 0; i < savedChats.length(); i++) {
                JSONObject savedChat = savedChats.optJSONObject(i);
                // Skip a damaged chat instead of losing all of them.
                if (savedChat == null || !savedChat.has("id") || !savedChat.has("eventName")) continue;
                if (!savedChat.has("members")) savedChat.put("members", new JSONArray());
                if (!savedChat.has("messages")) savedChat.put("messages", new JSONArray());
                JSONArray savedMembers = savedChat.getJSONArray("members");
                List<String> members = new ArrayList<>();
                for (int j = 0; j < savedMembers.length(); j++) {
                    members.add(savedMembers.getString(j));
                }
                LocalChat chat = new LocalChat(
                        savedChat.getString("id"),
                        savedChat.optString("eventId", ""),
                        savedChat.getString("eventName"),
                        members);
                chat.hangoutCompleted = savedChat.optBoolean("hangoutCompleted", false);
                JSONObject savedRatings = savedChat.optJSONObject("ratings");
                if (savedRatings != null) {
                    Iterator<String> ratingNames = savedRatings.keys();
                    while (ratingNames.hasNext()) {
                        String member = ratingNames.next();
                        int rating = savedRatings.optInt(member, 0);
                        if (members.contains(member) && rating >= 1 && rating <= 5) {
                            chat.ratings.put(member, rating);
                        }
                    }
                }
                JSONArray savedMessages = savedChat.getJSONArray("messages");
                for (int j = 0; j < savedMessages.length(); j++) {
                    JSONObject savedMessage = savedMessages.getJSONObject(j);
                    chat.messages.add(new LocalMessage(
                            savedMessage.getString("senderName"),
                            savedMessage.getString("text"),
                            savedMessage.getBoolean("own")));
                }
                loadedChats.add(chat);
            }
            chats.addAll(loadedChats);
            if (migratingLegacyChats) {
                chatPreferences.edit().putString("chats", saved).apply();
                preferences.edit().remove("chats").apply();
            }
        } catch (JSONException error) {
            Toast.makeText(this, "Saved chats couldn’t be loaded.", Toast.LENGTH_LONG).show();
        }
    }

    private void persistChats() {
        JSONArray savedChats = new JSONArray();
        try {
            for (LocalChat chat : chats) {
                JSONObject savedChat = new JSONObject();
                savedChat.put("id", chat.id);
                savedChat.put("eventId", chat.eventId);
                savedChat.put("eventName", chat.eventName);
                JSONArray savedMembers = new JSONArray();
                for (String member : chat.memberNames) savedMembers.put(member);
                savedChat.put("members", savedMembers);

                JSONArray savedMessages = new JSONArray();
                for (LocalMessage message : chat.messages) {
                    JSONObject savedMessage = new JSONObject();
                    savedMessage.put("senderName", message.senderName);
                    savedMessage.put("text", message.text);
                    savedMessage.put("own", message.own);
                    savedMessages.put(savedMessage);
                }
                savedChat.put("messages", savedMessages);
                savedChat.put("hangoutCompleted", chat.hangoutCompleted);
                JSONObject savedRatings = new JSONObject();
                for (Map.Entry<String, Integer> rating : chat.ratings.entrySet()) {
                    savedRatings.put(rating.getKey(), rating.getValue());
                }
                savedChat.put("ratings", savedRatings);
                savedChats.put(savedChat);
            }
            chatPreferences.edit().putString("chats", savedChats.toString()).apply();
        } catch (JSONException error) {
            Toast.makeText(this, "Chats couldn’t be saved on this phone.", Toast.LENGTH_LONG).show();
        }
    }

    private void setLightSystemBars() {
        WindowInsetsController controller =
                getWindow().getDecorView().getWindowInsetsController();
        if (controller == null) return;
        int appearance = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
        controller.setSystemBarsAppearance(darkMode ? 0 : appearance, appearance);
        getWindow().getDecorView().setBackgroundColor(PAPER);
    }

    private void applyPalette(boolean dark) {
        darkMode = dark;
        if (dark) {
            // Darker or lighter shades of the light-mode colours (same hues), so content stays
            // readable: text on background 12:1, on event boxes 8.9:1, on text boxes 6.5:1.
            // Cards are 1.35:1 against the background so they stand out without glaring.
            TEXT = Color.parseColor("#D6D6FF");   // light shade of #000033
            ICON = Color.parseColor("#D6D6FF");
            PAPER = Color.parseColor("#1C1C1C");  // dark shade of #EEEEEE
            CARD = Color.parseColor("#333333");   // neutral gray, clearly lighter than the background
            FIELD = Color.parseColor("#534728");  // dark shade of #F0DDAA
            TILE = Color.parseColor("#4A4A4A");   // avatar squares, lighter than the cards they sit on
            LINE = Color.parseColor("#4A4A4A");   // neutral outline
        } else {
            TEXT = Color.parseColor("#000033");
            // #000033 contrasts better than navy #333388 on every light surface.
            ICON = Color.parseColor("#000033");
            PAPER = Color.parseColor("#EEEEEE");
            CARD = Color.parseColor("#EEFFFF");
            FIELD = Color.parseColor("#F0DDAA");
            TILE = Color.WHITE;
            LINE = Color.parseColor("#D6E2E2");
        }
        INK = TEXT;
        MUTED = TEXT;
        PALE = CARD;
    }

    private boolean systemIsDark() {
        int mode = getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return mode == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    private void render() {
        int previousScrollY = contentScroll == null ? 0 : contentScroll.getScrollY();
        boolean wasChat = lastRenderWasChat;
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(PAPER);

        LinearLayout contentFrame = new LinearLayout(this);
        contentFrame.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams contentParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        shell.addView(contentFrame, contentParams);

        backAction = null;
        rowGroup = null;
        navHidden = openChat != null;
        appBar = row();
        appBar.setGravity(Gravity.CENTER_VERTICAL);
        appBar.setPadding(dp(16), 0, dp(12), 0);
        appBar.setBackgroundColor(PAPER);
        if (openChat == null) {
            contentFrame.addView(appBar, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));
        }

        contentScroll = new ScrollView(this);
        contentScroll.setFillViewport(true);
        contentScroll.setVerticalScrollBarEnabled(false);
        // Lift the top bar with a shadow once the page scrolls under it.
        contentScroll.setOnScrollChangeListener((view, x, y, oldX, oldY) ->
                appBar.setElevation(y > dp(2) ? dp(4) : 0));
        contentScroll.setClipToPadding(false);
        // The floating bar's shadow turns off clipping in the parent layers, so the scroll
        // area clips itself; otherwise scrolled content draws under the status bar.
        contentScroll.setOutlineProvider(android.view.ViewOutlineProvider.BOUNDS);
        contentScroll.setClipToOutline(true);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        // Leave room at the bottom so the last card can scroll above the floating bar.
        page.setPadding(dp(20), dp(4), dp(20),
                openChat != null ? dp(28) : dp(NAV_HEIGHT + NAV_MARGIN * 2 + 12));
        contentScroll.addView(page);

        // The page and the floating bottom bar share one layer so content scrolls under the bar.
        FrameLayout stack = new FrameLayout(this);
        stack.setClipChildren(false);
        stack.addView(contentScroll, new FrameLayout.LayoutParams(-1, -1));
        contentFrame.addView(stack, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        navigation = new LinearLayout(this);
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        navigation.setGravity(Gravity.CENTER);
        navigation.setBackground(round(NAV_BAR, NAV_HEIGHT / 2));
        navigation.setPadding(dp(6), dp(6), dp(6), dp(6));
        floatAbove(navigation, 14, NAV_BAR);
        FrameLayout.LayoutParams navParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(NAV_HEIGHT),
                Gravity.BOTTOM);
        navParams.setMargins(dp(NAV_MARGIN + 4), 0, dp(NAV_MARGIN + 4), dp(NAV_MARGIN));
        stack.addView(navigation, navParams);
        if (openChat != null) navigation.setVisibility(View.GONE);
        setContentView(shell);
        setLightSystemBars();
        applySystemBarInsets(shell);

        boolean newScreen = !currentTab.equals(lastRenderedTab) || wasChat != (openChat != null);
        if (!signedUp) {
            navHidden = true;
            navigation.setVisibility(View.GONE);
            buildSignupPage();
            restoreScrollPosition(previousScrollY, wasChat);
            return;
        }
        if (openChat != null) {
            LinearLayout compose = buildChatDetail(openChat);
            contentFrame.addView(compose, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            if (newScreen) animateScreenIn();
            restoreScrollPosition(previousScrollY, wasChat);
            return;
        }
        switch (currentTab) {
            case "Event": buildEventPage(); break;
            case "Match": buildMatchPage(); break;
            case "Chats": buildChatsPage(); break;
            case "Profile": buildProfilePage(); break;
            case "Hangout feedback": buildHangoutFeedbackPage(feedbackChat); break;
            case "Bugs & fixes": buildBugFixPage(); break;
            case "Safety": buildSafetyPage(); break;
            case "Settings": buildSettingsPage(); break;
            default: buildExplorePage(); break;
        }
        addNavigation();
        if (newScreen) animateScreenIn();
        restoreScrollPosition(previousScrollY, wasChat);
    }

    /** Short fade-and-rise when a new screen opens, instead of an instant page swap. */
    private void animateScreenIn() {
        page.setAlpha(0f);
        page.setTranslationY(dp(16));
        page.animate().alpha(1f).translationY(0f).setDuration(220)
                .setInterpolator(new android.view.animation.DecelerateInterpolator(2f)).start();
    }

    /**
     * Fills the fixed top bar. A null title shows the MeetMate wordmark. onBack adds a back
     * button and is also what the back gesture does; actionSymbol adds a round button on the right.
     */
    private void setAppBar(String title, Runnable onBack, String actionSymbol,
                           String actionLabel, Runnable onAction) {
        backAction = onBack;
        appBar.removeAllViews();
        if (onBack != null) {
            View back = roundIconButton("←", "Back", onBack);
            LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(dp(42), dp(42));
            backParams.rightMargin = dp(10);
            appBar.addView(back, backParams);
        }
        if (title == null) {
            LinearLayout brandBox = column();
            TextView brand = label("", 25, INK, true);
            brand.setTypeface(Typeface.SERIF, Typeface.BOLD);
            brand.setLetterSpacing(-0.01f);
            android.text.SpannableString wordmark = new android.text.SpannableString("MeetMate");
            wordmark.setSpan(new android.text.style.ForegroundColorSpan(ACCENT), 4, 8,
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            brand.setText(wordmark);
            brandBox.addView(brand, new LinearLayout.LayoutParams(-2, -2));
            View underline = new View(this);
            underline.setBackground(round(NAV_ICON, 2));
            LinearLayout.LayoutParams underlineParams = new LinearLayout.LayoutParams(dp(32), dp(4));
            underlineParams.leftMargin = dp(2);
            brandBox.addView(underline, underlineParams);
            appBar.addView(brandBox, new LinearLayout.LayoutParams(0, -2, 1f));
        } else {
            TextView heading = label(title, 21, INK, true);
            heading.setTypeface(Typeface.SERIF, Typeface.BOLD);
            heading.setSingleLine(true);
            heading.setEllipsize(TextUtils.TruncateAt.END);
            appBar.addView(heading, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        if (actionSymbol != null && onAction != null) {
            appBar.addView(roundIconButton(actionSymbol, actionLabel, onAction),
                    new LinearLayout.LayoutParams(dp(42), dp(42)));
        }
    }

    private void setAppBar(String title, Runnable onBack) {
        setAppBar(title, onBack, null, null, null);
    }

    private View roundIconButton(String symbol, String description, Runnable onClick) {
        FrameLayout button = new FrameLayout(this);
        button.setBackground(round(CARD, 21));
        button.setContentDescription(description);
        floatAbove(button, 2, ICON);
        pressable(button);
        button.addView(icon(symbol, 18), new FrameLayout.LayoutParams(-1, -1));
        button.setOnClickListener(v -> onClick.run());
        return button;
    }

    /** Round avatar with the user's initial; opens the profile. */
    private View profileButton() {
        FrameLayout button = new FrameLayout(this);
        button.setBackground(round(ACCENT, 21));
        button.setContentDescription("Your profile");
        floatAbove(button, 3, ACCENT);
        pressable(button);
        TextView letter = label(initial(userName), 16, ON_RED, true);
        letter.setGravity(Gravity.CENTER);
        button.addView(letter, new FrameLayout.LayoutParams(-1, -1));
        button.setOnClickListener(v -> {
            currentTab = "Profile";
            render();
        });
        return button;
    }

    /** Replaces the tab bar with one pinned action, for detail screens. */
    private void setBottomAction(View action) {
        navHidden = true;
        navigation.setVisibility(View.GONE);
        LinearLayout bar = column();
        bar.setPadding(dp(18), dp(10), dp(18), dp(14));
        bar.setBackgroundColor(PAPER);
        bar.setElevation(dp(10));
        bar.addView(action, new LinearLayout.LayoutParams(-1, dp(52)));
        ((ViewGroup) navigation.getParent()).addView(bar,
                new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
    }

    private void addSectionHeader(String text, int topMargin) {
        TextView header = label(text, 18, INK, true);
        header.setTypeface(Typeface.SERIF, Typeface.BOLD);
        add(header, topMargin, 10);
    }

    /** Starts a grouped card: following rows share one card, separated by thin lines. */
    private void startGroup() {
        rowGroup = column();
        rowGroup.setBackground(round(CARD, 20));
        rowGroup.setClipToOutline(true);
        floatAbove(rowGroup, 2, ICON);
    }

    private void endGroup() {
        if (rowGroup == null) return;
        LinearLayout group = rowGroup;
        rowGroup = null;
        add(group, 0, 6);
    }

    /** Adds a row to the open group (with a divider and press ripple) or as its own card. */
    private void addRow(LinearLayout row, boolean clickable) {
        if (rowGroup != null) {
            if (rowGroup.getChildCount() > 0) {
                View divider = new View(this);
                divider.setBackgroundColor(LINE);
                LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(-1, 1);
                dividerParams.leftMargin = dp(16);
                rowGroup.addView(divider, dividerParams);
            }
            if (clickable) {
                row.setBackground(new android.graphics.drawable.RippleDrawable(
                        android.content.res.ColorStateList.valueOf(withAlpha(ICON, 0x22)),
                        null, new android.graphics.drawable.ColorDrawable(Color.WHITE)));
            }
            rowGroup.addView(row, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        row.setBackground(round(PALE, 20));
        floatAbove(row, 2, ICON);
        if (clickable) pressable(row);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(9);
        page.addView(row, params);
    }

    private void applySystemBarInsets(View root) {
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            android.graphics.Insets safeInsets = insets.getInsets(
                    android.view.WindowInsets.Type.systemBars()
                            | android.view.WindowInsets.Type.displayCutout());
            // Keep text fields and the chat box above the on-screen keyboard.
            android.graphics.Insets keyboard = insets.getInsets(android.view.WindowInsets.Type.ime());
            boolean keyboardShown = insets.isVisible(android.view.WindowInsets.Type.ime());
            view.setPadding(
                    safeInsets.left,
                    safeInsets.top,
                    safeInsets.right,
                    Math.max(safeInsets.bottom, keyboard.bottom));
            // The floating bar would sit on top of the keyboard and hide the field being typed in.
            if (navigation != null && !navHidden) {
                navigation.setVisibility(keyboardShown ? View.GONE : View.VISIBLE);
            }
            return insets;
        });
        root.requestApplyInsets();
    }

    private void restoreScrollPosition(int scrollY, boolean wasChat) {
        boolean isChat = openChat != null;
        if (currentTab.equals(lastRenderedTab) && isChat == wasChat) {
            // Restore after layout but before the first frame is drawn, so the
            // rebuilt page never flashes at the top.
            ScrollView scroll = contentScroll;
            scroll.getViewTreeObserver().addOnPreDrawListener(
                    new android.view.ViewTreeObserver.OnPreDrawListener() {
                        @Override
                        public boolean onPreDraw() {
                            scroll.getViewTreeObserver().removeOnPreDrawListener(this);
                            scroll.scrollTo(0, scrollY);
                            return true;
                        }
                    });
        }
        lastRenderedTab = currentTab;
        lastRenderWasChat = isChat;
    }

    private void buildExplorePage() {
        setAppBar(null, null, null, null, null);
        LinearLayout.LayoutParams avatarParams = new LinearLayout.LayoutParams(dp(42), dp(42));
        appBar.addView(profileButton(), avatarParams);

        TextView hello = body("Hello, " + userName + "!", 14);
        add(hello, 6, 2);
        add(title("What’s on in Timișoara", 24), 0, 14);

        LinearLayout search = row();
        search.setGravity(Gravity.CENTER_VERTICAL);
        search.setPadding(dp(16), 0, dp(14), 0);
        search.setBackground(round(FIELD, 24));
        TextView searchIcon = icon("⌕", 20);
        search.addView(searchIcon);
        EditText searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextSize(14);
        searchInput.setTextColor(INK);
        searchInput.setHintTextColor(MUTED);
        searchInput.setHint("Search opera, theatre, exhibitions…");
        searchInput.setText(eventSearchQuery);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        hintParams.leftMargin = dp(8);
        search.addView(searchInput, hintParams);
        if (!eventSearchQuery.isEmpty()) {
            TextView clear = icon("✕", 14);
            clear.setContentDescription("Clear search");
            clear.setPadding(dp(8), dp(8), dp(4), dp(8));
            clear.setOnClickListener(v -> {
                eventSearchQuery = "";
                render();
            });
            search.addView(clear);
        }
        searchIcon.setOnClickListener(v -> applyEventSearch(searchInput));
        searchInput.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId != EditorInfo.IME_ACTION_SEARCH) return false;
            applyEventSearch(searchInput);
            return true;
        });
        add(search, 0, 12);

        if (!eventsSource.equals("server")) {
            TextView offline = body(eventsStatusText(), 11);
            offline.setPadding(dp(14), dp(9), dp(14), dp(9));
            offline.setBackground(round(PALE, 14));
            add(offline, 0, 10);
        }

        List<Event> upcoming = upcomingEvents();
        List<String> categories = new ArrayList<>();
        categories.add("");
        for (String category : Event.CATEGORIES) {
            for (Event event : upcoming) {
                if (event.category.equals(category)) {
                    categories.add(category);
                    break;
                }
            }
        }
        if (!categories.contains(selectedCategory)) selectedCategory = "";
        LinearLayout filters = row();
        filters.setPadding(dp(20), dp(4), dp(20), dp(8));
        for (String category : categories) {
            TextView chip = chip(category.isEmpty() ? "For you" : category,
                    selectedCategory.equals(category));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(34));
            params.rightMargin = dp(8);
            filters.addView(chip, params);
            chip.setOnClickListener(v -> {
                selectedCategory = category;
                render();
            });
        }
        addEdgeToEdge(filters, 4);

        List<Event> shown = new ArrayList<>();
        for (Event event : upcoming) {
            if (!selectedCategory.isEmpty() && !event.category.equals(selectedCategory)) continue;
            if (!matchesSearch(event, eventSearchQuery)) continue;
            shown.add(event);
        }
        if (shown.isEmpty()) {
            TextView empty = body(upcoming.isEmpty()
                    ? "No upcoming events are saved on this phone. Connect to the events server "
                    + "in Settings to load the latest Timișoara events."
                    : "No events match that search. Try another name or category.", 13);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(24), dp(18), dp(24));
            empty.setBackground(round(PALE, 16));
            add(empty, 8, 12);
            return;
        }
        int featured = 0;
        boolean browsing = selectedCategory.isEmpty() && eventSearchQuery.isEmpty();
        if (browsing && shown.size() > 4) {
            featured = 5;
            addSectionHeader("Coming up", 6);
            LinearLayout carousel = row();
            carousel.setPadding(dp(20), dp(2), dp(8), dp(14));
            for (int i = 0; i < featured; i++) carousel.addView(eventTile(shown.get(i)));
            addEdgeToEdge(carousel, 4);
            List<Event> concerts = new ArrayList<>();
            for (Event event : shown) {
                if (event.category.equals("Music") && concerts.size() < 8) concerts.add(event);
            }
            if (concerts.size() >= 2) {
                addSectionHeader("Live music & concerts", 6);
                LinearLayout concertRow = row();
                concertRow.setPadding(dp(20), dp(2), dp(8), dp(14));
                for (Event concert : concerts) concertRow.addView(eventTile(concert));
                addEdgeToEdge(concertRow, 4);
            }
            addSectionHeader("More in Timișoara", 6);
        } else {
            addSectionHeader(shown.size() + (shown.size() == 1 ? " event" : " events"), 8);
        }
        java.time.LocalDate lastDay = null;
        for (int i = featured; i < shown.size(); i++) {
            Event event = shown.get(i);
            java.time.LocalDate day = event.start.toLocalDate();
            if (!day.equals(lastDay)) {
                addDayHeading(day);
                lastDay = day;
            }
            addEventRow(event);
        }
        TextView credit = body("Event listings: Visit Timișoara", 10);
        credit.setGravity(Gravity.CENTER);
        add(credit, 8, 4);
    }

    /** "Today", "Tomorrow" or "Tuesday 17 November" above the events of that day. */
    private void addDayHeading(java.time.LocalDate day) {
        java.time.LocalDate today = now().toLocalDate();
        String text = day.equals(today) ? "Today"
                : day.equals(today.plusDays(1)) ? "Tomorrow"
                : day.format(java.time.format.DateTimeFormatter.ofPattern("EEEE d MMMM",
                java.util.Locale.ENGLISH));
        TextView heading = label(text.toUpperCase(java.util.Locale.ROOT), 11, ACCENT, true);
        heading.setLetterSpacing(0.08f);
        add(heading, 8, 8);
    }

    /** A horizontal row that runs to the screen edges, past the page padding. */
    private void addEdgeToEdge(LinearLayout content, int bottomMargin) {
        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setClipToPadding(false);
        scroller.addView(content);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.leftMargin = -dp(20);
        params.rightMargin = -dp(20);
        params.bottomMargin = dp(bottomMargin);
        page.addView(scroller, params);
    }

    /** Large swipeable card for the "Coming up" row. */
    private View eventTile(Event event) {
        LinearLayout tile = column();
        tile.setBackground(round(CARD, 22));
        tile.setPadding(dp(8), dp(8), dp(8), dp(12));
        floatAbove(tile, 3, ICON);
        pressable(tile);
        FrameLayout tileCover = eventCover(event);
        TextView datePill = label(event.when(now()), 10, Color.WHITE, true);
        datePill.setPadding(dp(9), dp(5), dp(9), dp(5));
        datePill.setBackground(round(withAlpha(Color.BLACK, 0x99), 10));
        FrameLayout.LayoutParams pillParams = new FrameLayout.LayoutParams(-2, -2,
                Gravity.BOTTOM | Gravity.LEFT);
        pillParams.setMargins(dp(9), 0, 0, dp(9));
        tileCover.addView(datePill, pillParams);
        tile.addView(tileCover, new LinearLayout.LayoutParams(-1, dp(130)));
        TextView name = title(event.name, 15);
        name.setMaxLines(2);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setPadding(dp(4), dp(10), dp(4), 0);
        tile.addView(name);
        TextView when = body(event.when(now()) + "  ·  " + event.place(), 11);
        when.setSingleLine(true);
        when.setEllipsize(TextUtils.TruncateAt.END);
        when.setPadding(dp(4), dp(4), dp(4), 0);
        tile.addView(when);
        String going = goingText(event);
        if (!going.isEmpty()) {
            TextView goingLabel = label(going, 10, ACCENT, true);
            goingLabel.setPadding(dp(4), dp(6), dp(4), 0);
            tile.addView(goingLabel);
        }
        tile.setOnClickListener(v -> showEvent(event.id, "Explore"));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(250), -2);
        params.rightMargin = dp(12);
        tile.setLayoutParams(params);
        return tile;
    }

    /** Compact list row: coloured date tile, title, time and place. */
    private void addEventRow(Event event) {
        LinearLayout card = row();
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(10), dp(10), dp(12), dp(10));
        card.setBackground(round(CARD, 20));
        floatAbove(card, 2, ICON);
        pressable(card);

        FrameLayout dateTile = new FrameLayout(this);
        dateTile.setBackground(round(event.color(), 14));
        dateTile.setClipToOutline(true);
        if (!event.imageUrl.isEmpty()) {
            android.widget.ImageView photo = new android.widget.ImageView(this);
            photo.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
            dateTile.addView(photo, new FrameLayout.LayoutParams(-1, -1));
            ImageLoader.load(this, photo, event.imageUrl, dp(64) * 2);
        }
        LinearLayout date = column();
        date.setGravity(Gravity.CENTER);
        if (event.imageUrl.isEmpty()) dateTile.addView(date, new FrameLayout.LayoutParams(-1, -1));
        TextView day = label(String.valueOf(event.start.getDayOfMonth()), 20, Color.WHITE, true);
        day.setTypeface(Typeface.SERIF, Typeface.BOLD);
        day.setGravity(Gravity.CENTER);
        date.addView(day);
        TextView month = label(event.start.format(java.time.format.DateTimeFormatter
                .ofPattern("MMM", java.util.Locale.ENGLISH)).toUpperCase(java.util.Locale.ROOT),
                9, Color.WHITE, true);
        month.setLetterSpacing(0.1f);
        month.setGravity(Gravity.CENTER);
        date.addView(month);
        card.addView(dateTile, new LinearLayout.LayoutParams(dp(64), dp(64)));

        LinearLayout text = column();
        TextView kind = label(event.label(), 9, ACCENT, true);
        kind.setLetterSpacing(0.06f);
        text.addView(kind);
        TextView name = label(event.name, 15, INK, true);
        name.setPadding(0, dp(2), 0, 0);
        name.setMaxLines(2);
        name.setEllipsize(TextUtils.TruncateAt.END);
        text.addView(name);
        TextView when = body(event.when(now()) + "  ·  " + event.place(), 11);
        when.setSingleLine(true);
        when.setEllipsize(TextUtils.TruncateAt.END);
        when.setPadding(0, dp(3), 0, 0);
        text.addView(when);
        String going = goingText(event);
        if (!going.isEmpty()) {
            TextView goingLabel = label(going, 10, ACCENT, true);
            goingLabel.setPadding(0, dp(3), 0, 0);
            text.addView(goingLabel);
        }
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, -2, 1f);
        textParams.leftMargin = dp(12);
        textParams.rightMargin = dp(6);
        card.addView(text, textParams);
        card.addView(icon("›", 22));
        card.setOnClickListener(v -> showEvent(event.id, "Explore"));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(10);
        page.addView(card, params);
    }

    private void applyEventSearch(EditText input) {
        eventSearchQuery = input.getText().toString().trim();
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(input.getWindowToken(), 0);
        render();
    }

    private boolean matchesSearch(Event event, String query) {
        if (query.isEmpty()) return true;
        return event.searchText().contains(query.toLowerCase(java.util.Locale.ROOT));
    }

    private void addEventCard(Event event, boolean selectable) {
        LinearLayout card = column();
        card.setBackground(round(CARD, 22));
        floatAbove(card, 4, ICON);
        pressable(card);
        card.setPadding(dp(10), dp(10), dp(10), dp(12));
        card.addView(eventCover(event), new LinearLayout.LayoutParams(-1, dp(132)));

        LinearLayout details = row();
        details.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout text = column();
        TextView eventTitle = title(event.name, 16);
        text.addView(eventTitle);
        TextView when = body(event.when(now()) + "  ·  " + event.place(), 11);
        when.setPadding(0, dp(5), 0, 0);
        text.addView(when);
        details.addView(text, new LinearLayout.LayoutParams(0, -2, 1f));
        String going = goingText(event);
        if (!going.isEmpty()) {
            TextView attendees = label("", 10, ACCENT, true);
            android.text.SpannableString attending =
                    new android.text.SpannableString("●  " + going);
            attending.setSpan(new android.text.style.ForegroundColorSpan(ICON), 0, 1,
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            attendees.setText(attending);
            LinearLayout.LayoutParams goingParams = new LinearLayout.LayoutParams(-2, -2);
            goingParams.leftMargin = dp(8);
            details.addView(attendees, goingParams);
        }
        LinearLayout.LayoutParams detailsParams = new LinearLayout.LayoutParams(-1, -2);
        detailsParams.topMargin = dp(12);
        card.addView(details, detailsParams);

        if (selectable) {
            boolean selected = event.id.equals(selectedEventId);
            TextView selection = label(selected ? "✓  Selected" : "Choose this event",
                    12, selected ? ON_RED : TEXT, true);
            selection.setGravity(Gravity.CENTER);
            selection.setBackground(round(selected ? ACCENT : PAPER, 21));
            if (selected) floatAbove(selection, 5, ACCENT);
            LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(42));
            buttonParams.topMargin = dp(12);
            card.addView(selection, buttonParams);
            card.setOnClickListener(v -> {
                selectedEventId = event.id;
                matchReady = false;
                render();
            });
        } else {
            TextView detailsButton = label("See details  →", 12, ON_RED, true);
            detailsButton.setGravity(Gravity.CENTER);
            detailsButton.setBackground(round(ACCENT, 20));
            floatAbove(detailsButton, 5, ACCENT);
            LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(40));
            buttonParams.topMargin = dp(12);
            card.addView(detailsButton, buttonParams);
            card.setOnClickListener(v -> showEvent(event.id, "Explore"));
        }
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.bottomMargin = dp(14);
        page.addView(card, cardParams);
    }

    /** Coloured poster with the event's number in the list and its category. */
    private FrameLayout eventCover(Event event) {
        FrameLayout cover = new FrameLayout(this);
        cover.setBackground(round(event.color(), 14));
        cover.setClipToOutline(true);
        if (!event.imageUrl.isEmpty()) {
            android.widget.ImageView photo = new android.widget.ImageView(this);
            photo.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
            photo.setContentDescription("Photo for " + event.name);
            cover.addView(photo, new FrameLayout.LayoutParams(-1, -1));
            ImageLoader.load(this, photo, event.imageUrl,
                    getResources().getDisplayMetrics().widthPixels);
            View fade = new View(this);
            fade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{withAlpha(Color.BLACK, 0x55), Color.TRANSPARENT,
                            withAlpha(Color.BLACK, 0x33)}));
            cover.addView(fade, new FrameLayout.LayoutParams(-1, -1));
        }
        int number = Math.max(1, upcomingEvents().indexOf(event) + 1);
        TextView posterNumber = label(String.format(java.util.Locale.ROOT, "%02d", number),
                66, Color.WHITE, true);
        posterNumber.setTypeface(Typeface.SERIF, Typeface.BOLD);
        posterNumber.setAlpha(0.28f);
        posterNumber.setGravity(Gravity.RIGHT | Gravity.BOTTOM);
        FrameLayout.LayoutParams numberParams = new FrameLayout.LayoutParams(-1, -1);
        numberParams.setMargins(0, 0, dp(10), dp(2));
        if (event.imageUrl.isEmpty()) cover.addView(posterNumber, numberParams);
        TextView badge = label(event.label(), 9, INK, true);
        badge.setLetterSpacing(0.04f);
        badge.setPadding(dp(9), dp(6), dp(9), dp(6));
        badge.setBackground(round(CARD, 7));
        FrameLayout.LayoutParams badgeParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        badgeParams.setMargins(dp(9), dp(9), 0, 0);
        cover.addView(badge, badgeParams);
        return cover;
    }

    /** "You’re going", "You + 3 going", "12 going", or "" when nothing useful is known. */
    private String goingText(Event event) {
        boolean joined = joinedEvents.contains(event.id);
        if (!eventsSource.equals("server") || event.attendeeCount < 0) {
            return joined ? "You’re going" : "";
        }
        if (joined) {
            int others = event.attendeeCount - (profileDirty ? 0 : 1);
            return others <= 0 ? "You’re going" : "You + " + others + " going";
        }
        return event.attendeeCount == 0 ? "" : event.attendeeCount + " going";
    }

    private void showEvent(String eventId, String returnTab) {
        // Always show who's going as of now, and refresh the counts in the background.
        attendeesByEvent.remove(eventId);
        refreshEvents(false);
        openEventId = eventId;
        eventReturnTab = returnTab;
        currentTab = "Event";
        render();
    }

    private void buildEventPage() {
        Event event = eventById(openEventId);
        if (event == null) {
            currentTab = "Explore";
            buildExplorePage();
            return;
        }
        Runnable goBack = () -> {
            currentTab = eventReturnTab;
            openEventId = null;
            render();
        };
        appBar.setVisibility(View.GONE);
        backAction = goBack;
        LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(-1, dp(320));
        heroParams.setMargins(-dp(20), -dp(4), -dp(20), dp(16));
        page.addView(eventHero(event, goBack), heroParams);

        boolean joined = joinedEvents.contains(event.id);
        String relativeDay = event.when(now());
        relativeDay = relativeDay.startsWith("Today") ? "Today"
                : relativeDay.startsWith("Tomorrow") ? "Tomorrow" : null;
        startGroup();
        addInfoRow("🗓", event.longWhen(), relativeDay, null);
        String venue = event.hasVenue() ? event.location : "Venue to be confirmed";
        String venueDetail = !event.address.isEmpty() ? event.address
                : event.hasVenue() ? "Timișoara" : "See the event page for the exact place";
        addInfoRow("📍", venue, venueDetail, event.address.isEmpty() ? null : () -> openMap(event));
        if (eventsSource.equals("server") && event.attendeeCount >= 0) {
            String going = goingText(event);
            addInfoRow("👥", going.isEmpty() ? "No one has joined yet" : going,
                    going.isEmpty() ? "Be the first to join" : "on MeetMate", null);
        }
        endGroup();
        if (!event.description.isEmpty()) add(body(event.description, 14), 10, 12);
        List<String> tags = event.readableTags();
        if (!tags.isEmpty()) {
            LinearLayout tagRow = row();
            tagRow.setPadding(0, dp(2), dp(8), dp(8));
            for (int i = 0; i < tags.size() && i < 5; i++) {
                TextView tag = chip(tags.get(i), false);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(30));
                params.rightMargin = dp(7);
                tagRow.addView(tag, params);
            }
            HorizontalScrollView tagScroll = new HorizontalScrollView(this);
            tagScroll.setHorizontalScrollBarEnabled(false);
            tagScroll.addView(tagRow);
            add(tagScroll, 0, 10);
        }

        Button join = primaryButton(joined ? "Find your crew  →" : "Join this event");
        setBottomAction(join);
        join.setOnClickListener(v -> {
            if (joinedEvents.contains(event.id)) {
                selectedEventId = event.id;
                matchReady = false;
                currentMatches.clear();
                currentTab = "Match";
                render();
            } else {
                toggleJoin(event);
            }
        });
        if (joined) {
            TextView leave = label("Leave this event", 12, MUTED, true);
            leave.setGravity(Gravity.CENTER);
            leave.setPadding(0, dp(8), 0, dp(8));
            leave.setOnClickListener(v -> toggleJoin(event));
            add(leave, 0, 4);
        }
        TextView privacy = body("When you join, people going to this event can see your name and "
                + "interests. Your age, email and phone number are never shared.", 11);
        privacy.setGravity(Gravity.CENTER);
        add(privacy, 4, 18);

        add(sectionTitle("PLAN YOUR VISIT"), 0, 10);
        startGroup();
        if (isWebLink(event.ticketUrl)) {
            addActionRow("Tickets & registration", linkHost(event.ticketUrl), "↗",
                    () -> openLink(event.ticketUrl));
        }
        if (isWebLink(event.sourceUrl)) {
            addActionRow("Event page", linkHost(event.sourceUrl), "↗", () -> openLink(event.sourceUrl));
        }
        if (!event.address.isEmpty()) {
            addActionRow("Directions", event.address, "↗", () -> openMap(event));
        }
        addActionRow("Share this event", "Send the details to a friend", "↗", () -> shareEvent(event));
        endGroup();

        add(sectionTitle("WHO’S GOING"), 18, 10);
        if (eventsServer.isEmpty()) {
            add(body("Connect to the events server in Settings to see who else is going.", 12), 0, 8);
        } else if (!attendeesByEvent.containsKey(event.id)) {
            add(body("Loading…", 12), 0, 8);
            loadAttendees(event.id);
        } else {
            List<EventsApi.Person> going = attendeesByEvent.get(event.id);
            if (going == null) {
                TextView retry = label("Couldn’t load who’s going. Tap to try again.", 12, ACCENT, true);
                retry.setOnClickListener(v -> {
                    attendeesByEvent.remove(event.id);
                    render();
                });
                add(retry, 0, 8);
            } else {
                int shown = 0;
                for (EventsApi.Person person : going) {
                    if (person.id.equals(userId)) continue;
                    addPersonCard(new LocalPerson(person.name, initial(person.name), person.interests));
                    shown++;
                }
                if (shown == 0) {
                    add(body(joined ? "No one else has joined yet. Share the event with friends!"
                            : "No one has joined yet. Be the first!", 12), 0, 8);
                }
            }
        }
        TextView credit = body("Listing and photo from Visit Timișoara. Check the time with the "
                + "organiser before you go.", 10);
        credit.setGravity(Gravity.CENTER);
        add(credit, 18, 4);
    }

    /** Full-width photo with back and share buttons on top and the title over the photo. */
    private FrameLayout eventHero(Event event, Runnable goBack) {
        FrameLayout hero = new FrameLayout(this);
        hero.setBackgroundColor(event.color());
        if (!event.imageUrl.isEmpty()) {
            android.widget.ImageView photo = new android.widget.ImageView(this);
            photo.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
            photo.setContentDescription("Photo for " + event.name);
            hero.addView(photo, new FrameLayout.LayoutParams(-1, -1));
            ImageLoader.load(this, photo, event.imageUrl,
                    getResources().getDisplayMetrics().widthPixels);
        }
        View fade = new View(this);
        fade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{withAlpha(Color.BLACK, 0x66), Color.TRANSPARENT,
                        withAlpha(Color.BLACK, 0xAA), withAlpha(Color.BLACK, 0xEE)}));
        hero.addView(fade, new FrameLayout.LayoutParams(-1, -1));
        // Extra shade behind the title so it stays readable over posters with text.
        View captionShade = new View(this);
        captionShade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.TRANSPARENT, withAlpha(Color.BLACK, 0xCC)}));
        hero.addView(captionShade, new FrameLayout.LayoutParams(-1, dp(190), Gravity.BOTTOM));

        FrameLayout.LayoutParams backParams = new FrameLayout.LayoutParams(dp(42), dp(42),
                Gravity.TOP | Gravity.LEFT);
        backParams.setMargins(dp(16), dp(12), 0, 0);
        hero.addView(roundIconButton("←", "Back", goBack), backParams);
        FrameLayout.LayoutParams shareParams = new FrameLayout.LayoutParams(dp(42), dp(42),
                Gravity.TOP | Gravity.RIGHT);
        shareParams.setMargins(0, dp(12), dp(16), 0);
        hero.addView(roundIconButton("↗", "Share event", () -> shareEvent(event)), shareParams);

        LinearLayout caption = column();
        caption.setPadding(dp(20), 0, dp(20), dp(18));
        TextView badge = label(event.label(), 9, INK, true);
        badge.setLetterSpacing(0.04f);
        badge.setPadding(dp(9), dp(5), dp(9), dp(5));
        badge.setBackground(round(CARD, 7));
        caption.addView(badge, new LinearLayout.LayoutParams(-2, -2));
        TextView heading = title(event.name, 24);
        heading.setTextColor(Color.WHITE);
        heading.setMaxLines(3);
        heading.setEllipsize(TextUtils.TruncateAt.END);
        heading.setShadowLayer(dp(6), 0, dp(1), withAlpha(Color.BLACK, 0x88));
        heading.setPadding(0, dp(10), 0, 0);
        caption.addView(heading);
        TextView when = label(event.when(now()) + "  ·  " + event.place(), 13, Color.WHITE, true);
        when.setAlpha(0.9f);
        when.setPadding(0, dp(6), 0, 0);
        caption.addView(when);
        hero.addView(caption, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        return hero;
    }

    private void addInfoRow(String symbol, String main, String detail, Runnable onClick) {
        LinearLayout info = row();
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(14), dp(12), dp(14), dp(12));
        info.addView(icon(symbol, 18), new LinearLayout.LayoutParams(dp(28), -2));
        LinearLayout text = column();
        text.addView(label(main, 15, INK, true));
        if (detail != null && !detail.isEmpty()) {
            TextView sub = body(detail, 12);
            sub.setPadding(0, dp(3), 0, 0);
            text.addView(sub);
        }
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, -2, 1f);
        textParams.leftMargin = dp(10);
        info.addView(text, textParams);
        if (onClick != null) {
            info.addView(icon("↗", 16));
            info.setOnClickListener(v -> onClick.run());
        }
        addRow(info, onClick != null);
    }

    private void loadAttendees(String eventId) {
        if (eventsServer.isEmpty() || attendeeRequests.contains(eventId)
                || attendeesByEvent.containsKey(eventId)) return;
        attendeeRequests.add(eventId);
        EventsApi.fetchAttendees(eventsServer, eventId, (people, error) -> {
            attendeeRequests.remove(eventId);
            if (isFinishing() || isDestroyed()) return;
            attendeesByEvent.put(eventId, people);
            if (openChat == null && currentTab.equals("Event") && eventId.equals(openEventId)) render();
        });
    }

    private void buildMatchPage() {
        setAppBar("Find your crew", null);
        add(body("Pick an event you joined. We’ll suggest a few people going too.", 14), 6, 14);
        if (eventsServer.isEmpty()) {
            addLocalNotice("Matches use sample profiles on this phone. Connect to the events "
                    + "server in Settings to meet real people going.");
        } else {
            addNotice("Real people, real plans",
                    "Matches are people who joined the same Timișoara event in MeetMate.");
        }

        add(sectionTitle("01  CHOOSE AN EVENT"), 0, 10);
        List<Event> joined = joinedUpcomingEvents();
        if (joined.isEmpty()) {
            TextView empty = body("You haven’t joined an event yet. Pick something on Explore, "
                    + "tap Join, then come back to find your crew.", 13);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(22), dp(18), dp(22));
            empty.setBackground(round(PALE, 16));
            add(empty, 0, 12);
            Button explore = primaryButton("Explore Timișoara events");
            add(explore, 0, 8);
            explore.setOnClickListener(v -> {
                currentTab = "Explore";
                render();
            });
            return;
        }
        boolean selectionStillJoined = false;
        for (Event event : joined) {
            if (event.id.equals(selectedEventId)) selectionStillJoined = true;
        }
        if (!selectionStillJoined) {
            selectedEventId = joined.get(0).id;
            matchReady = false;
        }
        for (Event event : joined) addEventCard(event, true);

        LinearLayout sizeHeader = row();
        sizeHeader.setGravity(Gravity.CENTER_VERTICAL);
        sizeHeader.addView(sectionTitle("02  CREW SIZE"), new LinearLayout.LayoutParams(0, -2, 1f));
        add(sizeHeader, 0, 12);
        LinearLayout sizeCard = row();
        sizeCard.setGravity(Gravity.CENTER_VERTICAL);
        sizeCard.setPadding(dp(16), dp(12), dp(16), dp(12));
        sizeCard.setBackground(round(PALE, 16));
        LinearLayout sizeText = column();
        sizeText.addView(title("Your group", 15));
        sizeText.addView(body("Including you", 11));
        sizeCard.addView(sizeText, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView minus = roundControl("−");
        sizeCard.addView(minus);
        TextView count = label(String.valueOf(groupSize), 17, INK, true);
        count.setGravity(Gravity.CENTER);
        sizeCard.addView(count, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView plus = roundControl("+");
        sizeCard.addView(plus);
        // Update the count in place; a full render() rebuilds the screen and flickers.
        minus.setOnClickListener(v -> {
            if (groupSize > 2) groupSize--;
            count.setText(String.valueOf(groupSize));
        });
        plus.setOnClickListener(v -> {
            if (groupSize < 6) groupSize++;
            count.setText(String.valueOf(groupSize));
        });
        add(sizeCard, 0, 18);

        add(sectionTitle("03  YOUR VIBE"), 0, 14);
        LinearLayout tags = row();
        tags.setPadding(0, dp(4), dp(8), dp(8));
        for (String interest : selectedInterests) {
            TextView tag = chip(interest, true);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(32));
            params.rightMargin = dp(7);
            tags.addView(tag, params);
        }
        if (selectedInterests.isEmpty()) tags.addView(body("Add interests in your profile", 12));
        HorizontalScrollView tagScroll = new HorizontalScrollView(this);
        tagScroll.setHorizontalScrollBarEnabled(false);
        tagScroll.addView(tags);
        add(tagScroll, 0, 12);

        Button matchButton = primaryButton(matchLoading ? "Finding your crew…"
                : matchReady ? "Try another group" : "Find my crew");
        matchButton.setEnabled(!matchLoading);
        add(matchButton, 0, 16);
        matchButton.setOnClickListener(v -> findMatches());

        if (matchReady) {
            addMatches();
        } else {
            TextView privacy = body("You’ll review your crew before a group chat is created.", 11);
            privacy.setGravity(Gravity.CENTER);
            add(privacy, 0, 12);
        }
    }

    private void findMatches() {
        if (selectedEventId == null || matchLoading) return;
        if (eventsServer.isEmpty()) {
            matchSamplePeople();
            return;
        }
        matchLoading = true;
        render();
        String eventId = selectedEventId;
        String server = eventsServer;
        // Make sure the server knows this person and the events they joined before matching.
        syncProfile((saved, saveError) -> {
            if (saved == null) {
                finishServerMatch(eventId, null, saveError);
                return;
            }
            EventsApi.matchPeople(server, eventId, userId,
                    (found, error) -> finishServerMatch(eventId, found, error));
        });
    }

    private void finishServerMatch(String eventId, List<EventsApi.Person> found, String error) {
        matchLoading = false;
        if (isFinishing() || isDestroyed()) return;
        if (!eventId.equals(selectedEventId)) {
            // Another event was picked while this was loading; don't show stale results.
            matchReady = false;
            rerenderIf("Match");
            return;
        }
        if (found == null) {
            Toast.makeText(this, error + " Showing sample profiles instead.", Toast.LENGTH_LONG).show();
            matchSamplePeople();
            return;
        }
        List<LocalPerson> ranked = new ArrayList<>();
        for (EventsApi.Person person : found) {
            if (!person.id.equals(userId)) ranked.add(new LocalPerson(person.name, initial(person.name), person.interests));
        }
        pickMatches(ranked, true);
    }

    private void matchSamplePeople() {
        List<LocalPerson> ranked = new ArrayList<>();
        for (LocalPerson person : people) {
            if (!person.sharedInterests(selectedInterests).isEmpty()) ranked.add(person);
        }
        Collections.sort(ranked, (left, right) -> Integer.compare(
                right.sharedInterests(selectedInterests).size(),
                left.sharedInterests(selectedInterests).size()));
        if (ranked.isEmpty()) {
            Toast.makeText(this, "Add a few interests to find your people.", Toast.LENGTH_LONG).show();
        }
        pickMatches(ranked, false);
    }

    /** Shows the next group from the ranked list; "Try another group" rotates through it. */
    private void pickMatches(List<LocalPerson> ranked, boolean fromServer) {
        matchesFromServer = fromServer;
        currentMatches.clear();
        if (!ranked.isEmpty()) {
            int start = matchOffset % ranked.size();
            int count = Math.min(groupSize - 1, ranked.size());
            for (int i = 0; i < count; i++) {
                currentMatches.add(ranked.get((start + i) % ranked.size()));
            }
            matchOffset = (start + 1) % ranked.size();
        }
        matchReady = true;
        render();
    }

    private void addMatches() {
        add(sectionTitle("PEOPLE WHO MIGHT CLICK"), 0, 22);
        Event event = eventById(selectedEventId);
        String eventName = event == null ? "this event" : event.name;
        if (currentMatches.isEmpty()) {
            add(body(matchesFromServer
                    ? "No one else has joined " + eventName + " yet. Share it with friends and "
                    + "check back soon."
                    : "None of the sample profiles share your interests. Add a few interests "
                    + "in your profile.", 13), 0, 10);
            if (matchesFromServer && event != null) {
                Button share = primaryButton("Share this event");
                add(share, 0, 8);
                share.setOnClickListener(v -> shareEvent(event));
            }
            return;
        }
        add(body(matchesFromServer
                ? "People going to " + eventName + ", picked by your shared interests."
                : "Sample profiles picked for " + eventName + " based on your shared interests.",
                12), 0, 12);
        for (LocalPerson person : currentMatches) addPersonCard(person);

        Button accept = primaryButton("Start a group chat");
        add(accept, 0, 16);
        accept.setOnClickListener(v -> {
            List<String> members = new ArrayList<>();
            for (LocalPerson person : currentMatches) {
                // Ratings are stored by name, so two people called "Alex" become "Alex" and "Alex 2".
                String member = person.name;
                for (int copy = 2; members.contains(member); copy++) member = person.name + " " + copy;
                members.add(member);
            }
            LocalChat chat = new LocalChat(UUID.randomUUID().toString(),
                    event == null ? "" : event.id, eventName, members);
            chats.add(0, chat);
            persistChats();
            openChat = chat;
            currentTab = "Chats";
            Toast.makeText(MainActivity.this,
                    "Your local event group chat is ready!", Toast.LENGTH_SHORT).show();
            render();
        });
        TextView pass = label("Try a different group", 12, MUTED, true);
        pass.setGravity(Gravity.CENTER);
        add(pass, 0, 15);
        pass.setOnClickListener(v -> {
            matchReady = false;
            currentMatches.clear();
            render();
        });
    }

    private void addPersonCard(LocalPerson person) {
        LinearLayout card = row();
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(round(CARD, 20));
        floatAbove(card, 2, ICON);
        View avatar = avatar(person.emoji, 48, TILE);
        card.addView(avatar);
        LinearLayout info = column();
        TextView name = title(person.name, 14);
        info.addView(name);
        String sharedText = person.sharedInterestsText(selectedInterests);
        TextView shared = body(sharedText.isEmpty() ? "Going to this event too"
                : "You both like " + sharedText, 11);
        shared.setPadding(0, dp(5), 0, 0);
        info.addView(shared);
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, -2, 1f);
        infoParams.leftMargin = dp(12);
        card.addView(info, infoParams);
        int sharedCount = person.sharedInterests(selectedInterests).size();
        if (sharedCount > 0) card.addView(label(sharedCount + " shared", 10, ACCENT, true));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(9);
        page.addView(card, params);
    }

    private void buildChatsPage() {
        setAppBar("Chats", null);
        addLocalNotice("Your messages are saved only on this phone.");
        if (chats.isEmpty()) {
            LinearLayout empty = column();
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(24), dp(34), dp(24), dp(34));
            empty.setBackground(round(PALE, 20));
            TextView emoji = icon("💬", 38);
            emoji.setGravity(Gravity.CENTER);
            empty.addView(emoji);
            TextView heading = title("No group chats yet", 17);
            heading.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams headingParams = new LinearLayout.LayoutParams(-1, -2);
            headingParams.topMargin = dp(12);
            empty.addView(heading, headingParams);
            TextView text = body("Find a crew for an event and your chat will show up here.", 12);
            text.setGravity(Gravity.CENTER);
            text.setPadding(0, dp(7), 0, 0);
            empty.addView(text);
            add(empty, 0, 10);
            Button explore = primaryButton("Explore events");
            add(explore, 0, 14);
            explore.setOnClickListener(v -> {
                currentTab = "Explore";
                render();
            });
            return;
        }
        for (LocalChat chat : chats) {
            LinearLayout card = row();
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            card.setBackground(round(PALE, 20));
            floatAbove(card, 2, ICON);
            pressable(card);
            Event chatEvent = eventForChat(chat);
            View icon = avatar(chatEvent != null ? chatEvent.emoji() : "💬", 48, TILE);
            card.addView(icon);
            LinearLayout info = column();
            info.addView(title(chat.eventName, 14));
            String lastMessage = chat.lastMessage();
            info.addView(body(chat.memberNamesText() + "  ·  " + lastMessage, 11));
            LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, -2, 1f);
            infoParams.leftMargin = dp(12);
            card.addView(info, infoParams);
            TextView arrow = icon("›", 24);
            card.addView(arrow);
            card.setOnClickListener(v -> {
                openChat = chat;
                render();
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
            params.bottomMargin = dp(10);
            page.addView(card, params);
        }
    }

    private void addLocalNotice(String message) {
        addNotice("On-device demo", message);
    }

    private void addNotice(String heading, String message) {
        LinearLayout notice = column();
        notice.setPadding(dp(18), dp(16), dp(18), dp(16));
        notice.setBackground(round(PALE, 14));
        notice.addView(title(heading, 15));
        TextView details = body(message, 12);
        details.setPadding(0, dp(7), 0, 0);
        notice.addView(details);
        add(notice, 0, 12);
    }

    private LinearLayout buildChatDetail(LocalChat chat) {
        LinearLayout header = row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = label("‹", 29, INK, false);
        back.setOnClickListener(v -> {
            openChat = null;
            chatMessagesContainer = null;
            currentTab = "Chats";
            render();
        });
        header.addView(back, new LinearLayout.LayoutParams(dp(36), dp(48)));
        LinearLayout headerText = column();
        headerText.addView(title(chat.eventName, 16));
        headerText.addView(body((chat.memberNames.size() + 1) + " people · event crew", 10));
        header.addView(headerText, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView details = label("•••", 18, MUTED, true);
        header.addView(details);
        add(header, 0, 8);
        addRule();

        Event event = eventForChat(chat);
        LinearLayout eventBanner = row();
        eventBanner.setGravity(Gravity.CENTER_VERTICAL);
        eventBanner.setPadding(dp(12), dp(11), dp(12), dp(11));
        eventBanner.setBackground(round(CARD, 10));
        eventBanner.addView(icon("📍", 13));
        TextView bannerText = label(event == null ? chat.eventName
                : event.when(now()) + "  ·  " + event.place(), 11, ACCENT, true);
        bannerText.setPadding(dp(8), 0, 0, 0);
        eventBanner.addView(bannerText);
        if (event != null) {
            pressable(eventBanner);
            eventBanner.setOnClickListener(v -> {
                openChat = null;
                chatMessagesContainer = null;
                showEvent(event.id, "Chats");
            });
        }
        add(eventBanner, 0, 14);

        TextView intro = body("You’re in! Say hi and agree where to meet before "
                + (event == null ? chat.eventName : event.name) + ".", 12);
        intro.setGravity(Gravity.CENTER);
        intro.setPadding(dp(18), dp(12), dp(18), dp(14));
        intro.setBackground(round(PALE, 14));
        add(intro, 0, 14);

        TextView reportConcern = label("Report a concern", 12, ACCENT, true);
        reportConcern.setOnClickListener(v -> {
            showSafetyPage(chat.eventName + " group chat", "Chat", chat);
        });
        add(reportConcern, 0, 12);

        Button feedback = primaryButton(chat.hangoutCompleted
                ? "Update post-hangout ratings" : "Hangout finished? Rate your crew");
        add(feedback, 0, 14);
        feedback.setOnClickListener(v -> {
            chat.hangoutCompleted = true;
            feedbackChat = chat;
            openChat = null;
            currentTab = "Hangout feedback";
            persistChats();
            render();
        });

        chatMessagesContainer = column();
        page.addView(chatMessagesContainer, new LinearLayout.LayoutParams(-1, -2));
        renderMessages(chat);
        scrollChatToLatestMessage();

        LinearLayout compose = row();
        compose.setGravity(Gravity.CENTER_VERTICAL);
        compose.setPadding(dp(14), dp(9), dp(14), dp(12));
        compose.setBackgroundColor(PAPER);
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(13);
        input.setTextColor(INK);
        input.setHintTextColor(MUTED);
        input.setHint("Message your crew...");
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setBackground(round(FIELD, 24));
        compose.addView(input, new LinearLayout.LayoutParams(0, dp(INPUT_HEIGHT), 1f));
        FrameLayout send = new FrameLayout(this);
        send.setContentDescription("Send message");
        send.setBackground(round(OWN_BUBBLE, 23));  // dark red
        floatAbove(send, 6, OWN_BUBBLE);
        pressable(send);
        // Plain text glyph on its own view, so only the arrow is black, not the button.
        TextView sendArrow = label("➤" + TEXT_STYLE, 20, ON_RED, true);
        sendArrow.setGravity(Gravity.CENTER);
        send.addView(sendArrow, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(dp(46), dp(46));
        sendParams.leftMargin = dp(8);
        compose.addView(send, sendParams);
        send.setOnClickListener(v -> sendMessage(chat, input));
        input.setOnEditorActionListener((view, actionId, eventAction) -> {
            if (actionId != EditorInfo.IME_ACTION_SEND) return false;
            sendMessage(chat, input);
            return true;
        });
        return compose;
    }

    private void renderMessages(LocalChat chat) {
        if (chatMessagesContainer == null) return;
        chatMessagesContainer.removeAllViews();
        if (chat.messages.isEmpty()) {
            TextView empty = body("No messages yet. Send a hello to start planning.", 12);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(20), dp(18), dp(20));
            empty.setBackground(round(PALE, 14));
            chatMessagesContainer.addView(empty);
            return;
        }
        for (LocalMessage message : chat.messages) addMessageBubble(message);
        chatMessagesContainer.requestLayout();
        chatMessagesContainer.invalidate();
    }

    private void addMessageBubble(LocalMessage message) {
        LinearLayout bubbleWrap = column();
        TextView sender = label(message.own ? "You" : message.senderName, 10, MUTED, true);
        if (message.own) sender.setGravity(Gravity.RIGHT);
        bubbleWrap.addView(sender);
        TextView bubble = body(message.text, 13);
        bubble.setTextColor(BUBBLE_TEXT);  // light text on red bubbles, always
        bubble.setPadding(dp(13), dp(10), dp(13), dp(10));
        bubble.setBackground(round(message.own ? OWN_BUBBLE : ACCENT, 14));
        LinearLayout.LayoutParams bubbleParams = new LinearLayout.LayoutParams(-2, -2);
        if (message.own) bubbleParams.gravity = Gravity.RIGHT;
        bubbleParams.topMargin = dp(4);
        bubbleWrap.addView(bubble, bubbleParams);
        LinearLayout.LayoutParams wrapParams = new LinearLayout.LayoutParams(-1, -2);
        wrapParams.bottomMargin = dp(12);
        chatMessagesContainer.addView(bubbleWrap, wrapParams);
    }

    private void scrollChatToLatestMessage() {
        if (contentScroll == null || chatMessagesContainer == null) return;
        chatMessagesContainer.post(() -> {
            if (contentScroll == null || chatMessagesContainer == null) return;
            int targetY = chatMessagesContainer.getBottom() - contentScroll.getHeight();
            contentScroll.scrollTo(0, Math.max(0, targetY));
        });
    }

    private void sendMessage(
            LocalChat chat,
            EditText input) {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        if (text.length() > 1000) {
            Toast.makeText(this, "Messages can be up to 1000 characters.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        boolean wasEmpty = chat.messages.isEmpty();
        LocalMessage message = new LocalMessage(userName, text, true);
        chat.messages.add(message);
        persistChats();
        if (openChat == chat && chatMessagesContainer != null) {
            if (wasEmpty) chatMessagesContainer.removeAllViews();
            addMessageBubble(message);
            chatMessagesContainer.requestLayout();
            chatMessagesContainer.invalidate();
            scrollChatToLatestMessage();
        }
        input.setText("");
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(input.getWindowToken(), 0);
    }

    /** First-launch account creation. Everything is saved on this phone only. */
    private void buildSignupPage() {
        setAppBar(null, null, null, null, null);
        add(title("Create your account", 26), 10, 6);
        add(body("Find events in Timișoara and people to go with. It takes a minute.", 14), 0, 20);

        EditText name = inputField("Your name", preferences.getString("signup_name",
                preferences.getString("name", "")));
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS
                | InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
        name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(40)});
        saveSignupDraft(name, "signup_name");
        add(sectionTitle("NAME"), 0, 6);
        add(name, 0, 14);

        EditText age = inputField("Your age", preferences.getString("signup_age", ""));
        age.setInputType(InputType.TYPE_CLASS_NUMBER);
        age.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
        saveSignupDraft(age, "signup_age");
        add(sectionTitle("AGE"), 0, 6);
        add(age, 0, 14);

        EditText contact = inputField("Email or phone number", preferences.getString("signup_contact",
                preferences.getString("contact", "")));
        contact.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        contact.setFilters(new InputFilter[]{new InputFilter.LengthFilter(80)});
        saveSignupDraft(contact, "signup_contact");
        add(sectionTitle("EMAIL OR PHONE"), 0, 6);
        add(contact, 0, 4);
        add(body("Only saved on this phone. Never shown to other people.", 11), 0, 18);

        add(sectionTitle("WHAT DO YOU LIKE?"), 0, 4);
        add(body("Pick at least one. We use them to find people you’ll get along with.", 12), 0, 10);
        Set<String> picked = new LinkedHashSet<>(preferences.getStringSet("signup_interests",
                new LinkedHashSet<String>()));
        LinearLayout grid = column();
        LinearLayout line = null;
        for (int i = 0; i < INTERESTS.length; i++) {
            if (i % 3 == 0) {
                line = row();
                LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(-1, -2);
                lineParams.bottomMargin = dp(8);
                grid.addView(line, lineParams);
            }
            String interest = INTERESTS[i];
            TextView chip = chip(interest, picked.contains(interest));
            LinearLayout.LayoutParams chipParams = new LinearLayout.LayoutParams(0, dp(38), 1f);
            chipParams.setMargins(dp(3), 0, dp(3), 0);
            line.addView(chip, chipParams);
            // Restyle in place so typed text isn't lost by a full redraw.
            chip.setOnClickListener(v -> {
                boolean nowPicked = !picked.contains(interest);
                if (nowPicked) picked.add(interest);
                else picked.remove(interest);
                styleChip(chip, nowPicked);
                preferences.edit().putStringSet("signup_interests", new LinkedHashSet<>(picked)).apply();
            });
        }
        if (line != null) {
            for (int filler = INTERESTS.length % 3; filler != 0 && filler < 3; filler++) {
                line.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));
            }
        }
        add(grid, 0, 14);

        CheckBox agree = new CheckBox(this);
        agree.setText("I understand that people going to the same events can see my name and "
                + "interests, and I’ll meet new people in public places.");
        agree.setTextColor(INK);
        agree.setTextSize(12);
        agree.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        add(agree, 4, 16);

        Button create = primaryButton("Create account");
        add(create, 0, 10);
        create.setOnClickListener(v -> {
            String newName = name.getText().toString().trim();
            String ageText = age.getText().toString().trim();
            String newContact = contact.getText().toString().trim();
            int ageValue = parseAge(ageText);
            String problem = profileProblem(newName, ageText, newContact);
            if (problem == null && picked.isEmpty()) problem = "Pick at least one interest.";
            else if (!agree.isChecked()) problem = "Tick the box to confirm you understand how sharing works.";
            if (problem != null) {
                Toast.makeText(this, problem, Toast.LENGTH_LONG).show();
                return;
            }
            userName = newName;
            userAge = String.valueOf(ageValue);
            userContact = newContact;
            selectedInterests.clear();
            selectedInterests.addAll(picked);
            signedUp = true;
            preferences.edit()
                    .putString("name", userName)
                    .putString("age", userAge)
                    .putString("contact", userContact)
                    .putStringSet("interests", new LinkedHashSet<>(selectedInterests))
                    .putBoolean("signed_up", true)
                    .putLong("signed_up_at", System.currentTimeMillis())
                    .remove("signup_name").remove("signup_age").remove("signup_contact")
                    .remove("signup_interests")
                    .apply();
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(create.getWindowToken(), 0);
            Toast.makeText(this, "Welcome to MeetMate, " + userName + "!", Toast.LENGTH_SHORT).show();
            currentTab = "Explore";
            render();
        });
        TextView note = body("Your account is saved on this phone. You can change it any time "
                + "in Profile.", 11);
        note.setGravity(Gravity.CENTER);
        add(note, 4, 12);
    }

    /** Keeps what was typed if the app is closed during sign-up. */
    private void saveSignupDraft(EditText field, String key) {
        field.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(android.text.Editable s) {
                preferences.edit().putString(key, s.toString()).apply();
            }
        });
    }

    private static int parseAge(String text) {
        try {
            return text.trim().isEmpty() ? -1 : Integer.parseInt(text.trim());
        } catch (NumberFormatException error) {
            return -1;
        }
    }

    /** Same rules for sign-up and Profile edits; null when everything is fine. */
    private static String profileProblem(String name, String ageText, String contact) {
        int age = parseAge(ageText);
        if (name.isEmpty()) return "Enter your name.";
        if (name.length() > 40) return "Names can be up to 40 characters.";
        if (age < 0) return "Enter your age.";
        if (age < 16) return "You need to be 16 or older to use MeetMate.";
        if (age > 120) return "Check your age.";
        if (!isEmailOrPhone(contact)) return "Enter a valid email address or phone number.";
        return null;
    }

    private static boolean isEmailOrPhone(String value) {
        if (android.util.Patterns.EMAIL_ADDRESS.matcher(value).matches()) return true;
        String digits = value.replaceAll("[\\s()+.-]", "");
        return digits.matches("\\d{7,15}") && value.matches("[\\d\\s()+.-]+");
    }

    private void buildProfilePage() {
        String returnTab = profileReturnTab;
        setAppBar("Profile", returnTab == null ? null : () -> {
            profileReturnTab = null;
            currentTab = returnTab;
            render();
        });

        LinearLayout hero = row();
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(dp(16), dp(15), dp(16), dp(15));
        hero.setBackground(round(CARD, 14));
        View avatar = avatar("😊", 54, TILE);
        hero.addView(avatar);
        LinearLayout heroText = column();
        heroText.addView(title(userName + ", " + userAge, 17));
        heroText.addView(body("Timișoara, Romania", 11));
        LinearLayout.LayoutParams heroTextParams = new LinearLayout.LayoutParams(0, -2, 1f);
        heroTextParams.leftMargin = dp(12);
        hero.addView(heroText, heroTextParams);
        add(hero, 0, 20);

        add(sectionTitle("ABOUT YOU"), 0, 14);
        EditText name = inputField("Name", userName);
        add(name, 0, 8);
        EditText age = inputField("Age", userAge);
        age.setInputType(2);
        add(age, 0, 8);
        EditText contact = inputField("Email or phone", userContact);
        add(contact, 0, 12);
        Button save = primaryButton("Save profile");
        add(save, 0, 4);
        save.setOnClickListener(v -> {
            String newName = name.getText().toString().trim();
            String newAge = age.getText().toString().trim();
            String newContact = contact.getText().toString().trim();
            String problem = profileProblem(newName, newAge, newContact);
            if (problem != null) {
                Toast.makeText(this, problem, Toast.LENGTH_LONG).show();
                return;
            }
            userName = newName;
            userAge = String.valueOf(parseAge(newAge));
            userContact = newContact;
            preferences.edit().putString("name", userName).putString("age", userAge)
                    .putString("contact", userContact).apply();
            Toast.makeText(this, "Profile saved", Toast.LENGTH_SHORT).show();
            onProfileChanged();
            render();
        });

        add(sectionTitle("INTERESTS & HOBBIES"), 0, 24);
        add(body("Pick a few things you love. We’ll use them to make better matches.", 12), 0, 10);
        LinearLayout interestList = column();
        interestList.setPadding(dp(12), dp(4), dp(12), dp(4));
        interestList.setBackground(round(CARD, 20));
        floatAbove(interestList, 2, ICON);
        for (String interest : INTERESTS) {
            CheckBox check = new CheckBox(this);
            check.setText(interest);
            check.setTextColor(INK);
            check.setTextSize(12);
            check.setButtonTintList(android.content.res.ColorStateList.valueOf(
                    selectedInterests.contains(interest) ? ACCENT : MUTED));
            check.setChecked(selectedInterests.contains(interest));
            check.setOnCheckedChangeListener((button, checked) -> {
                if (checked) selectedInterests.add(interest);
                else selectedInterests.remove(interest);
                check.setButtonTintList(android.content.res.ColorStateList.valueOf(
                        checked ? ACCENT : MUTED));
                preferences.edit().putStringSet("interests", new LinkedHashSet<>(selectedInterests)).apply();
                onProfileChanged();
            });
            interestList.addView(check, new LinearLayout.LayoutParams(-1, dp(44)));
        }
        add(interestList, 0, 10);
    }

    private void buildSettingsPage() {
        setAppBar("Settings", null);

        add(sectionTitle("PREFERENCES"), 8, 8);
        startGroup();
        addSettingRow("Push notifications", "Get updates about your event crews", notificationsEnabled, value -> {
            notificationsEnabled = value;
            preferences.edit().putBoolean("notifications", value).apply();
            Toast.makeText(this, value ? "Notifications enabled" : "Notifications paused", Toast.LENGTH_SHORT).show();
        });
        addSettingRow("Dark mode", "Easier on the eyes at night", darkMode, value -> {
            preferences.edit().putBoolean("dark_mode", value).apply();
            applyPalette(value);
            page.post(this::render);
        });
        addSettingRow("Location", "Find events and people nearby", locationEnabled, value -> {
            locationEnabled = value;
            preferences.edit().putBoolean("location", value).apply();
            Toast.makeText(this, value ? "Nearby events enabled" : "Nearby events paused", Toast.LENGTH_SHORT).show();
        });
        endGroup();

        add(sectionTitle("TIMIȘOARA EVENTS"), 18, 8);
        add(body("Live events and the people going come from the MeetMate events server. Enter the "
                + "address of the computer running it, for example 192.168.1.20:8000.", 12), 0, 10);
        EditText server = inputField("Events server address", eventsServer);
        server.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        server.setImeOptions(EditorInfo.IME_ACTION_DONE);
        add(server, 0, 8);
        Button connect = primaryButton(eventsServer.isEmpty() ? "Connect" : "Save & refresh");
        add(connect, 0, 6);
        connect.setOnClickListener(v -> connectEventsServer(server));
        server.setOnEditorActionListener((view, actionId, keyEvent) -> {
            boolean enterKey = keyEvent != null
                    && keyEvent.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER
                    && keyEvent.getAction() == android.view.KeyEvent.ACTION_DOWN;
            if (actionId != EditorInfo.IME_ACTION_DONE && !enterKey) return false;
            connectEventsServer(server);
            return true;
        });
        add(body(eventsStatusText(), 11), 0, 4);

        add(sectionTitle("ACCOUNT"), 18, 8);
        startGroup();
        addActionRow("Personal information", "Update your name, age, and contact", "›",
                () -> { profileReturnTab = "Settings"; currentTab = "Profile"; render(); });
        addActionRow("Interests & hobbies", "Choose what you’d love to do", "›",
                () -> { profileReturnTab = "Settings"; currentTab = "Profile"; render(); });
        endGroup();

        add(sectionTitle("BUGS & FIXES"), 18, 8);
        startGroup();
        addActionRow("Report a bug", "Tell us what went wrong", "↗",
                () -> showBugFixPage("Bug report"));
        addActionRow("Suggest a fix", "Share an improvement idea", "↗",
                () -> showBugFixPage("Fix suggestion"));
        endGroup();

        add(sectionTitle("SAFETY & REPORTS"), 18, 8);
        startGroup();
        addActionRow("Safety & reports", "Rate a completed hangout or report a concern", "›",
                () -> {
                    safetyReturnTab = "Settings";
                    safetyReturnChat = null;
                    currentTab = "Safety";
                    render();
                });
        endGroup();

        add(sectionTitle("ABOUT"), 18, 8);
        startGroup();
        addActionRow("Help & support", "Contact MeetMate support", "↗",
                () -> showBugFixPage("General support"));
        endGroup();
        TextView version = body("MEETMATE  ·  VERSION 1.0.0", 10);
        version.setGravity(Gravity.CENTER);
        version.setLetterSpacing(0.08f);
        add(version, 0, 25);
    }

    private void showBugFixPage(String topic) {
        bugFixTopic = topic;
        currentTab = "Bugs & fixes";
        render();
    }

    private void buildBugFixPage() {
        setAppBar(bugFixTopic, () -> {
            currentTab = "Settings";
            render();
        });
        add(body("Describe the issue or improvement. We won’t attach profile or device data.", 14),
                6, 16);

        EditText details = new EditText(this);
        details.setHint("What happened, or what would you change?");
        details.setTextSize(13);
        details.setTextColor(INK);
        details.setHintTextColor(MUTED);
        details.setGravity(Gravity.TOP | Gravity.START);
        details.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        details.setMinLines(5);
        details.setMaxLines(9);
        details.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2000)});
        details.setPadding(dp(14), dp(12), dp(14), dp(12));
        details.setBackground(round(FIELD, 13));
        String draftKey = "bugfix_" + bugFixTopic;
        details.setText(draftPreferences.getString(draftKey, ""));
        saveDraftOnChange(details, draftKey);
        page.addView(details, new LinearLayout.LayoutParams(-1, dp(150)));

        String topic = bugFixTopic;
        Button sendButton = primaryButton("Send");
        add(sendButton, 0, 12);
        sendButton.setOnClickListener(v -> {
            String description = details.getText().toString().trim();
            if (description.isEmpty()) {
                Toast.makeText(this, "Add a few details first.", Toast.LENGTH_SHORT).show();
                return;
            }
            String title = emailTitle(topic);
            sendFeedback(sendButton, reportKind(topic), "MeetMate: " + title,
                    title + "\n\n" + description, () -> {
                        draftPreferences.edit().remove(draftKey).apply();
                        details.setText("");
                    });
        });
        add(body(reportDestinationText(), 11), 0, 18);
    }

    /** Where a report goes, and a warning when the connection isn't encrypted. */
    private String reportDestinationText() {
        if (!BuildConfig.FORMSPREE_FORM_ID.isEmpty()) {
            return "Your message is sent securely to the MeetMate team. Your text is kept on "
                    + "this phone until it’s sent.";
        }
        if (eventsServer.isEmpty()) {
            return "Connect to the events server in Settings to send this. Your text is kept "
                    + "on this phone until it’s sent.";
        }
        String text = "Your message is sent to the events server you connected to ("
                + linkHost(eventsServer) + "), which forwards it to the MeetMate team.";
        if (!eventsServer.startsWith("https://")) {
            text += " This connection isn’t encrypted: on public Wi-Fi, others could read it.";
        }
        return text;
    }

    /** Report type understood by the events server's /reports endpoint. */
    private static String reportKind(String topic) {
        switch (topic) {
            case "Bug report": return "bug";
            case "Fix suggestion": return "fix";
            default: return "support";
        }
    }

    /** Email subject title for each feedback topic. */
    private static String emailTitle(String topic) {
        switch (topic) {
            case "Bug report": return "Bug Report";
            case "Fix suggestion": return "Fix Suggestion";
            case "General support": return "Support Request";
            default: return topic;
        }
    }

    private void saveDraftOnChange(EditText field, String key) {
        field.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(android.text.Editable s) {
                draftPreferences.edit().putString(key, s.toString()).apply();
            }
        });
    }

    private void sendFeedback(Button button, String kind, String subject, String message,
                              Runnable onSent) {
        CharSequence label = button.getText();
        button.setEnabled(false);
        button.setText("Sending…");
        FeedbackSender.send(eventsServer, kind, subject, message, (success, error) -> {
            if (isFinishing() || isDestroyed()) return;
            button.setEnabled(true);
            button.setText(label);
            if (success) {
                onSent.run();
                Toast.makeText(this, "Sent. Thank you!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void buildSafetyPage() {
        setAppBar("Safety & reports", () -> {
            if ("Chat".equals(safetyReturnTab) && safetyReturnChat != null) {
                openChat = safetyReturnChat;
                currentTab = "Chats";
            } else if ("Hangout feedback".equals(safetyReturnTab)
                    && safetyReturnChat != null) {
                feedbackChat = safetyReturnChat;
                currentTab = "Hangout feedback";
            } else {
                currentTab = "Settings";
            }
            safetyReturnTab = "Settings";
            safetyReturnChat = null;
            render();
        });
        add(body("Your comfort matters. Meet in public places, keep personal details private, and leave any situation that feels wrong.", 13), 0, 16);

        LinearLayout urgent = column();
        urgent.setPadding(dp(16), dp(14), dp(16), dp(14));
        urgent.setBackground(round(CARD, 14));
        urgent.addView(title("Immediate danger?", 14));
        TextView urgentText = body(
                "Contact local emergency services. This report form is not an emergency service.",
                12);
        urgentText.setPadding(0, dp(6), 0, 0);
        urgent.addView(urgentText);
        add(urgent, 0, 20);

        add(sectionTitle("REPORT A CONCERN"), 0, 8);
        add(body("This isn’t emergency response, and a reply time can’t be guaranteed. "
                + reportDestinationText(), 12), 0, 12);

        EditText target = inputField("Person, event, or chat",
                draftPreferences.getString("safety_target", ""));
        target.setFilters(new InputFilter[]{new InputFilter.LengthFilter(120)});
        saveDraftOnChange(target, "safety_target");
        add(target, 0, 10);

        String[] categories = {
                "Harassment or bullying",
                "Threatening behavior",
                "Inappropriate content",
                "Spam or scam",
                "Other safety concern"
        };
        Spinner category = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, categories) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                return themed(super.getView(position, convertView, parent));
            }
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                return themed(super.getDropDownView(position, convertView, parent));
            }
            private View themed(View view) {
                if (view instanceof TextView) ((TextView) view).setTextColor(INK);
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category.setAdapter(adapter);
        category.setSelection(Math.max(0, Arrays.asList(categories)
                .indexOf(draftPreferences.getString("safety_category", ""))));
        category.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view,
                                       int position, long id) {
                draftPreferences.edit().putString("safety_category", categories[position]).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        category.setPadding(dp(12), 0, dp(12), 0);
        category.setBackground(round(FIELD, 24));
        category.setPopupBackgroundDrawable(round(CARD, 16));
        add(category, 0, 10);

        EditText details = new EditText(this);
        details.setHint("What happened? Include only details needed to understand the concern.");
        details.setTextSize(13);
        details.setTextColor(INK);
        details.setHintTextColor(MUTED);
        details.setGravity(Gravity.TOP | Gravity.START);
        details.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        details.setMinLines(4);
        details.setMaxLines(8);
        details.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2000)});
        details.setPadding(dp(14), dp(12), dp(14), dp(12));
        details.setBackground(round(FIELD, 13));
        details.setText(draftPreferences.getString("safety_details", ""));
        saveDraftOnChange(details, "safety_details");
        page.addView(details, new LinearLayout.LayoutParams(-1, dp(130)));
        Button reportButton = primaryButton("Send report");
        add(reportButton, 0, 12);
        reportButton.setOnClickListener(v -> {
            String reportedItem = target.getText().toString().trim();
            String description = details.getText().toString().trim();
            if (reportedItem.isEmpty() || description.isEmpty()) {
                Toast.makeText(this, "Add who or what you’re reporting and describe the concern.",
                        Toast.LENGTH_LONG).show();
                return;
            }
            String reportBody = "Safety Report\n\n"
                    + "Concern: " + category.getSelectedItem().toString() + "\n"
                    + "Person, event, or chat: " + reportedItem + "\n\n"
                    + "Details:\n" + description + "\n\n"
                    + "Please review this report.";
            sendFeedback(reportButton, "safety", "MeetMate: Safety Report", reportBody, () -> {
                draftPreferences.edit().remove("safety_target")
                        .remove("safety_category").remove("safety_details").apply();
                target.setText("");
                details.setText("");
                category.setSelection(0);
            });
        });
        add(body("The app doesn’t attach your profile or contact details. Your text is kept "
                + "on this phone until it’s sent.", 11), 0, 18);
    }

    private void showSafetyPage(String target, String returnTab, LocalChat chat) {
        draftPreferences.edit().putString("safety_target", target).apply();
        safetyReturnTab = returnTab;
        safetyReturnChat = chat;
        openChat = null;
        currentTab = "Safety";
        render();
    }

    private void buildHangoutFeedbackPage(LocalChat chat) {
        if (chat == null) {
            currentTab = "Chats";
            buildChatsPage();
            return;
        }
        setAppBar("How was your crew?", () -> {
            feedbackChat = null;
            openChat = chat;
            currentTab = "Chats";
            render();
        });
        add(body(chat.eventName + " · Rate each person privately on this phone.",
                13), 0, 14);
        addLocalNotice("Ratings aren’t shared with other users or used to affect matching.");

        for (String member : chat.memberNames) {
            LinearLayout card = column();
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            card.setBackground(round(PALE, 14));
            LinearLayout heading = row();
            heading.setGravity(Gravity.CENTER_VERTICAL);
            heading.addView(title(member, 15), new LinearLayout.LayoutParams(0, -2, 1f));
            TextView report = label("Report", 11, ACCENT, true);
            heading.addView(report);
            report.setOnClickListener(v -> showSafetyPage(
                    member + " · " + chat.eventName + " hangout",
                    "Hangout feedback", chat));
            card.addView(heading);

            LinearLayout stars = row();
            stars.setGravity(Gravity.CENTER_VERTICAL);
            int currentRating = chat.ratings.containsKey(member) ? chat.ratings.get(member) : 0;
            for (int value = 1; value <= 5; value++) {
                final int rating = value;
                TextView star = icon(value <= currentRating ? "★" : "☆", 27);
                star.setContentDescription("Rate " + member + " " + value + " out of 5");
                star.setPadding(dp(3), dp(4), dp(5), dp(4));
                star.setOnClickListener(v -> {
                    chat.ratings.put(member, rating);
                    persistChats();
                    feedbackChat = chat;
                    render();
                });
                stars.addView(star);
            }
            card.addView(stars);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
            cardParams.bottomMargin = dp(10);
            page.addView(card, cardParams);
        }

        if (chat.ratings.size() == chat.memberNames.size()) {
            add(body("Thanks for sharing your feedback.", 12), 0, 10);
        }
        Button done = primaryButton("Back to group chat");
        add(done, 0, 12);
        done.setOnClickListener(v -> {
            feedbackChat = null;
            openChat = chat;
            currentTab = "Chats";
            render();
        });
    }

    private interface ToggleHandler { void changed(boolean value); }

    private void addSettingRow(String title, String subtitle, boolean checked, ToggleHandler handler) {
        LinearLayout card = row();
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(13), dp(12), dp(13));
        LinearLayout text = column();
        text.addView(label(title, 15, INK, true));
        TextView sub = body(subtitle, 12);
        sub.setPadding(0, dp(3), 0, 0);
        text.addView(sub);
        card.addView(text, new LinearLayout.LayoutParams(0, -2, 1f));
        android.widget.Switch toggle = new android.widget.Switch(this);
        int[][] states = {{android.R.attr.state_checked}, {}};
        toggle.setThumbTintList(new android.content.res.ColorStateList(states,
                new int[]{ACCENT, darkMode ? Color.parseColor("#BBBBBB") : Color.WHITE}));
        toggle.setTrackTintList(new android.content.res.ColorStateList(states,
                new int[]{withAlpha(ACCENT, 0x88), withAlpha(ICON, 0x40)}));
        toggle.setChecked(checked);
        toggle.setOnCheckedChangeListener((button, value) -> handler.changed(value));
        card.addView(toggle);
        card.setOnClickListener(v -> toggle.toggle());
        addRow(card, true);
    }

    private void addActionRow(String title, String subtitle, String action, Runnable callback) {
        LinearLayout card = row();
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(14), dp(14), dp(14));
        LinearLayout text = column();
        text.addView(label(title, 15, INK, true));
        TextView sub = body(subtitle, 12);
        sub.setPadding(0, dp(3), 0, 0);
        sub.setSingleLine(true);
        sub.setEllipsize(TextUtils.TruncateAt.END);
        text.addView(sub);
        card.addView(text, new LinearLayout.LayoutParams(0, -2, 1f));
        card.addView(icon(action, 19));
        card.setOnClickListener(v -> callback.run());
        addRow(card, true);
    }

    /** Wordmark-only top bar, used by screens without their own title. */
    private void addBrandHeader() {
        setAppBar(null, null, null, null, null);
    }

    private void addNavigation() {
        String[] names = {"Explore", "Match", "Chats", "Profile", "Settings"};
        int[] icons = {R.drawable.nav_explore, R.drawable.nav_match, R.drawable.nav_chat,
                R.drawable.nav_profile, R.drawable.nav_settings};
        for (int i = 0; i < names.length; i++) {
            final String name = names[i];
            boolean active = (currentTab.equals("Event") ? eventReturnTab : currentTab).equals(name);
            LinearLayout item = column();
            item.setGravity(Gravity.CENTER);
            if (active) item.setBackground(round(withAlpha(NAV_ICON, 0x2E), 26));
            pressable(item);
            android.widget.ImageView icon = new android.widget.ImageView(this);
            icon.setImageResource(icons[i]);
            icon.setImageTintList(android.content.res.ColorStateList.valueOf(NAV_ICON));
            icon.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
            icon.setAlpha(active ? 1f : 0.55f);
            icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            item.addView(icon, new LinearLayout.LayoutParams(dp(22), dp(22)));
            TextView text = label(names[i], 9, NAV_ICON, active);
            text.setAlpha(active ? 1f : 0.7f);
            text.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(-1, -2);
            textParams.topMargin = dp(3);
            item.addView(text, textParams);
            item.setOnClickListener(v -> {
                v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
                profileReturnTab = null;
                openChat = null;
                currentTab = name;
                render();
            });
            LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(0, -1, 1f);
            itemParams.setMargins(dp(2), 0, dp(2), 0);
            navigation.addView(item, itemParams);
        }
    }

    private void addRule() {
        View rule = new View(this);
        rule.setBackgroundColor(LINE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(1));
        params.bottomMargin = dp(1);
        page.addView(rule, params);
    }

    /**
     * Lifts a view off the page with a soft shadow tinted in its own colour, and lets the
     * shadow spill outside its parents instead of being cut off at their edges.
     */
    private void floatAbove(View view, int elevationDp, int shadowColor) {
        view.setElevation(dp(elevationDp));
        view.setOutlineAmbientShadowColor(shadowColor);
        view.setOutlineSpotShadowColor(shadowColor);
        view.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View v) {
                android.view.ViewParent parent = v.getParent();
                // Stop at horizontal scrollers: they must keep clipping their rows.
                while (parent instanceof ViewGroup && parent != contentScroll
                        && !(parent instanceof HorizontalScrollView)) {
                    ((ViewGroup) parent).setClipChildren(false);
                    ((ViewGroup) parent).setClipToPadding(false);
                    parent = parent.getParent();
                }
            }
            @Override public void onViewDetachedFromWindow(View v) {}
        });
    }

    /** Shrinks slightly and settles down while pressed, then springs back. */
    private void pressable(View view) {
        float lift = view.getElevation();
        android.animation.StateListAnimator animator = new android.animation.StateListAnimator();
        animator.addState(new int[]{android.R.attr.state_pressed}, pressAnimation(view, 0.95f, -lift / 2));
        animator.addState(new int[]{}, pressAnimation(view, 1f, 0f));
        view.setStateListAnimator(animator);
    }

    private android.animation.Animator pressAnimation(View view, float scale, float z) {
        android.animation.AnimatorSet set = new android.animation.AnimatorSet();
        set.playTogether(
                android.animation.ObjectAnimator.ofFloat(view, "scaleX", scale),
                android.animation.ObjectAnimator.ofFloat(view, "scaleY", scale),
                android.animation.ObjectAnimator.ofFloat(view, "translationZ", z));
        set.setDuration(120);
        set.setInterpolator(new android.view.animation.DecelerateInterpolator());
        return set;
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    private EditText inputField(String hint, String value) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(13);
        input.setTextColor(INK);
        input.setHintTextColor(MUTED);
        input.setHint(hint);
        input.setText(value);
        // Same shape and height as the chat message box.
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setBackground(round(FIELD, 24));
        input.setMinHeight(dp(INPUT_HEIGHT));
        input.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(INPUT_HEIGHT)));
        return input;
    }

    private Button primaryButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(ON_RED);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setBackground(round(ACCENT, 26));
        button.setStateListAnimator(null);
        floatAbove(button, 8, ACCENT);
        pressable(button);
        button.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(52)));
        return button;
    }

    private TextView chip(String text, boolean active) {
        TextView view = label(text, 11, active ? ON_RED : TEXT, active);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(15), 0, dp(15), 0);
        styleChip(view, active);
        pressable(view);
        return view;
    }

    private void styleChip(TextView view, boolean active) {
        view.setTextColor(active ? ON_RED : TEXT);
        view.setTypeface(Typeface.DEFAULT, active ? Typeface.BOLD : Typeface.NORMAL);
        GradientDrawable background = round(active ? ACCENT : PALE, 17);
        if (!active) background.setStroke(dp(1), LINE);
        view.setBackground(background);
        floatAbove(view, active ? 5 : 1, active ? ACCENT : ICON);
    }

    private TextView roundControl(String text) {
        TextView view = label(text, 20, INK, true);
        view.setGravity(Gravity.CENTER);
        view.setBackground(round(PAPER, 19));
        floatAbove(view, 4, ICON);
        pressable(view);
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        return view;
    }

    private View avatar(String text, int size, int color) {
        FrameLayout tile = new FrameLayout(this);
        tile.setBackground(round(color, size / 3));
        tile.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        TextView glyph = icon(text, 22);
        glyph.setGravity(Gravity.CENTER);
        tile.addView(glyph, new FrameLayout.LayoutParams(-1, -1));
        return tile;
    }

    /** A symbol or emoji drawn in the single icon colour. */
    private TextView icon(String symbol, int size) {
        TextView view = label(symbol + TEXT_STYLE, size, ICON, true);
        view.setGravity(Gravity.CENTER);
        tintGlyphs(view, ICON);
        return view;
    }

    /**
     * Colour emojis ignore text colour, so draw the view through a colour filter that
     * keeps each glyph's shape and paints it in one colour. Only use on views without
     * a background, since the filter applies to everything the view draws.
     */
    private void tintGlyphs(View view, int color) {
        android.graphics.Paint paint = new android.graphics.Paint();
        paint.setColorFilter(new android.graphics.PorterDuffColorFilter(
                color, android.graphics.PorterDuff.Mode.SRC_IN));
        view.setLayerType(View.LAYER_TYPE_HARDWARE, paint);
    }

    private TextView sectionTitle(String text) {
        TextView view = label(text, 10, MUTED, true);
        view.setLetterSpacing(0.06f);
        return view;
    }

    private TextView title(String text, int size) {
        TextView view = label(text, size, INK, true);
        view.setTypeface(Typeface.SERIF, Typeface.BOLD);
        view.setLineSpacing(dp(2), 1f);
        return view;
    }

    private TextView body(String text, int size) {
        TextView view = label(text, size, MUTED, false);
        view.setLineSpacing(dp(2), 1f);
        return view;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private void add(View view, int topMargin, int bottomMargin) {
        boolean fixedInput = view instanceof EditText || view instanceof Spinner;
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1,
                fixedInput ? dp(INPUT_HEIGHT) : -2);
        params.topMargin = dp(topMargin);
        params.bottomMargin = dp(bottomMargin);
        page.addView(view, params);
    }

    private LinearLayout row() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        return layout;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int rgb(int red, int green, int blue) {
        return Color.rgb(red, green, blue);
    }

    private ZonedDateTime now() {
        return ZonedDateTime.now(Event.TIMISOARA);
    }

    /** Events that haven't finished yet, soonest first. */
    private List<Event> upcomingEvents() {
        ZonedDateTime now = now();
        List<Event> upcoming = new ArrayList<>();
        for (Event event : events) if (event.isUpcoming(now)) upcoming.add(event);
        Collections.sort(upcoming, (left, right) -> left.start.compareTo(right.start));
        return upcoming;
    }

    private List<Event> joinedUpcomingEvents() {
        List<Event> joined = new ArrayList<>();
        for (Event event : upcomingEvents()) if (joinedEvents.contains(event.id)) joined.add(event);
        return joined;
    }

    private Event eventById(String id) {
        if (id == null) return null;
        for (Event event : events) if (event.id.equals(id)) return event;
        return null;
    }

    private Event eventForChat(LocalChat chat) {
        Event event = eventById(chat.eventId);
        if (event != null) return event;
        for (Event candidate : events) if (candidate.name.equals(chat.eventName)) return candidate;
        return null;
    }

    /** Uses the last list from the server if it still has upcoming events, else the bundled list. */
    private void loadSavedEvents() {
        SharedPreferences cache = getSharedPreferences("meetmate_events_cache", MODE_PRIVATE);
        preferences.edit().remove("events_cache").remove("events_cache_time").apply();
        String saved = cache.getString("events_cache", null);
        if (saved != null) {
            try {
                events = EventsApi.parseEvents(saved);
                eventsSource = "saved";
                eventsUpdatedAt = cache.getLong("events_cache_time", 0);
                if (!upcomingEvents().isEmpty()) return;
            } catch (JSONException | RuntimeException | StackOverflowError ignored) {
                // Fall back to the list bundled with the app.
            }
        }
        try (java.io.InputStream in = getAssets().open("events.json")) {
            events = EventsApi.parseEvents(EventsApi.readAll(in));
        } catch (IOException | JSONException error) {
            events = new ArrayList<>();
        }
        eventsSource = "bundled";
        eventsUpdatedAt = 0;
    }

    private void refreshEvents(boolean showResult) {
        if (eventsServer.isEmpty() || eventsRefreshing) return;
        eventsRefreshing = true;
        String server = eventsServer;
        EventsApi.fetchEvents(server, (result, error) -> {
            eventsRefreshing = false;
            if (isFinishing() || isDestroyed() || !server.equals(eventsServer)) return;
            if (result == null) {
                if (showResult) {
                    Toast.makeText(this, error + " Check the address and that the server is "
                            + "running on the same Wi-Fi.", Toast.LENGTH_LONG).show();
                }
                rerenderIf("Explore", "Settings");
                return;
            }
            events = result.events;
            eventsSource = "server";
            eventsUpdatedAt = System.currentTimeMillis();
            attendeesByEvent.clear();
            getSharedPreferences("meetmate_events_cache", MODE_PRIVATE).edit()
                    .putString("events_cache", result.json)
                    .putLong("events_cache_time", eventsUpdatedAt).apply();
            if (showResult) {
                Toast.makeText(this, "Connected · " + upcomingEvents().size() + " Timișoara events",
                        Toast.LENGTH_SHORT).show();
            }
            if (profileDirty && preferences.getBoolean("profile_shared", false)) syncProfile(null);
            rerenderIf("Explore", "Match", "Event", "Settings");
        });
    }

    private void rerenderIf(String... tabs) {
        if (openChat != null) return;
        // Don't rebuild the screen under someone who is typing; it would clear the field.
        if (getCurrentFocus() instanceof EditText) return;
        for (String tab : tabs) {
            if (tab.equals(currentTab)) {
                render();
                return;
            }
        }
    }

    private String eventsStatusText() {
        java.time.format.DateTimeFormatter time = java.time.format.DateTimeFormatter
                .ofPattern("HH:mm", java.util.Locale.ENGLISH);
        java.time.format.DateTimeFormatter dayTime = java.time.format.DateTimeFormatter
                .ofPattern("d MMM, HH:mm", java.util.Locale.ENGLISH);
        java.time.ZonedDateTime updated = java.time.Instant.ofEpochMilli(eventsUpdatedAt)
                .atZone(java.time.ZoneId.systemDefault());
        if (eventsSource.equals("server")) {
            return "Live from Visit Timișoara · updated " + time.format(updated);
        }
        String list = eventsSource.equals("saved") && eventsUpdatedAt > 0
                ? "Saved list from " + dayTime.format(updated) : "Event list saved in the app";
        if (eventsServer.isEmpty()) {
            return list + " · connect to the events server in Settings for live updates and "
                    + "to see who’s going.";
        }
        return list + (eventsRefreshing ? " · connecting…"
                : " · the events server isn’t reachable right now.");
    }

    private void connectEventsServer(EditText field) {
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(field.getWindowToken(), 0);
        String input = field.getText().toString().trim();
        attendeesByEvent.clear();
        if (input.isEmpty()) {
            eventsServer = "";
            preferences.edit().putString("events_server", "").apply();
            if (eventsSource.equals("server")) eventsSource = "saved";
            Toast.makeText(this, "Disconnected. MeetMate shows the saved Timișoara events.",
                    Toast.LENGTH_SHORT).show();
            render();
            return;
        }
        String server = EventsApi.normalizeServer(input);
        if (server == null) {
            Toast.makeText(this, "Enter an address like 192.168.1.20:8000", Toast.LENGTH_LONG).show();
            return;
        }
        eventsServer = server;
        preferences.edit().putString("events_server", server).apply();
        eventsRefreshing = false;
        refreshEvents(true);
        render();
    }

    /** What the server learns about this person: a random ID, name, interests and joined events. */
    private JSONObject profileJson() throws JSONException {
        JSONObject profile = new JSONObject();
        profile.put("id", userId);
        profile.put("secret", profileSecret());
        profile.put("name", userName);
        profile.put("university", "");
        profile.put("bio", "");
        JSONArray interests = new JSONArray();
        for (String interest : selectedInterests) interests.put(interest);
        profile.put("interests", interests);
        JSONArray attending = new JSONArray();
        for (String eventId : joinedEvents) attending.put(eventId);
        profile.put("attending_event_ids", attending);
        return profile;
    }

    private boolean syncInFlight;
    private final List<EventsApi.Callback<Boolean>> syncWaiters = new ArrayList<>();

    /**
     * Sends the profile. Updates go one at a time, newest last, so a quick join-then-leave
     * can't reach the server in the wrong order.
     */
    private void syncProfile(EventsApi.Callback<Boolean> done) {
        if (syncInFlight) {
            syncWaiters.add(done);
            return;
        }
        if (eventsServer.isEmpty()) {
            if (done != null) done.done(null, "No events server is connected.");
            return;
        }
        JSONObject profile;
        try {
            profile = profileJson();
        } catch (JSONException error) {
            if (done != null) done.done(null, "Your profile couldn’t be prepared.");
            return;
        }
        int sentVersion = profileVersion;
        String server = eventsServer;
        syncInFlight = true;
        EventsApi.saveProfile(server, profile, (saved, error) -> {
            syncInFlight = false;
            if (isFinishing() || isDestroyed()) return;
            if (saved != null && server.equals(eventsServer) && sentVersion == profileVersion) {
                setProfileDirty(false);
            }
            if (done != null) done.done(saved, error);
            if (!syncWaiters.isEmpty()) {
                List<EventsApi.Callback<Boolean>> waiting = new ArrayList<>(syncWaiters);
                syncWaiters.clear();
                // One more send with the latest profile answers everyone who was waiting.
                syncProfile((again, againError) -> {
                    for (EventsApi.Callback<Boolean> waiter : waiting) {
                        if (waiter != null) waiter.done(again, againError);
                    }
                });
            }
        });
    }

    /** Random secret that proves profile updates come from this phone. */
    private String profileSecret() {
        String secret = preferences.getString("profile_secret", null);
        if (secret == null) {
            byte[] bytes = new byte[24];
            new java.security.SecureRandom().nextBytes(bytes);
            StringBuilder hex = new StringBuilder();
            for (byte b : bytes) hex.append(String.format("%02x", b));
            secret = hex.toString();
            preferences.edit().putString("profile_secret", secret).apply();
        }
        return secret;
    }

    private void setProfileDirty(boolean dirty) {
        profileDirty = dirty;
        preferences.edit().putBoolean("profile_dirty", dirty).apply();
    }

    /** Call after the name or interests change. Nothing is shared before the first join. */
    private void onProfileChanged() {
        profileVersion++;
        if (!preferences.getBoolean("profile_shared", false)) return;
        setProfileDirty(true);
        syncProfile(null);
    }

    private void toggleJoin(Event event) {
        boolean joining = !joinedEvents.contains(event.id);
        if (joining) joinedEvents.add(event.id);
        else joinedEvents.remove(event.id);
        // The server keeps up to 100 joined events per person; drop the oldest beyond that.
        Iterator<String> oldest = joinedEvents.iterator();
        while (joinedEvents.size() > 100 && oldest.hasNext()) {
            oldest.next();
            oldest.remove();
        }
        JSONArray joinedList = new JSONArray();
        for (String id : joinedEvents) joinedList.put(id);
        preferences.edit().putString("joined_events_list", joinedList.toString())
                .remove("joined_events").putBoolean("profile_shared", true).apply();
        if (joining) selectedEventId = event.id;
        else if (event.id.equals(selectedEventId)) selectedEventId = null;
        matchReady = false;
        currentMatches.clear();
        attendeesByEvent.remove(event.id);
        profileVersion++;
        setProfileDirty(true);
        if (eventsServer.isEmpty()) {
            Toast.makeText(this, joining ? "You’re going! Saved on this phone." : "You left this event.",
                    Toast.LENGTH_SHORT).show();
            render();
            return;
        }
        syncProfile((saved, error) -> {
            if (saved == null) {
                Toast.makeText(this, "Saved on this phone. " + error + " MeetMate will try again later.",
                        Toast.LENGTH_LONG).show();
                rerenderIf("Event");
                return;
            }
            Toast.makeText(this, joining
                            ? "You’re going! People going can now see your name and interests."
                            : "You left this event.", Toast.LENGTH_SHORT).show();
            refreshEvents(false);
        });
        render();
    }

    /** First letter of a name, used as the avatar for real people. */
    private static String initial(String name) {
        String trimmed = name.trim();
        if (trimmed.isEmpty()) return "?";
        int end = trimmed.offsetByCodePoints(0, 1);
        return trimmed.substring(0, end).toUpperCase(java.util.Locale.ROOT);
    }

    private static boolean isWebLink(String url) {
        if (url == null || url.isEmpty()) return false;
        String scheme = Uri.parse(url).getScheme();
        return "https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme);
    }

    private static String linkHost(String url) {
        String host = Uri.parse(url).getHost();
        if (host == null) return url;
        return host.startsWith("www.") ? host.substring(4) : host;
    }

    /** Opens http(s) links only, in the browser. */
    private void openLink(String url) {
        if (!isWebLink(url)) return;
        Intent view = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        view.addCategory(Intent.CATEGORY_BROWSABLE);
        try {
            startActivity(view);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "No browser is available on this phone.", Toast.LENGTH_LONG).show();
        }
    }

    private void openMap(Event event) {
        String place = (event.hasVenue() ? event.location + ", " : "") + event.address;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))));
        } catch (ActivityNotFoundException error) {
            openLink("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(place));
        }
    }

    private void shareEvent(Event event) {
        StringBuilder text = new StringBuilder(event.name).append('\n').append(event.longWhen());
        if (event.hasVenue()) text.append('\n').append(event.location);
        if (!event.address.isEmpty()) text.append(event.hasVenue() ? ", " : "\n").append(event.address);
        String link = isWebLink(event.sourceUrl) ? event.sourceUrl
                : isWebLink(event.ticketUrl) ? event.ticketUrl : "";
        if (!link.isEmpty()) text.append('\n').append(link);
        text.append("\n\nShared from MeetMate · Timișoara");
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, event.name);
        send.putExtra(Intent.EXTRA_TEXT, text.toString());
        try {
            startActivity(Intent.createChooser(send, "Share event"));
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "No app can share this event.", Toast.LENGTH_SHORT).show();
        }
    }

    private static class LocalPerson {
        final String name;
        final String emoji;
        final List<String> interests;

        LocalPerson(String name, String emoji, String... interests) {
            this(name, emoji, Arrays.asList(interests));
        }

        LocalPerson(String name, String emoji, List<String> interests) {
            this.name = name;
            this.emoji = emoji;
            this.interests = new ArrayList<>(interests);
        }

        List<String> sharedInterests(Set<String> selected) {
            Set<String> mine = new HashSet<>();
            for (String interest : selected) mine.add(interest.toLowerCase(java.util.Locale.ROOT));
            List<String> shared = new ArrayList<>();
            for (String interest : interests) {
                if (mine.contains(interest.toLowerCase(java.util.Locale.ROOT))
                        && !shared.contains(interest)) {
                    shared.add(interest);
                }
            }
            return shared;
        }

        String sharedInterestsText(Set<String> selected) {
            List<String> shared = sharedInterests(selected);
            for (int i = 0; i < shared.size(); i++) {
                shared.set(i, shared.get(i).toLowerCase(java.util.Locale.ROOT));
            }
            return TextUtils.join(", ", shared);
        }
    }

    private static class LocalChat {
        final String id;
        /** Event ID for chats made since real events arrived; empty for older chats. */
        final String eventId;
        final String eventName;
        final List<String> memberNames;
        final List<LocalMessage> messages = new ArrayList<>();
        final Map<String, Integer> ratings = new LinkedHashMap<>();
        boolean hangoutCompleted;

        LocalChat(String id, String eventId, String eventName, List<String> memberNames) {
            this.id = id;
            this.eventId = eventId == null ? "" : eventId;
            this.eventName = eventName;
            this.memberNames = new ArrayList<>(memberNames);
        }

        String lastMessage() {
            return messages.isEmpty() ? "No messages yet"
                    : messages.get(messages.size() - 1).text;
        }

        String memberNamesText() {
            return memberNames.isEmpty() ? "Your event crew" : TextUtils.join(", ", memberNames);
        }
    }

    private static class LocalMessage {
        final String senderName;
        final String text;
        final boolean own;

        LocalMessage(String senderName, String text, boolean own) {
            this.senderName = senderName;
            this.text = text;
            this.own = own;
        }
    }

}
