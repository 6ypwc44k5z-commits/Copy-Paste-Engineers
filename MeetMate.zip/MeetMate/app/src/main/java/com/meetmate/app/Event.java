package com.meetmate.app;

import android.graphics.Color;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** One Timișoara event, as served by the MeetMate events API or bundled in the app. */
final class Event {
    static final ZoneId TIMISOARA = ZoneId.of("Europe/Bucharest");
    /** Location the backend uses when a listing doesn't name a venue. */
    static final String DEFAULT_LOCATION = "Timișoara, Romania";
    /** Explore filter order. */
    static final String[] CATEGORIES = {"Food", "Theatre", "Music", "Art", "Books", "Other"};

    private static final DateTimeFormatter SHORT_DAY =
            DateTimeFormatter.ofPattern("EEE d MMM", Locale.ENGLISH);
    private static final DateTimeFormatter LONG_DAY =
            DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.ENGLISH);
    private static final DateTimeFormatter TIME =
            DateTimeFormatter.ofPattern("HH:mm", Locale.ENGLISH);

    final String id;
    final String name;
    final String description;
    final String location;
    final String address;
    final String sourceUrl;
    final String ticketUrl;
    /** https link to the listing's photo, or "" */
    final String imageUrl;
    final ZonedDateTime start;
    final List<String> tags;
    final String category;
    /** People who joined through MeetMate, or -1 when the server didn't say. */
    final int attendeeCount;

    private Event(String id, String name, String description, String location, String address,
                  String sourceUrl, String ticketUrl, String imageUrl, ZonedDateTime start,
                  List<String> tags, int attendeeCount) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.location = location;
        this.address = address;
        this.sourceUrl = sourceUrl;
        this.ticketUrl = ticketUrl;
        this.imageUrl = imageUrl;
        this.start = start;
        this.tags = Collections.unmodifiableList(tags);
        this.category = categoryOf(tags);
        this.attendeeCount = attendeeCount;
    }

    /** Returns null for listings without an ID, title or readable start time. */
    static Event fromJson(JSONObject json) {
        String id = text(json, "id", 64);
        String title = text(json, "title", 200);
        ZonedDateTime start = parseStart(text(json, "date", 40));
        if (id.isEmpty() || title.isEmpty() || start == null) return null;
        List<String> tags = new ArrayList<>();
        JSONArray tagArray = json.optJSONArray("tags");
        if (tagArray != null) {
            for (int i = 0; i < tagArray.length() && tags.size() < 20; i++) {
                String tag = tagArray.isNull(i) ? "" : tagArray.optString(i, "").trim();
                if (!tag.isEmpty() && tag.length() <= 64) tags.add(tag);
            }
        }
        int count = json.has("attendee_count") && !json.isNull("attendee_count")
                ? json.optInt("attendee_count", -1) : -1;
        return new Event(id, title,
                text(json, "description", 2000),
                text(json, "location", 200),
                text(json, "address", 200),
                link(text(json, "source_url", 1000)),
                link(text(json, "ticket_url", 1000)),
                photo(link(text(json, "image_url", 1000))),
                start, tags, count);
    }

    private static String text(JSONObject json, String key, int maxLength) {
        if (!json.has(key) || json.isNull(key)) return "";
        // Drop invisible text-direction controls, which can make text look like something else.
        String value = json.optString(key, "")
                .replaceAll("[\\u202A-\\u202E\\u2066-\\u2069\\u200E\\u200F]", "").trim();
        return value.length() > maxLength ? value.substring(0, maxLength) : value;
    }

    /** Some listings arrive HTML-escaped ("&amp;"). */
    private static String link(String url) {
        return url.replace("&amp;", "&");
    }

    /** Only https photos; the placeholder image used for hand-added events is skipped. */
    private static String photo(String url) {
        return url.startsWith("https://") && !url.contains("placehold.co") ? url : "";
    }

    private static ZonedDateTime parseStart(String value) {
        if (value.isEmpty()) return null;
        try {
            return OffsetDateTime.parse(value).atZoneSameInstant(TIMISOARA);
        } catch (java.time.DateTimeException ignored) {
            // Events added by hand may have no UTC offset; they are Timișoara local time.
        }
        try {
            return LocalDateTime.parse(value).atZone(TIMISOARA);
        } catch (java.time.DateTimeException ignored) {
            // Fall through to a date without a time.
        }
        try {
            return LocalDate.parse(value).atStartOfDay(TIMISOARA);
        } catch (java.time.DateTimeException ignored) {
            return null;
        }
    }

    private static String categoryOf(List<String> tags) {
        boolean food = false, music = false, books = false, art = false, theatre = false;
        for (String tag : tags) {
            String t = tag.toLowerCase(Locale.ROOT);
            // Visit Timișoara: food-drink-en, gastronomie-si-experiente-culinare
            if (t.contains("food") || t.contains("drink") || t.contains("gastronom")
                    || t.contains("culinar") || t.contains("wine") || t.contains("vin-")) food = true;
            if (t.contains("music") || t.contains("concert") || t.contains("muzic")) music = true;
            if (t.contains("literat") || t.contains("book") || t.contains("carte")) books = true;
            if (t.contains("exhibition") || t.startsWith("arts") || t.contains("expozi")) art = true;
            if (t.contains("theatre") || t.contains("teatru") || t.contains("performance")
                    || t.contains("spectacol") || t.contains("opera")) theatre = true;
        }
        if (food) return "Food";
        if (music) return "Music";
        if (books) return "Books";
        if (art) return "Art";
        if (theatre) return "Theatre";
        return "Other";
    }

    String label() {
        switch (category) {
            case "Food": return "FOOD & DRINK";
            case "Theatre": return "THEATRE & OPERA";
            case "Music": return "LIVE MUSIC";
            case "Art": return "ART & EXHIBITIONS";
            case "Books": return "BOOKS & TALKS";
            default: return "IN TIMIȘOARA";
        }
    }

    String emoji() {
        switch (category) {
            case "Food": return "🍽";
            case "Theatre": return "🎭";
            case "Music": return "🎵";
            case "Art": return "🎨";
            case "Books": return "📚";
            default: return "📍";
        }
    }

    /** Poster colour behind the event number. */
    int color() {
        switch (category) {
            case "Food": return Color.rgb(196, 98, 45);
            case "Theatre": return Color.parseColor("#333388");
            case "Music": return Color.rgb(70, 83, 91);
            case "Art": return Color.rgb(143, 91, 79);
            case "Books": return Color.rgb(104, 124, 87);
            default: return Color.rgb(207, 123, 80);
        }
    }

    boolean hasVenue() {
        return !location.isEmpty() && !location.equals(DEFAULT_LOCATION);
    }

    /** Short place name for cards. */
    String place() {
        return hasVenue() ? location : "Timișoara";
    }

    boolean isUpcoming(ZonedDateTime now) {
        return start.isAfter(now.minusHours(3));
    }

    /** "Today · 18:00", "Tomorrow · 19:30" or "Sat 21 Nov · 19:00", in Timișoara time. */
    String when(ZonedDateTime now) {
        LocalDate day = start.toLocalDate();
        LocalDate today = now.withZoneSameInstant(TIMISOARA).toLocalDate();
        String dayText = day.equals(today) ? "Today"
                : day.equals(today.plusDays(1)) ? "Tomorrow" : SHORT_DAY.format(start);
        return dayText + " · " + TIME.format(start);
    }

    /** "Sunday 15 November · 18:00" */
    String longWhen() {
        return LONG_DAY.format(start) + " · " + TIME.format(start);
    }

    /** Tags such as "theatre-and-opera-en" as "Theatre and opera". */
    List<String> readableTags() {
        Set<String> readable = new LinkedHashSet<>();
        for (String tag : tags) {
            String t = tag.replaceAll("-(en|ro)$", "").replace('-', ' ').trim();
            if (t.isEmpty()) continue;
            readable.add(Character.toUpperCase(t.charAt(0)) + t.substring(1));
        }
        return new ArrayList<>(readable);
    }

    String searchText() {
        return (name + " " + label() + " " + category + " " + location + " " + address + " "
                + description + " " + String.join(" ", readableTags())).toLowerCase(Locale.ROOT);
    }
}
