package com.meetmate.app;

import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Talks to the MeetMate events API (api-mcp-share/api.py) on a background thread.
 * Callbacks run on the main thread with either a result or a user-facing error.
 */
final class EventsApi {
    interface Callback<T> {
        void done(T result, String error);
    }

    /** Someone who joined an event, as returned by the server. */
    static final class Person {
        final String id;
        final String name;
        final List<String> interests;

        Person(String id, String name, List<String> interests) {
            this.id = id;
            this.name = name;
            this.interests = interests;
        }
    }

    static final class EventList {
        final List<Event> events;
        /** The raw response, saved so the list is available offline. */
        final String json;

        EventList(List<Event> events, String json) {
            this.events = events;
            this.json = json;
        }
    }

    static final int MAX_RESPONSE_BYTES = 2_000_000;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService IO = Executors.newFixedThreadPool(2);

    private EventsApi() {}

    /** Accepts "192.168.1.20:8000" or a full http(s) address; returns null if unusable. */
    static String normalizeServer(String input) {
        if (input == null) return null;
        String value = input.trim();
        if (value.isEmpty()) return null;
        if (!value.contains("://")) value = "http://" + value;
        Uri uri = Uri.parse(value);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        String host = uri.getHost();
        if (!(scheme.equals("http") || scheme.equals("https")) || host == null || host.isEmpty()) {
            return null;
        }
        while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        return value;
    }

    static List<Event> parseEvents(String json) throws JSONException {
        checkDepth(json);
        JSONArray array = new JSONArray(json);
        List<Event> events = new ArrayList<>();
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (int i = 0; i < array.length() && events.size() < 200; i++) {
            JSONObject item = array.optJSONObject(i);
            Event event = item == null ? null : Event.fromJson(item);
            if (event != null && seen.add(event.id)) events.add(event);
        }
        return events;
    }

    /**
     * org.json parses nested arrays recursively, so very deep input ("[[[[...") would
     * overflow the stack and crash the app. Reject anything nested deeper than 32 levels.
     */
    static void checkDepth(String json) throws JSONException {
        int depth = 0;
        boolean inString = false;
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (inString) {
                if (c == '\\') i++;
                else if (c == '"') inString = false;
            } else if (c == '"') {
                inString = true;
            } else if (c == '[' || c == '{') {
                if (++depth > 32) throw new JSONException("Data is nested too deeply");
            } else if (c == ']' || c == '}') {
                depth--;
            }
        }
    }

    private static String checked(String json) throws JSONException {
        checkDepth(json);
        return json;
    }

    static void fetchEvents(String server, Callback<EventList> callback) {
        run(callback, () -> {
            String json = request("GET", server + "/events", null);
            return new EventList(parseEvents(json), json);
        });
    }

    static void fetchAttendees(String server, String eventId, Callback<List<Person>> callback) {
        run(callback, () -> parsePeople(new JSONObject(
                checked(request("GET", server + "/events/" + Uri.encode(eventId), null)))
                .optJSONArray("attendees")));
    }

    /** Sends the profile; the app only includes its random ID, name, interests and events. */
    static void saveProfile(String server, JSONObject profile, Callback<Boolean> callback) {
        run(callback, () -> {
            request("POST", server + "/users", profile.toString());
            return Boolean.TRUE;
        });
    }

    static void matchPeople(String server, String eventId, String userId,
                            Callback<List<Person>> callback) {
        run(callback, () -> parsePeople(new JSONArray(checked(request("GET", server
                + "/match/people/" + Uri.encode(eventId) + "/" + Uri.encode(userId), null)))));
    }

    static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int read;
        while ((read = in.read(chunk)) != -1) {
            if (buffer.size() + read > MAX_RESPONSE_BYTES) throw new IOException("Too much data");
            buffer.write(chunk, 0, read);
        }
        return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
    }

    private static List<Person> parsePeople(JSONArray array) {
        List<Person> people = new ArrayList<>();
        if (array == null) return people;
        for (int i = 0; i < array.length() && people.size() < 200; i++) {
            JSONObject item = array.optJSONObject(i);
            if (item == null || item.isNull("name")) continue;
            String name = item.optString("name", "").trim();
            if (name.isEmpty()) continue;
            if (name.length() > 60) name = name.substring(0, 60);
            String id = item.isNull("id") ? "" : item.optString("id", "");
            List<String> interests = new ArrayList<>();
            JSONArray list = item.optJSONArray("interests");
            if (list != null) {
                for (int j = 0; j < list.length() && interests.size() < 20; j++) {
                    String interest = list.isNull(j) ? "" : list.optString(j, "").trim();
                    if (!interest.isEmpty()) interests.add(interest);
                }
            }
            people.add(new Person(id, name, interests));
        }
        return people;
    }

    private interface Work<T> {
        T call() throws IOException, JSONException;
    }

    private static <T> void run(Callback<T> callback, Work<T> work) {
        IO.execute(() -> {
            T result = null;
            String error = null;
            try {
                result = work.call();
            } catch (HttpError e) {
                error = "The events server answered with error " + e.code + ".";
            } catch (IOException e) {
                error = "Can’t reach the events server.";
            } catch (JSONException | RuntimeException | StackOverflowError | OutOfMemoryError e) {
                error = "The events server sent data the app can’t read.";
            }
            final T finalResult = result;
            final String finalError = error;
            MAIN.post(() -> callback.done(finalResult, finalError));
        });
    }

    private static final class HttpError extends IOException {
        final int code;

        HttpError(int code) {
            super("HTTP " + code);
            this.code = code;
        }
    }

    private static String request(String method, String url, String body) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        try {
            connection.setRequestMethod(method);
            connection.setConnectTimeout(6000);
            // The server may refresh from Visit Timișoara before answering.
            connection.setReadTimeout(20000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Accept", "application/json");
            if (body != null) {
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = connection.getOutputStream()) {
                    out.write(bytes);
                }
            }
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new HttpError(status);
            try (InputStream in = connection.getInputStream()) {
                return readAll(in);
            }
        } finally {
            connection.disconnect();
        }
    }
}
