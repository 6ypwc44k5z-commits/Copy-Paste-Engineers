"""Saves reports sent from the app and emails them to the developer.

Email settings come from environment variables only, so no password is ever stored in
the shared project folder or inside the app:

    MEETMATE_REPORT_TO      developer address that receives reports (required for email)
    MEETMATE_SMTP_USER      account used to send, e.g. a Gmail address
    MEETMATE_SMTP_PASSWORD  its password; for Gmail an app password
    MEETMATE_SMTP_HOST      default smtp.gmail.com
    MEETMATE_SMTP_PORT      default 587 (STARTTLS); 465 uses SSL
    MEETMATE_REPORT_FROM    sender shown in the email, default MEETMATE_SMTP_USER
"""

import json
import logging
import os
import smtplib
import ssl
import threading
from email.message import EmailMessage
from pathlib import Path
from typing import Any

LOGGER = logging.getLogger(__name__)
REPORTS_PATH = Path(__file__).resolve().parent / "data" / "reports.jsonl"
LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}
_lock = threading.Lock()


def save_report(report: dict[str, Any]) -> None:
    """Append the report to data/reports.jsonl so none are lost if email fails."""
    with _lock:
        REPORTS_PATH.parent.mkdir(parents=True, exist_ok=True)
        with REPORTS_PATH.open("a", encoding="utf-8") as reports_file:
            reports_file.write(json.dumps(report, ensure_ascii=False) + "\n")


def email_configured() -> bool:
    return bool(os.environ.get("MEETMATE_REPORT_TO", "").strip())


def send_report_email(subject: str, body: str) -> bool:
    """Returns True when sent, False when email isn't configured. Raises on SMTP errors."""
    recipient = os.environ.get("MEETMATE_REPORT_TO", "").strip()
    if not recipient:
        return False
    host = os.environ.get("MEETMATE_SMTP_HOST", "smtp.gmail.com").strip()
    port = int(os.environ.get("MEETMATE_SMTP_PORT", "587"))
    user = os.environ.get("MEETMATE_SMTP_USER", "").strip()
    password = os.environ.get("MEETMATE_SMTP_PASSWORD", "")
    sender = os.environ.get("MEETMATE_REPORT_FROM", "").strip() or user or recipient

    message = EmailMessage()
    # Subjects come from a fixed list in api.py; strip line breaks anyway.
    message["Subject"] = " ".join(subject.split())
    message["From"] = sender
    message["To"] = recipient
    message.set_content(body)

    context = ssl.create_default_context()
    if port == 465:
        with smtplib.SMTP_SSL(host, port, context=context, timeout=20) as smtp:
            if user:
                smtp.login(user, password)
            smtp.send_message(message)
        return True
    with smtplib.SMTP(host, port, timeout=20) as smtp:
        # Require encryption for any real mail server, so the password is never sent in
        # plain text. Only a test server on this computer may skip it.
        if host not in LOCAL_HOSTS:
            smtp.starttls(context=context)
        if user:
            smtp.login(user, password)
        smtp.send_message(message)
    return True
