import re
import uuid
from datetime import datetime
from typing import Any

from mcp.server.fastmcp import FastMCP

from data_store import add_event, read_users, without_secret
from event_service import get_events

mcp = FastMCP("meetmate-events")


def _profile_tags(user: dict[str, Any], event_tags: set[str]) -> set[str]:
    bio_words = set(re.findall(r"[a-z0-9]+", user["bio"].lower()))
    interests = {interest.lower() for interest in user["interests"]}
    return interests | (bio_words & event_tags)


def _score(shared_count: int, total_count: int) -> int:
    if total_count == 0:
        return 0
    return round(shared_count / total_count * 100)


@mcp.tool()
def search_events(tag: str | None = None, query: str | None = None) -> list[dict[str, Any]]:
    """Search events by an optional tag and/or title or description keyword."""
    events, _ = get_events()
    if tag:
        normalized_tag = tag.strip().lower()
        events = [
            event
            for event in events
            if normalized_tag in [event_tag.lower() for event_tag in event["tags"]]
        ]
    if query:
        keyword = query.strip().lower()
        events = [
            event
            for event in events
            if keyword in event["title"].lower()
            or keyword in event["description"].lower()
        ]
    return events


@mcp.tool()
def get_event_attendees(event_id: str) -> dict[str, Any]:
    """Return one event and the profiles of users attending it."""
    events, _ = get_events()
    event = next((item for item in events if item["id"] == event_id), None)
    if event is None:
        return {"error": f"Event not found: {event_id}"}
    attendees = [
        without_secret(user) for user in read_users() if event_id in user["attending_event_ids"]
    ]
    return {"event": event, "attendees": attendees}


@mcp.tool()
def recommend_matches_for_user(user_id: str) -> dict[str, Any]:
    """Recommend up to three events and compatible attendees using profile interests and bio."""
    users = read_users()
    user = next((item for item in users if item["id"] == user_id), None)
    if user is None:
        return {"error": f"User not found: {user_id}"}

    events, _ = get_events()
    all_event_tags = {
        tag.lower()
        for event in events
        for tag in event["tags"]
    }
    user_tags = _profile_tags(user, all_event_tags)
    event_matches = []
    for event in events:
        event_tags = {tag.lower() for tag in event["tags"]}
        shared = sorted(user_tags & event_tags)
        event_matches.append(
            {
                **event,
                "match_score": _score(len(shared), len(user_tags)),
                "shared_interests": shared,
            }
        )
    event_matches.sort(key=lambda event: event["match_score"], reverse=True)

    user_event_ids = set(user["attending_event_ids"])
    people_matches = []
    for candidate in users:
        if candidate["id"] == user_id:
            continue
        shared_events = user_event_ids & set(candidate["attending_event_ids"])
        if not shared_events:
            continue
        candidate_tags = _profile_tags(candidate, all_event_tags)
        shared_interests = sorted(user_tags & candidate_tags)
        combined_tags = user_tags | candidate_tags
        people_matches.append(
            {
                **without_secret(candidate),
                "match_score": _score(len(shared_interests), len(combined_tags)),
                "shared_interests": shared_interests,
                "shared_event_ids": sorted(shared_events),
            }
        )
    people_matches.sort(key=lambda person: person["match_score"], reverse=True)

    return {
        "user_id": user_id,
        "recommended_events": event_matches[:3],
        "compatible_people": people_matches[:3],
    }


@mcp.tool()
def add_new_event(
    title: str,
    description: str,
    date: str,
    location: str,
    tags: list[str],
    address: str = "",
) -> dict[str, Any]:
    """Append a new event with a unique ID; date must be an ISO 8601 datetime."""
    try:
        datetime.fromisoformat(date.replace("Z", "+00:00"))
    except ValueError as error:
        raise ValueError("date must be a valid ISO 8601 datetime") from error
    normalized_tags = sorted({tag.strip().lower() for tag in tags if tag.strip()})
    if not 3 <= len(normalized_tags) <= 5:
        raise ValueError("provide between 3 and 5 non-empty tags")

    event = {
        "id": f"evt-{uuid.uuid4().hex[:12]}",
        "title": title,
        "description": description,
        "date": date,
        "location": location,
        "address": address.strip(),
        "image_url": "https://placehold.co/600x400?text=New+Event",
        "tags": normalized_tags,
    }
    add_event(event)
    return event


if __name__ == "__main__":
    mcp.run(transport="stdio")
