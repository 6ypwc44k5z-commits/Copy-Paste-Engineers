"""Make a QR code image that opens a download link for the MeetMate app.

Use it for a link that works anywhere, for example a OneDrive or Google Drive share link
to apk/MeetMate.apk (set the link to "Anyone with the link can view"):

    python make_apk_qr.py "https://...your share link..."

The image is saved as apk/MeetMate-QR.png next to the APK. To install over the local
Wi-Fi instead, start the API and open http://127.0.0.1:8000/install on this computer.
"""

import sys
from pathlib import Path

import segno

OUTPUT = Path(__file__).resolve().parent.parent / "apk" / "MeetMate-QR.png"


def main() -> None:
    if len(sys.argv) != 2 or not sys.argv[1].startswith(("https://", "http://")):
        raise SystemExit('Usage: python make_apk_qr.py "https://link-to-MeetMate.apk"')
    link = sys.argv[1]
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    segno.make(link, error="m").save(OUTPUT, scale=12, border=4, dark="#000033")
    print(f"Saved {OUTPUT.relative_to(OUTPUT.parent.parent)} for {link}")


if __name__ == "__main__":
    main()
