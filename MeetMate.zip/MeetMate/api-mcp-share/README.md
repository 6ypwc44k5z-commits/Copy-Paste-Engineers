# MeetMate events backend (Timișoara)

This folder holds the backend for the MeetMate Android app: a REST API the app talks to,
and an MCP server that lets an AI assistant (Kiro, GitHub Copilot) search the same events.

## Where the events come from

Events come from Visit Timișoara's public events feed and are cached in
`data/events.sqlite3` (schema in `database/schema.sql`). The cache refreshes on the first
request and then every 30 minutes, reading at most the 500 newest listings and keeping the
30 soonest upcoming events. Concerts from the Banatul Philharmonic (next 60 days, up to 15) come from the Philharmonic's own events API (`philharmonic_source.py`). If the feed is down, cached events are served with the
`X-Events-Stale: true` header; with no cache the API returns HTTP 503.

The feed has no venue or street address, so these are filled in by hand in
`data/event_addresses.csv` (columns `location`, `address`, `description`; empty cells are
skipped). Venues were checked on the organisers' and ticket sellers' own pages. Events
announced only on Facebook have no venue yet. Import the CSV after editing it:

```sh
python import_event_addresses.py data/event_addresses.csv
```

Imported venues, addresses and descriptions are kept when the live feed refreshes.
`database/events.sql` is an SQL export of the current events.

People who join events in the app are stored in `data/users.json`. The app sends only a
random ID, the display name, interests and joined event IDs, never age, email or phone.

## Set up (Python 3.10 or newer)

Keep the virtual environment outside this OneDrive folder: it contains your computer's
file paths. Set `PYTHONDONTWRITEBYTECODE=1` when running so Python doesn't write
`__pycache__` files (which also record file paths) into the shared folder.

macOS / Linux:

```sh
python3 -m venv ~/.cache/meetmate-api-venv
~/.cache/meetmate-api-venv/bin/python -m pip install -r requirements.txt
```

Windows (PowerShell):

```powershell
python -m venv $HOME\.cache\meetmate-api-venv
& $HOME\.cache\meetmate-api-venv\Scripts\python.exe -m pip install -r requirements.txt
```

## Run the API for the app

Phones reach the API over the Wi-Fi, so listen on all network interfaces:

```sh
PYTHONDONTWRITEBYTECODE=1 ~/.cache/meetmate-api-venv/bin/python -m uvicorn api:app --host 0.0.0.0 --port 8000
```

Then, in the app, open **Settings → Timișoara events**, enter this computer's Wi-Fi
address with the port (for example `192.168.1.20:8000`) and tap **Connect**. The phone
and the computer must be on the same network, and the computer's firewall must allow
incoming connections on port 8000. On the Android emulator use `10.0.2.2:8000`.

The API has no login: anyone on the same network can read who joined which event and
change profiles. Use it on a trusted network for demos.

Interactive documentation: `http://127.0.0.1:8000/docs`.

| Endpoint | What it does |
|---|---|
| `GET /events` | Upcoming events with venue, address, links and `attendee_count` |
| `GET /events/{id}` | One event and the people who joined it |
| `POST /users` | Saves a profile and the events it joined |
| `GET /match/people/{event_id}/{user_id}` | People at the same event, ranked by shared interests |
| `GET /match/events/{user_id}` | Events ranked by the user's interests |

## Installing the app with a QR code

While the server runs, open `http://127.0.0.1:8000/install` on this computer. The page
shows a QR code for `/download/MeetMate.apk` using this computer's Wi-Fi address; phones
on the same Wi-Fi scan it to download and install the app. The page also shows the
server address to enter in the app's Settings.

For a link that works without the server (for example a OneDrive share link to
`apk/MeetMate.apk`), run `python make_apk_qr.py "https://..."` to create
`apk/MeetMate-QR.png`.

## Reports sent by email

Bug reports, fix suggestions, support requests and safety reports from the app go to
`POST /reports`. Each report is saved to `data/reports.jsonl` and emailed to the
developer. Each device can send up to 5 reports per 10 minutes, and the server accepts
up to 200 a day.

Email settings are read from environment variables when the server starts, so no password
is stored in this folder or in the app. With Gmail, turn on 2-step verification and create
an app password at <https://myaccount.google.com/apppasswords>, then start the server with:

```sh
export MEETMATE_REPORT_TO="developer@example.com"      # who receives reports
export MEETMATE_SMTP_USER="sending.account@gmail.com"  # account that sends them
export MEETMATE_SMTP_PASSWORD="the 16-letter app password"
PYTHONDONTWRITEBYTECODE=1 ~/.cache/meetmate-api-venv/bin/python -m uvicorn api:app --host 0.0.0.0 --port 8000
```

Other mail providers: also set `MEETMATE_SMTP_HOST` and `MEETMATE_SMTP_PORT` (587 for
STARTTLS, 465 for SSL). Without `MEETMATE_REPORT_TO`, reports are only saved to
`data/reports.jsonl`. Reports are sent without the sender's profile or contact details.

## MCP server

`mcp_server.py` is a stdio MCP server named `meetmate-events` with these tools:
`search_events`, `get_event_attendees`, `recommend_matches_for_user` (read-only) and
`add_new_event` (adds an event to the database).

**Kiro:** add this to `.kiro/settings/mcp.json` in the project root (or to your user-level
`~/.kiro/settings/mcp.json`). It assumes the virtual environment location above and works on
macOS and Linux:

```json
{
  "mcpServers": {
    "meetmate-events": {
      "command": "sh",
      "args": ["-c", "cd api-mcp-share && exec \"$HOME/.cache/meetmate-api-venv/bin/python\" mcp_server.py"],
      "env": { "PYTHONDONTWRITEBYTECODE": "1" },
      "autoApprove": ["search_events", "get_event_attendees", "recommend_matches_for_user"]
    }
  }
}
```

**VS Code (GitHub Copilot):** `.vscode/mcp.json` starts the server with a `.venv` inside
this folder on Windows.

To test with the MCP Inspector (needs Node.js):

```sh
npx -y @modelcontextprotocol/inspector ~/.cache/meetmate-api-venv/bin/python mcp_server.py
```
