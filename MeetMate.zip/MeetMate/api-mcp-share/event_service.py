import logging
import threading
from typing import Any

from data_store import event_sync_is_due, read_events, replace_external_events
from event_source import EventSourceError, fetch_live_events
from philharmonic_source import SOURCE as PHILHARMONIC_SOURCE
from philharmonic_source import PhilharmonicSourceError, fetch_concerts

LOGGER = logging.getLogger(__name__)
SYNC_INTERVAL_SECONDS = 30 * 60
_sync_lock = threading.Lock()


def get_events() -> tuple[list[dict[str, Any]], bool]:
    cached_events = read_events()
    if not event_sync_is_due(SYNC_INTERVAL_SECONDS):
        return cached_events, False

    with _sync_lock:
        cached_events = read_events()
        if not event_sync_is_due(SYNC_INTERVAL_SECONDS):
            return cached_events, False
        try:
            live_events = fetch_live_events()
        except EventSourceError as error:
            if not cached_events:
                raise
            LOGGER.warning("Event feed refresh failed; serving cached events: %s", error)
            return cached_events, True
        # Concerts are a second, optional source: if it fails, its last list stays.
        try:
            replace_external_events(fetch_concerts(), PHILHARMONIC_SOURCE, mark_synced=False)
        except PhilharmonicSourceError as error:
            LOGGER.warning("Philharmonic refresh failed; keeping saved concerts: %s", error)
        replace_external_events(live_events)
        return read_events(), False
