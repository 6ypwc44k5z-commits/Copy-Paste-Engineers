"""Concerts from the Banatul Philharmonic Timișoara (filarmonicabanatul.ro).

The Philharmonic publishes its programme through the public events API of its website
(The Events Calendar for WordPress). Each concert comes with its venue, street address,
photo and ticket link. Only facts are kept (title, performers, time, place, links); the
full programme notes stay on the Philharmonic's page, which the app links to.
"""

import html
import json
import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Callable
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

LOGGER = logging.getLogger(__name__)
API_URL = "https://www.filarmonicabanatul.ro/wp-json/tribe/events/v1/events"
SOURCE = "filarmonica-banatul"
# Keep the app list focused: the next two months, at most this many concerts.
DAYS_AHEAD = 60
MAX_CONCERTS = 15
REQUEST_TIMEOUT_SECONDS = 8
BUCHAREST = ZoneInfo("Europe/Bucharest")


class PhilharmonicSourceError(RuntimeError):
    pass


def _text(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]*>", " ", value))).strip()


def _https(value: Any) -> str:
    url = _text(value)
    return url if url.startswith("https://") else ""


def _photo(image: Any) -> str:
    """A phone-sized version of the photo (about 1000 px wide) instead of the 2560 px original."""
    if not isinstance(image, dict):
        return ""
    sizes = image.get("sizes") if isinstance(image.get("sizes"), dict) else {}
    for name in ("large", "et-pb-image--responsive--tablet", "medium_large"):
        size = sizes.get(name)
        if isinstance(size, dict) and _https(size.get("url")):
            return _https(size.get("url"))
    return _https(image.get("url"))


def normalize_concert(item: dict[str, Any], now: datetime) -> dict[str, Any] | None:
    try:
        start_utc = datetime.strptime(item["utc_start_date"], "%Y-%m-%d %H:%M:%S")
    except (KeyError, TypeError, ValueError):
        return None
    start = start_utc.replace(tzinfo=timezone.utc).astimezone(BUCHAREST)
    if start <= now or start > now + timedelta(days=DAYS_AHEAD):
        return None
    if item.get("hide_from_listings") or item.get("status") != "publish":
        return None

    parts = [part.strip() for part in _text(item.get("title")).split("|") if part.strip()]
    if not parts or item.get("id") is None:
        return None
    title = parts[0]
    if title.isupper():
        # The Philharmonic writes titles in capitals; show them in sentence case.
        title = title[0] + title[1:].lower()
    credits = "; ".join(parts[1:])

    venue = item.get("venue") if isinstance(item.get("venue"), dict) else {}
    venue_name = _text(venue.get("venue"))
    street = _text(venue.get("address"))
    city = _text(venue.get("city"))
    if not city or city == "None":
        city = "Timișoara"
    postcode = _text(venue.get("zip"))
    address = ", ".join(part for part in (street, f"{postcode} {city}".strip()) if part)

    description = "Concert by the Banatul Philharmonic Timișoara."
    if credits:
        description += " " + credits + "."
    description += " Programme notes and tickets on the Philharmonic's page."

    return {
        "id": f"fb-{item['id']}",
        "title": title,
        "description": description,
        "date": start.isoformat(),
        "location": venue_name or "Timișoara, Romania",
        "address": address if street else "",
        "image_url": _photo(item.get("image")),
        "tags": ["classical-music", "concert-en", "music-en"],
        "source_url": _https(item.get("url")),
        "ticket_url": _https(item.get("website")),
    }


def fetch_concerts(
    now: datetime | None = None,
    open_url: Callable[..., Any] = urlopen,
) -> list[dict[str, Any]]:
    current = (now or datetime.now(timezone.utc)).astimezone(BUCHAREST)
    query = urlencode({"per_page": 50, "start_date": current.strftime("%Y-%m-%d %H:%M:%S")})
    request = Request(
        f"{API_URL}?{query}",
        headers={"Accept": "application/json", "User-Agent": "MeetMate/1.0"},
    )
    try:
        with open_url(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (URLError, TimeoutError, UnicodeDecodeError, ValueError) as error:
        raise PhilharmonicSourceError(f"Could not read the Philharmonic programme: {error}") from error
    items = payload.get("events") if isinstance(payload, dict) else None
    if not isinstance(items, list):
        raise PhilharmonicSourceError("The Philharmonic returned an invalid event list")
    concerts = [
        concert
        for item in items
        if isinstance(item, dict)
        for concert in [normalize_concert(item, current)]
        if concert is not None
    ]
    return sorted(concerts, key=lambda concert: concert["date"])[:MAX_CONCERTS]
