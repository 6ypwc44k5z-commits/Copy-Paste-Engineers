import json
import logging
import re
from datetime import datetime, time, timezone
from html import unescape
from typing import Any, Callable
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

LOGGER = logging.getLogger(__name__)
API_URL = "https://visit-timisoara.com/wp-json/wp/v2/events-visit"
MEDIA_URL = "https://visit-timisoara.com/wp-json/wp/v2/media"
PAGE_SIZE = 100
MAX_PAGES = 5
MAX_EVENTS = 30
REQUEST_TIMEOUT_SECONDS = 8
FIELDS = "id,link,title,meta,event-themes,event-type,class_list,featured_media"
BUCHAREST = ZoneInfo("Europe/Bucharest")


class EventSourceError(RuntimeError):
    pass


def _plain_text(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    return unescape(re.sub(r"<[^>]*>", " ", value)).strip()


def _event_datetime(meta: dict[str, Any]) -> datetime | None:
    try:
        timestamp = int(meta["starting_date"])
    except (KeyError, TypeError, ValueError):
        return None

    start_date = datetime.fromtimestamp(timestamp, BUCHAREST).date()
    start_time = meta.get("starting_time")
    if isinstance(start_time, str) and start_time.strip():
        try:
            parsed_time = time.fromisoformat(start_time.strip())
        except ValueError:
            LOGGER.warning("Ignoring invalid event start time: %r", start_time)
        else:
            return datetime.combine(
                start_date,
                parsed_time.replace(tzinfo=BUCHAREST),
            )
    return datetime.fromtimestamp(timestamp, BUCHAREST)


def normalize_event(
    item: dict[str, Any],
    now: datetime | None = None,
) -> dict[str, Any] | None:
    meta = item.get("meta")
    title_data = item.get("title")
    if not isinstance(meta, dict) or not isinstance(title_data, dict):
        return None

    event_datetime = _event_datetime(meta)
    if event_datetime is None:
        LOGGER.warning("Skipping Visit Timișoara event without a valid start date")
        return None
    current_time = now or datetime.now(timezone.utc)
    if event_datetime <= current_time.astimezone(BUCHAREST):
        return None

    title = _plain_text(title_data.get("rendered"))
    event_id = item.get("id")
    if not title or event_id is None:
        LOGGER.warning("Skipping Visit Timișoara event without an ID or title")
        return None

    classes = item.get("class_list", [])
    if not isinstance(classes, list):
        classes = []
    tags = sorted(
        {
            class_name.removeprefix(prefix)
            for class_name in classes
            for prefix in ("event-themes-", "event-type-")
            if isinstance(class_name, str) and class_name.startswith(prefix)
        }
    )
    description = (
        _plain_text(meta.get("short_description"))
        or _plain_text(meta.get("long_description"))
    )

    return {
        "id": f"vt-{event_id}",
        "title": title,
        "description": description,
        "date": event_datetime.isoformat(),
        "location": _plain_text(meta.get("event_setting"))
        or "Timișoara, Romania",
        "address": "",
        "image_url": _plain_text(meta.get("background_event_list_card_image")),
        # Featured photo ID; fetch_live_events swaps it for the photo's URL.
        "_media_id": item.get("featured_media"),
        "tags": tags,
        # Links can arrive HTML-escaped ("&amp;"); _plain_text unescapes them.
        "source_url": _plain_text(meta.get("link_website_event"))
        or _plain_text(item.get("link")),
        "ticket_url": _plain_text(meta.get("link_tickets_event"))
        or _plain_text(meta.get("link_registration_event_")),
    }


def _fetch_page(
    page: int,
    open_url: Callable[..., Any],
) -> tuple[list[dict[str, Any]], int]:
    query = urlencode(
        {
            "per_page": PAGE_SIZE,
            "page": page,
            "_fields": FIELDS,
        }
    )
    request = Request(
        f"{API_URL}?{query}",
        headers={"Accept": "application/json", "User-Agent": "MeetMate/1.0"},
    )
    try:
        with open_url(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
            payload = json.loads(response.read().decode("utf-8"))
            total_pages = int(response.headers.get("X-WP-TotalPages", "1"))
    except (URLError, TimeoutError, UnicodeDecodeError, ValueError) as error:
        raise EventSourceError(
            f"Could not read the Visit Timișoara event feed: {error}"
        ) from error

    if not isinstance(payload, list) or not all(isinstance(item, dict) for item in payload):
        raise EventSourceError("Visit Timișoara returned an invalid event list")
    return payload, total_pages


def _event_deduplication_key(event: dict[str, Any]) -> str:
    event_date = event["date"]
    ticket_url = str(event.get("ticket_url", "")).strip().lower()
    if ticket_url:
        return f"{ticket_url}|{event_date}"
    source_url = str(event.get("source_url", "")).strip().lower()
    return f"{source_url}|{event_date}" if source_url else event["id"]


def _is_english(event: dict[str, Any]) -> bool:
    return any(tag.endswith("-en") for tag in event["tags"])


def fetch_live_events(
    now: datetime | None = None,
    open_url: Callable[..., Any] = urlopen,
) -> list[dict[str, Any]]:
    events_by_key: dict[str, dict[str, Any]] = {}
    total_pages = 1
    page = 1
    while page <= min(MAX_PAGES, total_pages):
        items, total_pages = _fetch_page(page, open_url)
        if not items:
            break
        for item in items:
            normalized = normalize_event(item, now)
            if normalized is None:
                continue
            key = _event_deduplication_key(normalized)
            previous = events_by_key.get(key)
            if previous is None or (_is_english(normalized) and not _is_english(previous)):
                events_by_key[key] = normalized
        page += 1
    events = sorted(events_by_key.values(), key=lambda event: event["date"])[:MAX_EVENTS]
    _attach_photos(events, open_url)
    return events


def _attach_photos(events: list[dict[str, Any]], open_url: Callable[..., Any]) -> None:
    """Use each listing's featured photo from Visit Timișoara as its image_url.

    Photos are optional: if the media lookup fails, events keep the image they had.
    """
    media_ids = {
        event.get("_media_id")
        for event in events
        if isinstance(event.get("_media_id"), int) and event.get("_media_id") > 0
    }
    photo_urls: dict[int, str] = {}
    if media_ids:
        query = urlencode(
            {
                "include": ",".join(str(media_id) for media_id in sorted(media_ids)),
                "per_page": PAGE_SIZE,
                "_fields": "id,source_url",
            }
        )
        request = Request(
            f"{MEDIA_URL}?{query}",
            headers={"Accept": "application/json", "User-Agent": "MeetMate/1.0"},
        )
        try:
            with open_url(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
                payload = json.loads(response.read().decode("utf-8"))
            for item in payload if isinstance(payload, list) else []:
                url = _plain_text(item.get("source_url")) if isinstance(item, dict) else ""
                if isinstance(item.get("id"), int) and url.startswith("https://"):
                    photo_urls[item["id"]] = url
        except (URLError, TimeoutError, UnicodeDecodeError, ValueError) as error:
            LOGGER.warning("Could not read Visit Timișoara event photos: %s", error)
    for event in events:
        photo = photo_urls.get(event.pop("_media_id", None))
        if photo and not event.get("image_url"):
            event["image_url"] = photo
