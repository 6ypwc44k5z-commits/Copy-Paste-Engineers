import logging
import threading
import time
from collections import Counter, deque
from datetime import datetime, timezone
from typing import Annotated, Any, Literal

from pathlib import Path

from fastapi import FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel, Field

from data_store import ProfileLocked, TooManyUsers, read_users, save_user
from event_service import get_events
from event_source import EventSourceError
from report_mailer import email_configured, save_report, send_report_email

LOGGER = logging.getLogger("meetmate.reports")

app = FastAPI(title="MeetMate Event Matchmaking API (Timișoara)")
# No CORS: the Android app doesn't need it, and allowing every origin would let any
# website make a visitor's browser change profiles on this server.

ShortText = Annotated[str, Field(max_length=64)]


class UserProfile(BaseModel):
    # The app sends a random ID, a display name, interests and joined events only.
    id: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_-]+$")
    name: str = Field(min_length=1, max_length=60)
    university: str = Field(default="", max_length=120)
    bio: str = Field(default="", max_length=500)
    interests: list[ShortText] = Field(default_factory=list, max_length=20)
    attending_event_ids: list[ShortText] = Field(default_factory=list, max_length=100)
    # Random per-device secret; proves later updates come from the same phone.
    secret: str = Field(default="", max_length=128)


def _public(user: dict[str, Any]) -> dict[str, Any]:
    """What other people may see: no secret, and not which other events someone joined."""
    return {key: user.get(key, [] if key == "interests" else "") for key in
            ("id", "name", "university", "bio", "interests")}


class Report(BaseModel):
    kind: Literal["bug", "fix", "support", "safety"]
    message: str = Field(min_length=1, max_length=4000)
    app_version: str = Field(default="", max_length=20)


REPORT_TITLES = {
    "bug": "Bug Report",
    "fix": "Fix Suggestion",
    "support": "Support Request",
    "safety": "Safety Report",
}
MAX_USERS = 2000
PROFILE_SAVES_PER_ADDRESS = 30
PROFILE_SAVES_WINDOW_SECONDS = 10 * 60
_profile_save_times: dict[str, deque] = {}
_profile_lock = threading.Lock()


def _allow_profile_save(address: str) -> bool:
    now = time.monotonic()
    with _profile_lock:
        times = _profile_save_times.setdefault(address, deque())
        while times and now - times[0] > PROFILE_SAVES_WINDOW_SECONDS:
            times.popleft()
        if len(times) >= PROFILE_SAVES_PER_ADDRESS:
            return False
        times.append(now)
        return True


# Reports trigger emails, so limit how many one device (IP address) and everyone can send.
REPORTS_PER_ADDRESS = 5
REPORTS_PER_ADDRESS_WINDOW_SECONDS = 10 * 60
REPORTS_PER_DAY = 200
_report_times: dict[str, deque] = {}
_all_report_times: deque = deque()
_report_lock = threading.Lock()


def _allow_report(address: str) -> bool:
    now = time.monotonic()
    with _report_lock:
        while _all_report_times and now - _all_report_times[0] > 24 * 3600:
            _all_report_times.popleft()
        times = _report_times.setdefault(address, deque())
        while times and now - times[0] > REPORTS_PER_ADDRESS_WINDOW_SECONDS:
            times.popleft()
        if len(times) >= REPORTS_PER_ADDRESS or len(_all_report_times) >= REPORTS_PER_DAY:
            return False
        times.append(now)
        _all_report_times.append(now)
        return True


def _events_for_request(response: Response) -> list[dict[str, Any]]:
    try:
        events, stale = get_events()
    except EventSourceError as error:
        raise HTTPException(
            status_code=503,
            detail=f"Live Timișoara events are unavailable: {error}",
        ) from error
    response.headers["X-Events-Source"] = "Visit-Timisoara"
    response.headers["X-Events-Stale"] = str(stale).lower()
    return events


def _attendee_counts(users: list[dict[str, Any]]) -> Counter:
    return Counter(
        event_id for user in users for event_id in set(user["attending_event_ids"])
    )


def _match_score(shared_count: int, total_count: int) -> int:
    if total_count == 0:
        return 0
    return round(shared_count / total_count * 100)


@app.get("/events")
def list_events(
    response: Response,
    tag: str | None = Query(default=None),
) -> list[dict[str, Any]]:
    events = _events_for_request(response)
    counts = _attendee_counts(read_users())
    events = [{**event, "attendee_count": counts[event["id"]]} for event in events]
    if tag is None:
        return events
    normalized_tag = tag.strip().lower()
    return [
        event
        for event in events
        if normalized_tag in [event_tag.lower() for event_tag in event["tags"]]
    ]


@app.get("/events/{event_id}")
def get_event(event_id: str, response: Response) -> dict[str, Any]:
    events = _events_for_request(response)
    event = next((item for item in events if item["id"] == event_id), None)
    if event is None:
        raise HTTPException(status_code=404, detail="Event not found")
    attendees = [
        _public(user) for user in read_users() if event_id in user["attending_event_ids"]
    ]
    return {**event, "attendee_count": len(attendees), "attendees": attendees}


@app.post("/users")
def upsert_user(user: UserProfile, request: Request) -> dict[str, Any]:
    address = request.client.host if request.client else "unknown"
    if not _allow_profile_save(address):
        raise HTTPException(status_code=429, detail="Too many profile updates. Try again later.")
    profile = user.model_dump(exclude={"secret"})
    try:
        return save_user(profile, secret=user.secret, max_users=MAX_USERS)
    except ProfileLocked:
        raise HTTPException(status_code=403, detail="This profile belongs to another device.") from None
    except TooManyUsers:
        raise HTTPException(status_code=503, detail="This server has reached its user limit.") from None


@app.get("/match/events/{user_id}")
def match_events(user_id: str, response: Response) -> list[dict[str, Any]]:
    user = next((item for item in read_users() if item["id"] == user_id), None)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    interests = {interest.lower() for interest in user["interests"]}
    matches = []
    for event in _events_for_request(response):
        event_tags = {tag.lower() for tag in event["tags"]}
        shared_count = len(interests & event_tags)
        matches.append(
            {
                **event,
                "match_score": _match_score(shared_count, len(interests)),
            }
        )
    return sorted(matches, key=lambda event: event["match_score"], reverse=True)


@app.get("/match/people/{event_id}/{user_id}")
def match_people(event_id: str, user_id: str, response: Response) -> list[dict[str, Any]]:
    events = _events_for_request(response)
    event = next((item for item in events if item["id"] == event_id), None)
    if event is None:
        raise HTTPException(status_code=404, detail="Event not found")
    users = read_users()
    user = next((item for item in users if item["id"] == user_id), None)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    interests = {interest.lower() for interest in user["interests"]}
    matches = []
    for candidate in users:
        if candidate["id"] == user_id or event_id not in candidate["attending_event_ids"]:
            continue
        candidate_interests = {
            interest.lower() for interest in candidate["interests"]
        }
        shared = sorted(interests & candidate_interests)
        union = interests | candidate_interests
        matches.append(
            {
                **_public(candidate),
                "match_score": _match_score(len(shared), len(union)),
                "shared_interests": shared,
            }
        )
    return sorted(matches, key=lambda person: person["match_score"], reverse=True)


@app.post("/reports")
def send_report(report: Report, request: Request) -> dict[str, Any]:
    """Saves a bug report, fix suggestion, support request or safety report and emails it."""
    address = request.client.host if request.client else "unknown"
    if not _allow_report(address):
        raise HTTPException(status_code=429, detail="Too many reports. Try again later.")
    title = REPORT_TITLES[report.kind]
    received = datetime.now(timezone.utc).isoformat(timespec="seconds")
    save_report({
        "received": received,
        "kind": report.kind,
        "message": report.message,
        "app_version": report.app_version,
    })
    body = (
        f"{title} sent from the MeetMate app\n"
        f"Received: {received}\n"
        f"App version: {report.app_version or 'unknown'}\n\n"
        f"{report.message}\n"
    )
    emailed = False
    try:
        emailed = send_report_email(f"MeetMate: {title}", body)
    except Exception as error:  # Keep the saved report even if the mail server fails.
        LOGGER.warning("Report saved but the email could not be sent: %s", error)
    if not email_configured():
        LOGGER.warning("Report saved to data/reports.jsonl; set MEETMATE_REPORT_TO to email reports.")
    return {"saved": True, "emailed": emailed}


# ---- Installing the app from this computer -------------------------------------------
# Open http://<this computer>:8000/install in a browser on this computer and scan the QR
# code with an Android phone on the same Wi-Fi to download the app.
APK_PATH = Path(__file__).resolve().parent.parent / "apk" / "MeetMate.apk"


def _lan_address() -> str:
    """This computer's Wi-Fi/LAN address (no traffic is sent)."""
    import socket

    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("192.0.2.1", 9))  # documentation-only address
        return probe.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        probe.close()


@app.get("/download/MeetMate.apk")
def download_apk() -> FileResponse:
    if not APK_PATH.is_file():
        raise HTTPException(status_code=404, detail="Build the app first (apk/MeetMate.apk).")
    return FileResponse(
        APK_PATH,
        media_type="application/vnd.android.package-archive",
        filename="MeetMate.apk",
    )


@app.get("/install", response_class=HTMLResponse)
def install_page(request: Request) -> str:
    import html

    import segno

    port = request.url.port or 8000
    host = request.url.hostname or ""
    if host in ("127.0.0.1", "localhost", "::1"):
        host = _lan_address()
    download_url = f"http://{host}:{port}/download/MeetMate.apk"
    server_address = f"{host}:{port}"
    qr = segno.make(download_url, error="m").svg_inline(scale=8, dark="#000033")
    size = f"{APK_PATH.stat().st_size / 1_000_000:.1f} MB" if APK_PATH.is_file() else "not built yet"
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Install MeetMate</title>
<style>
 body {{ font-family: system-ui, sans-serif; background: #EEEEEE; color: #000033;
        display: flex; justify-content: center; padding: 32px; }}
 .card {{ background: #EEFFFF; border-radius: 24px; padding: 32px; max-width: 460px;
         box-shadow: 0 8px 30px rgba(0,0,51,.12); text-align: center; }}
 h1 {{ font-family: Georgia, serif; margin: 0 0 4px; }} h1 span {{ color: #EE4444; }}
 .qr {{ background: white; display: inline-block; padding: 12px; border-radius: 16px; margin: 16px 0; }}
 ol {{ text-align: left; line-height: 1.5; }} code {{ background: #F0DDAA; padding: 2px 6px; border-radius: 6px; }}
 .small {{ font-size: 13px; opacity: .8; }}
</style></head><body><div class="card">
<h1>Meet<span>Mate</span></h1>
<div class="small">Android app · {html.escape(size)} · needs Android 16 or newer</div>
<div class="qr">{qr}</div>
<ol>
 <li>Connect the phone to the same Wi-Fi as this computer.</li>
 <li>Scan the code with the phone's camera and open the link.</li>
 <li>Open the downloaded <b>MeetMate.apk</b>. If asked, allow your browser to install unknown apps.</li>
 <li>In MeetMate, go to <b>Settings → Timișoara events</b>, enter <code>{html.escape(server_address)}</code> and tap <b>Connect</b>.</li>
</ol>
<div class="small">Or type this link on the phone:<br><code>{html.escape(download_url)}</code></div>
</div></body></html>"""
