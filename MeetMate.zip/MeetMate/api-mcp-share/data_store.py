import hashlib
import hmac
import json
import os
import sqlite3
import threading
import time
from contextlib import closing
from pathlib import Path
from typing import Any

DATA_DIR = Path(__file__).resolve().parent / "data"
EVENTS_DB_PATH = DATA_DIR / "events.sqlite3"
EVENTS_SCHEMA_PATH = Path(__file__).resolve().parent / "database" / "schema.sql"
EVENT_SOURCE = "visit-timisoara"
# Location used when the live feed doesn't name a venue.
DEFAULT_LOCATION = "Timișoara, Romania"
# Event fields that can be filled in by hand (import_event_addresses.py) and are kept
# when the live feed refreshes without them.
EDITABLE_EVENT_FIELDS = ("location", "address", "description")

_users_lock = threading.Lock()


def _connect_events() -> sqlite3.Connection:
    EVENTS_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(EVENTS_DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    schema = EVENTS_SCHEMA_PATH.read_text(encoding="utf-8")
    connection.executescript(schema)
    event_columns = {
        row["name"] for row in connection.execute("PRAGMA table_info(events)")
    }
    if "address" not in event_columns:
        connection.execute("ALTER TABLE events ADD COLUMN address TEXT NOT NULL DEFAULT ''")
    return connection


def _event_values(event: dict[str, Any], source: str) -> tuple[Any, ...]:
    return (
        event["id"],
        event["title"],
        event.get("description", ""),
        event["date"],
        event.get("location", ""),
        event.get("address", ""),
        event.get("image_url", ""),
        json.dumps(event.get("tags", []), ensure_ascii=False),
        source,
        event.get("source_url", ""),
        event.get("ticket_url", ""),
    )


def _insert_events(
    connection: sqlite3.Connection,
    events: list[dict[str, Any]],
    source: str,
) -> None:
    connection.executemany(
        """
        INSERT OR REPLACE INTO events
            (id, title, description, date, location, address, image_url, tags, source, source_url, ticket_url)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [_event_values(event, source) for event in events],
    )


def _read(filename: str) -> list[dict[str, Any]]:
    with (DATA_DIR / filename).open(encoding="utf-8") as data_file:
        return json.load(data_file)


def _write(filename: str, data: list[dict[str, Any]]) -> None:
    # Write to a temporary file first so a crash or a sync client never sees half a file.
    path = DATA_DIR / filename
    temp_path = path.with_name(f".{path.name}.tmp")
    with temp_path.open("w", encoding="utf-8") as data_file:
        json.dump(data, data_file, ensure_ascii=False, indent=2)
        data_file.write("\n")
    os.replace(temp_path, path)


def read_events() -> list[dict[str, Any]]:
    with closing(_connect_events()) as connection:
        rows = connection.execute(
            """
            SELECT id, title, description, date, location, address, image_url, tags, source, source_url, ticket_url
            FROM events
            ORDER BY date, title
            """
        ).fetchall()
    return [
        {
            **dict(row),
            "tags": json.loads(row["tags"]),
        }
        for row in rows
    ]


def _keep_saved_details(event: dict[str, Any], saved: sqlite3.Row | None) -> dict[str, Any]:
    """Keep a venue, address or description added by hand when the feed has none."""
    if saved is None:
        return event
    merged = dict(event)
    if not merged.get("address"):
        merged["address"] = saved["address"]
    if merged.get("location", "") in ("", DEFAULT_LOCATION) and saved["location"]:
        merged["location"] = saved["location"]
    if not merged.get("description"):
        merged["description"] = saved["description"]
    if not merged.get("image_url"):
        merged["image_url"] = saved["image_url"]
    return merged


def replace_external_events(
    events: list[dict[str, Any]],
    source: str = EVENT_SOURCE,
    mark_synced: bool = True,
) -> None:
    """Replace all events from one source (Visit Timișoara by default)."""
    with closing(_connect_events()) as connection:
        with connection:
            saved_details = {
                row["id"]: row
                for row in connection.execute(
                    "SELECT id, location, address, description, image_url FROM events WHERE source = ?",
                    (source,),
                )
            }
            events = [
                _keep_saved_details(event, saved_details.get(event["id"]))
                for event in events
            ]
            connection.execute("DELETE FROM events WHERE source = ?", (source,))
            _insert_events(connection, events, source)
            if not mark_synced:
                return
            connection.execute(
                """
                INSERT OR REPLACE INTO sync_state (key, value)
                VALUES ('last_successful_sync', ?)
                """,
                (time.time(),),
            )


def add_event(event: dict[str, Any]) -> None:
    with closing(_connect_events()) as connection:
        with connection:
            _insert_events(connection, [event], "manual")


def update_event_details(details: dict[str, dict[str, str]]) -> None:
    """Set the venue (location), address and/or description of existing events."""
    with closing(_connect_events()) as connection:
        with connection:
            for event_id, fields in details.items():
                updates = {
                    column: value
                    for column, value in fields.items()
                    if column in EDITABLE_EVENT_FIELDS and value
                }
                if not updates:
                    continue
                # Column names come from EDITABLE_EVENT_FIELDS only; values are parameters.
                assignments = ", ".join(f"{column} = ?" for column in updates)
                cursor = connection.execute(
                    f"UPDATE events SET {assignments} WHERE id = ?",
                    (*updates.values(), event_id),
                )
                if cursor.rowcount == 0:
                    raise ValueError(f"Unknown event ID: {event_id}")


def update_event_addresses(addresses: dict[str, str]) -> None:
    update_event_details(
        {event_id: {"address": address} for event_id, address in addresses.items()}
    )


def event_sync_is_due(max_age_seconds: int) -> bool:
    with closing(_connect_events()) as connection:
        row = connection.execute(
            "SELECT value FROM sync_state WHERE key = 'last_successful_sync'"
        ).fetchone()
    return row is None or time.time() - row["value"] >= max_age_seconds


def read_users() -> list[dict[str, Any]]:
    return _read("users.json")


def write_users(users: list[dict[str, Any]]) -> None:
    _write("users.json", users)


class ProfileLocked(Exception):
    """The profile belongs to another device (its secret doesn't match)."""


class TooManyUsers(Exception):
    pass


def _secret_hash(secret: str) -> str:
    return hashlib.sha256(secret.encode("utf-8")).hexdigest() if secret else ""


def without_secret(user: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in user.items() if key != "secret_hash"}


def save_user(user: dict[str, Any], secret: str = "", max_users: int = 0) -> dict[str, Any]:
    """Add or replace one profile; safe when several requests arrive at once.

    The first save with a secret ties the profile to that device: later saves of the same
    ID must send the same secret, so nobody else can take the profile over. Only a hash
    of the secret is stored.
    """
    secret_hash = _secret_hash(secret)
    with _users_lock:
        users = read_users()
        for index, existing_user in enumerate(users):
            if existing_user["id"] == user["id"]:
                stored = existing_user.get("secret_hash", "")
                if stored and not hmac.compare_digest(stored, secret_hash):
                    raise ProfileLocked(user["id"])
                users[index] = {**user, "secret_hash": stored or secret_hash}
                break
        else:
            if max_users and len(users) >= max_users:
                raise TooManyUsers()
            users.append({**user, "secret_hash": secret_hash})
        write_users(users)
    return without_secret(user)
