import csv
import sys
from pathlib import Path

from data_store import DEFAULT_LOCATION, update_event_details

# CSV column -> events table column. Only event_id is required; empty cells are skipped.
COLUMNS = {"location": "location", "address": "address", "description": "description"}


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python import_event_addresses.py <csv-file>")

    csv_path = Path(sys.argv[1])
    with csv_path.open(encoding="utf-8-sig", newline="") as address_file:
        reader = csv.DictReader(address_file)
        if reader.fieldnames is None or "event_id" not in reader.fieldnames:
            raise ValueError("CSV must contain an event_id column")
        if not set(COLUMNS).intersection(reader.fieldnames):
            raise ValueError("CSV must contain a location, address or description column")

        details: dict[str, dict[str, str]] = {}
        for row in reader:
            event_id = (row.get("event_id") or "").strip()
            if not event_id:
                raise ValueError("Every CSV row must include an event_id")
            for csv_column, db_column in COLUMNS.items():
                value = (row.get(csv_column) or "").strip()
                if not value or (db_column == "location" and value == DEFAULT_LOCATION):
                    continue
                existing = details.setdefault(event_id, {}).get(db_column)
                if existing is not None and existing != value:
                    raise ValueError(f"Conflicting {csv_column} values for event ID: {event_id}")
                details[event_id][db_column] = value

    if not details:
        raise ValueError("The CSV contains no venues, addresses or descriptions to import")
    update_event_details(details)
    print(f"Updated venues, addresses or descriptions for {len(details)} events.")


if __name__ == "__main__":
    main()
