package com.sidequest.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.text.InputFilter;
import android.text.InputType;
import android.view.inputmethod.EditorInfo;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    // Palette
    private static final int TEXT = Color.parseColor("#000033");
    private static final int INK = TEXT;
    private static final int MUTED = TEXT;
    private static final int ACCENT = Color.parseColor("#EE4444");      // buttons, others' bubbles
    private static final int OWN_BUBBLE = Color.parseColor("#BB3030");  // your chat bubbles
    private static final int FIELD = Color.parseColor("#F0DDAA");       // text boxes
    private static final int BUBBLE_TEXT = Color.parseColor("#EEEEEE"); // text on all chat bubbles
    // Icons and emojis. #000033 contrasts better than navy #333388 on every surface they sit on
    // (light backgrounds, #F0DDAA boxes, red buttons), so it is used everywhere except the navy bar.
    private static final int ICON = Color.parseColor("#000033");
    private static final int NAV_ICON = Color.parseColor("#EECC66");    // bottom-bar icons and labels
    private static final int NAV_BAR = Color.parseColor("#333388");     // bottom bar
    private static final int PAPER = Color.parseColor("#EEEEEE");       // page background
    private static final int CARD = Color.parseColor("#EEFFFF");        // event boxes and other cards
    private static final int PALE = CARD;
    /** Unicode variation selector: draw the preceding symbol as tintable text, not a colour emoji. */
    private static final String TEXT_STYLE = "\uFE0E";
    private static final int LINE = Color.parseColor("#D6E2E2");
    /** Height of single-line inputs, matching the chat message box. */
    private static final int INPUT_HEIGHT = 46;
    /** Floating bottom bar size and its gap from the screen edges, in dp. */
    private static final int NAV_HEIGHT = 64;
    private static final int NAV_MARGIN = 12;
    private static final String[] INTERESTS = {
            "Live music", "Foodie", "Outdoors", "Art", "Fitness",
            "Movies", "Dancing", "Coffee", "Gaming", "Books"
    };

    private final List<Event> events = Arrays.asList(
            new Event("Rooftop Jazz Session", "LIVE MUSIC", "Tonight · 7:30 PM", "The Skylark, 0.8 mi",
                    "🎷", Color.rgb(70, 83, 91), "18 going", "Music"),
            new Event("Sunday Farmers Market", "FOOD & DRINK", "Sun · 10:00 AM", "Union Square, 1.2 mi",
                    "🥑", Color.rgb(104, 124, 87), "32 going", "Food"),
            new Event("Golden Hour Hike", "OUTDOORS", "Sat · 5:00 PM", "Lands End, 2.4 mi",
                    "🌅", Color.rgb(207, 123, 80), "12 going", "Outdoors"),
            new Event("Gallery After Hours", "ART & CULTURE", "Fri · 6:00 PM", "Modern Art House, 1.6 mi",
                    "🎨", Color.rgb(143, 91, 79), "24 going", "Art")
    );
    private final List<LocalPerson> people = Arrays.asList(
            new LocalPerson("Maya", "🎧", "Live music", "Coffee", "Art", "Foodie"),
            new LocalPerson("Leo", "📷", "Live music", "Outdoors", "Coffee", "Movies"),
            new LocalPerson("Sam", "🌿", "Outdoors", "Foodie", "Art", "Books"),
            new LocalPerson("Nina", "✨", "Live music", "Dancing", "Foodie", "Fitness"),
            new LocalPerson("Alex", "🎸", "Live music", "Gaming", "Movies", "Coffee")
    );
    private final List<LocalChat> chats = new ArrayList<>();
    private final Set<String> selectedInterests = new LinkedHashSet<>();
    private SharedPreferences preferences;
    private SharedPreferences chatPreferences;
    private SharedPreferences draftPreferences;
    private LinearLayout chatMessagesContainer;
    private LinearLayout page;
    private LinearLayout navigation;
    private ScrollView contentScroll;
    private String lastRenderedTab;
    private boolean lastRenderWasChat;
    private String currentTab = "Explore";
    private String userName = "Jamie";
    private String userAge = "26";
    private String userContact = "j*****@email.com";
    private String selectedEvent = "Rooftop Jazz Session";
    private int groupSize = 3;
    private List<LocalPerson> currentMatches = new ArrayList<>();
    private int matchOffset = 0;
    private int selectedFilter = 0;
    private String eventSearchQuery = "";
    private boolean matchReady = false;
    private LocalChat openChat;
    private LocalChat feedbackChat;
    private LocalChat safetyReturnChat;
    private String safetyReturnTab = "Settings";
    private String bugFixTopic = "Bug report";
    private boolean notificationsEnabled = true;
    private boolean locationEnabled = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setDecorFitsSystemWindows(false);
        preferences = getSharedPreferences("sidequest_profile", MODE_PRIVATE);
        chatPreferences = getSharedPreferences("sidequest_chat_history", MODE_PRIVATE);
        draftPreferences = getSharedPreferences("sidequest_drafts", MODE_PRIVATE);
        userName = preferences.getString("name", userName);
        userAge = preferences.getString("age", userAge);
        userContact = preferences.getString("contact", userContact);
        notificationsEnabled = preferences.getBoolean("notifications", notificationsEnabled);
        locationEnabled = preferences.getBoolean("location", locationEnabled);
        selectedInterests.addAll(preferences.getStringSet("interests",
                new LinkedHashSet<>(Arrays.asList("Live music", "Coffee", "Foodie", "Outdoors"))));
        if (selectedInterests.isEmpty()) {
            selectedInterests.addAll(Arrays.asList("Live music", "Coffee", "Foodie", "Outdoors"));
        }
        loadChats();
        render();
    }

    private void loadChats() {
        String saved = chatPreferences.getString("chats", null);
        boolean migratingLegacyChats = false;
        if (saved == null) {
            saved = preferences.getString("chats", null);
            migratingLegacyChats = saved != null;
        }
        if (saved == null) return;
        List<LocalChat> loadedChats = new ArrayList<>();
        try {
            JSONArray savedChats = new JSONArray(saved);
            for (int i = 0; i < savedChats.length(); i++) {
                JSONObject savedChat = savedChats.getJSONObject(i);
                JSONArray savedMembers = savedChat.getJSONArray("members");
                List<String> members = new ArrayList<>();
                for (int j = 0; j < savedMembers.length(); j++) {
                    members.add(savedMembers.getString(j));
                }
                LocalChat chat = new LocalChat(
                        savedChat.getString("id"),
                        savedChat.getString("eventName"),
                        members);
                chat.hangoutCompleted = savedChat.optBoolean("hangoutCompleted", false);
                JSONObject savedRatings = savedChat.optJSONObject("ratings");
                if (savedRatings != null) {
                    Iterator<String> ratingNames = savedRatings.keys();
                    while (ratingNames.hasNext()) {
                        String member = ratingNames.next();
                        int rating = savedRatings.optInt(member, 0);
                        if (members.contains(member) && rating >= 1 && rating <= 5) {
                            chat.ratings.put(member, rating);
                        }
                    }
                }
                JSONArray savedMessages = savedChat.getJSONArray("messages");
                for (int j = 0; j < savedMessages.length(); j++) {
                    JSONObject savedMessage = savedMessages.getJSONObject(j);
                    chat.messages.add(new LocalMessage(
                            savedMessage.getString("senderName"),
                            savedMessage.getString("text"),
                            savedMessage.getBoolean("own")));
                }
                loadedChats.add(chat);
            }
            chats.addAll(loadedChats);
            if (migratingLegacyChats) {
                chatPreferences.edit().putString("chats", saved).apply();
                preferences.edit().remove("chats").apply();
            }
        } catch (JSONException error) {
            Toast.makeText(this, "Saved chats couldn’t be loaded.", Toast.LENGTH_LONG).show();
        }
    }

    private void persistChats() {
        JSONArray savedChats = new JSONArray();
        try {
            for (LocalChat chat : chats) {
                JSONObject savedChat = new JSONObject();
                savedChat.put("id", chat.id);
                savedChat.put("eventName", chat.eventName);
                JSONArray savedMembers = new JSONArray();
                for (String member : chat.memberNames) savedMembers.put(member);
                savedChat.put("members", savedMembers);

                JSONArray savedMessages = new JSONArray();
                for (LocalMessage message : chat.messages) {
                    JSONObject savedMessage = new JSONObject();
                    savedMessage.put("senderName", message.senderName);
                    savedMessage.put("text", message.text);
                    savedMessage.put("own", message.own);
                    savedMessages.put(savedMessage);
                }
                savedChat.put("messages", savedMessages);
                savedChat.put("hangoutCompleted", chat.hangoutCompleted);
                JSONObject savedRatings = new JSONObject();
                for (Map.Entry<String, Integer> rating : chat.ratings.entrySet()) {
                    savedRatings.put(rating.getKey(), rating.getValue());
                }
                savedChat.put("ratings", savedRatings);
                savedChats.put(savedChat);
            }
            chatPreferences.edit().putString("chats", savedChats.toString()).apply();
        } catch (JSONException error) {
            Toast.makeText(this, "Chats couldn’t be saved on this phone.", Toast.LENGTH_LONG).show();
        }
    }

    private void setLightSystemBars() {
        WindowInsetsController controller =
                getWindow().getDecorView().getWindowInsetsController();
        if (controller == null) return;
        int appearance = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
        controller.setSystemBarsAppearance(appearance, appearance);
    }

    private void render() {
        int previousScrollY = contentScroll == null ? 0 : contentScroll.getScrollY();
        boolean wasChat = lastRenderWasChat;
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(PAPER);

        LinearLayout contentFrame = new LinearLayout(this);
        contentFrame.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams contentParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        shell.addView(contentFrame, contentParams);

        contentScroll = new ScrollView(this);
        contentScroll.setFillViewport(true);
        contentScroll.setClipToPadding(false);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        // Leave room at the bottom so the last card can scroll above the floating bar.
        page.setPadding(dp(22), dp(14), dp(22),
                openChat != null ? dp(28) : dp(NAV_HEIGHT + NAV_MARGIN * 2 + 12));
        contentScroll.addView(page);

        // The page and the floating bottom bar share one layer so content scrolls under the bar.
        FrameLayout stack = new FrameLayout(this);
        stack.setClipChildren(false);
        stack.addView(contentScroll, new FrameLayout.LayoutParams(-1, -1));
        contentFrame.addView(stack, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        navigation = new LinearLayout(this);
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        navigation.setGravity(Gravity.CENTER);
        navigation.setBackground(round(NAV_BAR, NAV_HEIGHT / 2));
        navigation.setPadding(dp(6), dp(6), dp(6), dp(6));
        floatAbove(navigation, 14, NAV_BAR);
        FrameLayout.LayoutParams navParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(NAV_HEIGHT),
                Gravity.BOTTOM);
        navParams.setMargins(dp(NAV_MARGIN + 4), 0, dp(NAV_MARGIN + 4), dp(NAV_MARGIN));
        stack.addView(navigation, navParams);
        if (openChat != null) navigation.setVisibility(View.GONE);
        setContentView(shell);
        setLightSystemBars();
        applySystemBarInsets(shell);

        if (openChat != null) {
            LinearLayout compose = buildChatDetail(openChat);
            contentFrame.addView(compose, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            restoreScrollPosition(previousScrollY, wasChat);
            return;
        }
        switch (currentTab) {
            case "Match": buildMatchPage(); break;
            case "Chats": buildChatsPage(); break;
            case "Profile": buildProfilePage(); break;
            case "Hangout feedback": buildHangoutFeedbackPage(feedbackChat); break;
            case "Bugs & fixes": buildBugFixPage(); break;
            case "Safety": buildSafetyPage(); break;
            case "Settings": buildSettingsPage(); break;
            default: buildExplorePage(); break;
        }
        addNavigation();
        restoreScrollPosition(previousScrollY, wasChat);
    }

    private void applySystemBarInsets(View root) {
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            android.graphics.Insets safeInsets = insets.getInsets(
                    android.view.WindowInsets.Type.systemBars()
                            | android.view.WindowInsets.Type.displayCutout());
            view.setPadding(
                    safeInsets.left,
                    safeInsets.top,
                    safeInsets.right,
                    safeInsets.bottom);
            return insets;
        });
        root.requestApplyInsets();
    }

    private void restoreScrollPosition(int scrollY, boolean wasChat) {
        boolean isChat = openChat != null;
        if (currentTab.equals(lastRenderedTab) && isChat == wasChat) {
            // Restore after layout but before the first frame is drawn, so the
            // rebuilt page never flashes at the top.
            ScrollView scroll = contentScroll;
            scroll.getViewTreeObserver().addOnPreDrawListener(
                    new android.view.ViewTreeObserver.OnPreDrawListener() {
                        @Override
                        public boolean onPreDraw() {
                            scroll.getViewTreeObserver().removeOnPreDrawListener(this);
                            scroll.scrollTo(0, scrollY);
                            return true;
                        }
                    });
        }
        lastRenderedTab = currentTab;
        lastRenderWasChat = isChat;
    }

    private void buildExplorePage() {
        addBrandHeader();
        TextView location = label("A FEW GOOD THINGS, CLOSE BY", 10, ACCENT, true);
        location.setLetterSpacing(0.08f);
        add(location, 0, 18);
        add(title("Make a plan.\nBring a friend.", 31), 0, 8);
        add(body("Small plans make the best stories.", 14), 0, 20);

        LinearLayout search = row();
        search.setGravity(Gravity.CENTER_VERTICAL);
        search.setPadding(dp(14), 0, dp(14), 0);
        GradientDrawable searchBackground = round(FIELD, 12);
        searchBackground.setStroke(dp(1), LINE);
        search.setBackground(searchBackground);
        TextView searchIcon = icon("⌕", 22);
        search.addView(searchIcon);
        EditText searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextSize(13);
        searchInput.setTextColor(INK);
        searchInput.setHintTextColor(MUTED);
        searchInput.setHint("Jazz, coffee, a good walk…");
        searchInput.setText(eventSearchQuery);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        hintParams.leftMargin = dp(10);
        search.addView(searchInput, hintParams);
        searchIcon.setOnClickListener(v -> applyEventSearch(searchInput));
        searchInput.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId != EditorInfo.IME_ACTION_SEARCH) return false;
            applyEventSearch(searchInput);
            return true;
        });
        add(search, 0, 22);

        LinearLayout heading = row();
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.addView(title("On the calendar", 20), new LinearLayout.LayoutParams(0, -2, 1f));
        add(heading, 0, 12);

        LinearLayout filters = row();
        String[] filtersText = {"For you", "Music", "Food", "Outdoors", "Art"};
        int visibleEvents = 0;
        for (int i = 0; i < filtersText.length; i++) {
            final int index = i;
            TextView chip = chip(filtersText[i], selectedFilter == i);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(34));
            params.rightMargin = dp(8);
            filters.addView(chip, params);
            chip.setOnClickListener(v -> {
                selectedFilter = index;
                render();
            });
        }
        ScrollView filterScroll = new ScrollView(this);
        filterScroll.setHorizontalScrollBarEnabled(false);
        filterScroll.setHorizontalFadingEdgeEnabled(true);
        filterScroll.addView(filters);
        add(filterScroll, 0, 14);

        for (Event event : events) {
            if (selectedFilter != 0 && !event.category.equals(filtersText[selectedFilter])) continue;
            if (!matchesSearch(event, eventSearchQuery)) continue;
            addEventCard(event, false);
            visibleEvents++;
        }
        if (visibleEvents == 0) {
            TextView empty = body("No events match that search. Try another name or category.", 13);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(24), dp(18), dp(24));
            empty.setBackground(round(PALE, 16));
            add(empty, 0, 12);
        }
    }

    private void applyEventSearch(EditText input) {
        eventSearchQuery = input.getText().toString().trim();
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(input.getWindowToken(), 0);
        render();
    }

    private boolean matchesSearch(Event event, String query) {
        if (query.isEmpty()) return true;
        String normalized = query.toLowerCase(java.util.Locale.ROOT);
        return (event.name + " " + event.label + " " + event.place + " " + event.category)
                .toLowerCase(java.util.Locale.ROOT).contains(normalized);
    }

    private void addEventCard(Event event, boolean selectable) {
        LinearLayout card = column();
        card.setBackground(round(CARD, 22));
        floatAbove(card, 4, ICON);
        pressable(card);
        card.setPadding(dp(10), dp(10), dp(10), dp(12));

        FrameLayout cover = new FrameLayout(this);
        cover.setBackground(round(event.color, 10));
        TextView posterNumber = label(String.format(java.util.Locale.ROOT, "%02d",
                events.indexOf(event) + 1), 66, Color.WHITE, true);
        posterNumber.setTypeface(Typeface.SERIF, Typeface.BOLD);
        posterNumber.setAlpha(0.28f);
        posterNumber.setGravity(Gravity.RIGHT | Gravity.BOTTOM);
        FrameLayout.LayoutParams numberParams = new FrameLayout.LayoutParams(-1, -1);
        numberParams.setMargins(0, 0, dp(10), dp(2));
        cover.addView(posterNumber, numberParams);
        TextView badge = label(event.label, 9, INK, true);
        badge.setLetterSpacing(0.04f);
        badge.setPadding(dp(9), dp(6), dp(9), dp(6));
        badge.setBackground(round(CARD, 7));
        FrameLayout.LayoutParams badgeParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        badgeParams.setMargins(dp(9), dp(9), 0, 0);
        cover.addView(badge, badgeParams);
        cover.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(132)));
        card.addView(cover);

        LinearLayout details = row();
        details.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout text = column();
        TextView eventTitle = title(event.name, 16);
        text.addView(eventTitle);
        TextView when = body(event.when + "  ·  " + event.place, 11);
        when.setPadding(0, dp(5), 0, 0);
        text.addView(when);
        details.addView(text, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView attendees = label("", 10, ACCENT, true);
        android.text.SpannableString attending =
                new android.text.SpannableString("●  " + event.attending);
        attending.setSpan(new android.text.style.ForegroundColorSpan(ICON), 0, 1,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        attendees.setText(attending);
        details.addView(attendees);
        LinearLayout.LayoutParams detailsParams = new LinearLayout.LayoutParams(-1, -2);
        detailsParams.topMargin = dp(12);
        card.addView(details, detailsParams);

        if (selectable) {
            TextView selection = label(event.name.equals(selectedEvent) ? "✓  Selected" : "Choose this event",
                    12, TEXT, true);
            selection.setGravity(Gravity.CENTER);
            selection.setBackground(round(event.name.equals(selectedEvent) ? ACCENT : PAPER, 21));
            if (event.name.equals(selectedEvent)) floatAbove(selection, 5, ACCENT);
            LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(42));
            buttonParams.topMargin = dp(12);
            card.addView(selection, buttonParams);
            card.setOnClickListener(v -> {
                selectedEvent = event.name;
                matchReady = false;
                render();
            });
        } else {
            TextView matchButton = label("Meet your people  →", 12, TEXT, true);
            matchButton.setGravity(Gravity.CENTER);
            matchButton.setBackground(round(ACCENT, 20));
            floatAbove(matchButton, 5, ACCENT);
            LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(40));
            buttonParams.topMargin = dp(12);
            card.addView(matchButton, buttonParams);
            card.setOnClickListener(v -> {
                selectedEvent = event.name;
                currentTab = "Match";
                matchReady = false;
                render();
            });
        }
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.bottomMargin = dp(14);
        page.addView(card, cardParams);
    }

    private void buildMatchPage() {
        addBrandHeader();
        add(label("GOOD PLANS, BETTER COMPANY", 10, ACCENT, true), 0, 18);
        add(title("Pick a plan.\nMeet your people.", 29), 0, 8);
        add(body("Choose what sounds fun. We’ll find a few folks to join.", 13), 0, 20);
        addLocalNotice("Matches use sample profiles on this phone.");

        add(sectionTitle("01  CHOOSE AN EVENT"), 0, 10);
        for (Event event : events) addEventCard(event, true);

        LinearLayout sizeHeader = row();
        sizeHeader.setGravity(Gravity.CENTER_VERTICAL);
        sizeHeader.addView(sectionTitle("02  CREW SIZE"), new LinearLayout.LayoutParams(0, -2, 1f));
        add(sizeHeader, 0, 12);
        LinearLayout sizeCard = row();
        sizeCard.setGravity(Gravity.CENTER_VERTICAL);
        sizeCard.setPadding(dp(16), dp(12), dp(16), dp(12));
        sizeCard.setBackground(round(PALE, 16));
        LinearLayout sizeText = column();
        sizeText.addView(title("Your group", 15));
        sizeText.addView(body("Including you", 11));
        sizeCard.addView(sizeText, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView minus = roundControl("−");
        sizeCard.addView(minus);
        TextView count = label(String.valueOf(groupSize), 17, INK, true);
        count.setGravity(Gravity.CENTER);
        sizeCard.addView(count, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView plus = roundControl("+");
        sizeCard.addView(plus);
        // Update the count in place; a full render() rebuilds the screen and flickers.
        minus.setOnClickListener(v -> {
            if (groupSize > 2) groupSize--;
            count.setText(String.valueOf(groupSize));
        });
        plus.setOnClickListener(v -> {
            if (groupSize < 6) groupSize++;
            count.setText(String.valueOf(groupSize));
        });
        add(sizeCard, 0, 18);

        add(sectionTitle("03  YOUR VIBE"), 0, 18);
        LinearLayout tags = row();
        tags.setOrientation(LinearLayout.HORIZONTAL);
        for (String interest : selectedInterests) {
            TextView tag = chip(interest, true);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(32));
            params.rightMargin = dp(7);
            tags.addView(tag, params);
        }
        if (selectedInterests.isEmpty()) tags.addView(body("Add interests in your profile", 12));
        add(tags, 0, 16);

        Button matchButton = primaryButton(matchReady ? "Try another group" : "Find my crew");
        add(matchButton, 0, 16);
        matchButton.setOnClickListener(v -> findMatches());

        if (matchReady) {
            addMatches();
        } else {
            TextView privacy = body("You’ll review your crew before a group chat is created.", 11);
            privacy.setGravity(Gravity.CENTER);
            add(privacy, 0, 12);
        }
    }

    private void findMatches() {
        List<LocalPerson> ranked = new ArrayList<>();
        for (LocalPerson person : people) {
            if (!person.sharedInterests(selectedInterests).isEmpty()) ranked.add(person);
        }
        Collections.sort(ranked, (left, right) -> Integer.compare(
                right.sharedInterests(selectedInterests).size(),
                left.sharedInterests(selectedInterests).size()));
        currentMatches.clear();
        if (!ranked.isEmpty()) {
            int start = matchOffset % ranked.size();
            int count = Math.min(groupSize - 1, ranked.size());
            for (int i = 0; i < count; i++) {
                currentMatches.add(ranked.get((start + i) % ranked.size()));
            }
            matchOffset = (start + 1) % ranked.size();
        }
        matchReady = true;
        if (currentMatches.isEmpty()) {
            Toast.makeText(this, "Add a few interests to find your people.", Toast.LENGTH_LONG).show();
        }
        render();
    }

    private void addMatches() {
        add(sectionTitle("PEOPLE WHO MIGHT CLICK"), 0, 22);
        if (currentMatches.isEmpty()) {
            add(body("No one else is matched for this event yet. Come back after more people join.",
                    13), 0, 10);
            return;
        }
        TextView description = body("People picked for " + eventByName(selectedEvent).name
                + " based on your shared interests.", 12);
        add(description, 0, 12);
        for (LocalPerson person : currentMatches) addPersonCard(person);

        Button accept = primaryButton("Start a group chat");
        add(accept, 0, 16);
        accept.setOnClickListener(v -> {
            List<String> members = new ArrayList<>();
            for (LocalPerson person : currentMatches) members.add(person.name);
            LocalChat chat = new LocalChat(UUID.randomUUID().toString(), selectedEvent, members);
            chats.add(0, chat);
            persistChats();
            openChat = chat;
            currentTab = "Chats";
            Toast.makeText(MainActivity.this,
                    "Your local event group chat is ready!", Toast.LENGTH_SHORT).show();
            render();
        });
        TextView pass = label("Try a different group", 12, MUTED, true);
        pass.setGravity(Gravity.CENTER);
        add(pass, 0, 15);
        pass.setOnClickListener(v -> {
            matchReady = false;
            currentMatches.clear();
            render();
        });
    }

    private void addPersonCard(LocalPerson person) {
        LinearLayout card = row();
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(round(CARD, 20));
        floatAbove(card, 2, ICON);
        View avatar = avatar(person.emoji, 48, rgb(239, 231, 214));
        card.addView(avatar);
        LinearLayout info = column();
        TextView name = title(person.name, 14);
        info.addView(name);
        TextView shared = body("You both like "
                + person.sharedInterestsText(selectedInterests), 11);
        shared.setPadding(0, dp(5), 0, 0);
        info.addView(shared);
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, -2, 1f);
        infoParams.leftMargin = dp(12);
        card.addView(info, infoParams);
        TextView percent = label(person.sharedInterests(selectedInterests).size()
                + " shared", 10, ACCENT, true);
        card.addView(percent);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(9);
        page.addView(card, params);
    }

    private void buildChatsPage() {
        addBrandHeader();
        add(label("PLANS IN GOOD COMPANY", 10, ACCENT, true), 0, 18);
        add(title("Group chats", 28), 0, 6);
        add(body("The fun starts before you get there.", 13), 0, 20);
        addLocalNotice("Your messages are saved only on this phone.");
        if (chats.isEmpty()) {
            LinearLayout empty = column();
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(24), dp(34), dp(24), dp(34));
            empty.setBackground(round(PALE, 20));
            TextView emoji = icon("💬", 38);
            emoji.setGravity(Gravity.CENTER);
            empty.addView(emoji);
            TextView heading = title("No group chats yet", 17);
            heading.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams headingParams = new LinearLayout.LayoutParams(-1, -2);
            headingParams.topMargin = dp(12);
            empty.addView(heading, headingParams);
            TextView text = body("Find a crew for an event and your chat will show up here.", 12);
            text.setGravity(Gravity.CENTER);
            text.setPadding(0, dp(7), 0, 0);
            empty.addView(text);
            add(empty, 0, 10);
            Button explore = primaryButton("Explore events");
            add(explore, 0, 14);
            explore.setOnClickListener(v -> {
                currentTab = "Explore";
                render();
            });
            return;
        }
        for (LocalChat chat : chats) {
            LinearLayout card = row();
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            card.setBackground(round(PALE, 20));
            floatAbove(card, 2, ICON);
            pressable(card);
            View icon = avatar(eventByName(chat.eventName).emoji, 48, Color.WHITE);
            card.addView(icon);
            LinearLayout info = column();
            info.addView(title(chat.eventName, 14));
            String lastMessage = chat.lastMessage();
            info.addView(body(chat.memberNamesText() + "  ·  " + lastMessage, 11));
            LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, -2, 1f);
            infoParams.leftMargin = dp(12);
            card.addView(info, infoParams);
            TextView arrow = icon("›", 24);
            card.addView(arrow);
            card.setOnClickListener(v -> {
                openChat = chat;
                render();
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
            params.bottomMargin = dp(10);
            page.addView(card, params);
        }
    }

    private void addLocalNotice(String message) {
        LinearLayout notice = column();
        notice.setPadding(dp(18), dp(16), dp(18), dp(16));
        notice.setBackground(round(PALE, 14));
        notice.addView(title("On-device demo", 15));
        TextView details = body(message, 12);
        details.setPadding(0, dp(7), 0, 0);
        notice.addView(details);
        add(notice, 0, 12);
    }

    private LinearLayout buildChatDetail(LocalChat chat) {
        LinearLayout header = row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = label("‹", 29, INK, false);
        back.setOnClickListener(v -> {
            openChat = null;
            chatMessagesContainer = null;
            currentTab = "Chats";
            render();
        });
        header.addView(back, new LinearLayout.LayoutParams(dp(36), dp(48)));
        LinearLayout headerText = column();
        headerText.addView(title(chat.eventName, 16));
        headerText.addView(body((chat.memberNames.size() + 1) + " people · event crew", 10));
        header.addView(headerText, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView details = label("•••", 18, MUTED, true);
        header.addView(details);
        add(header, 0, 8);
        addRule();

        Event event = eventByName(chat.eventName);
        LinearLayout eventBanner = row();
        eventBanner.setGravity(Gravity.CENTER_VERTICAL);
        eventBanner.setPadding(dp(12), dp(11), dp(12), dp(11));
        eventBanner.setBackground(round(CARD, 10));
        eventBanner.addView(icon("📍", 13));
        TextView bannerText = label(event.when + "  ·  " + event.place, 11, ACCENT, true);
        bannerText.setPadding(dp(8), 0, 0, 0);
        eventBanner.addView(bannerText);
        add(eventBanner, 0, 14);

        TextView intro = body("You’re in! Say hi and start planning your "
                + event.category.toLowerCase() + " outing.", 12);
        intro.setGravity(Gravity.CENTER);
        intro.setPadding(dp(18), dp(12), dp(18), dp(14));
        intro.setBackground(round(PALE, 14));
        add(intro, 0, 14);

        TextView reportConcern = label("Report a concern", 12, ACCENT, true);
        reportConcern.setOnClickListener(v -> {
            showSafetyPage(chat.eventName + " group chat", "Chat", chat);
        });
        add(reportConcern, 0, 12);

        Button feedback = primaryButton(chat.hangoutCompleted
                ? "Update post-hangout ratings" : "Hangout finished? Rate your crew");
        add(feedback, 0, 14);
        feedback.setOnClickListener(v -> {
            chat.hangoutCompleted = true;
            feedbackChat = chat;
            openChat = null;
            currentTab = "Hangout feedback";
            persistChats();
            render();
        });

        chatMessagesContainer = column();
        page.addView(chatMessagesContainer, new LinearLayout.LayoutParams(-1, -2));
        renderMessages(chat);
        scrollChatToLatestMessage();

        LinearLayout compose = row();
        compose.setGravity(Gravity.CENTER_VERTICAL);
        compose.setPadding(dp(14), dp(9), dp(14), dp(12));
        compose.setBackgroundColor(PAPER);
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(13);
        input.setTextColor(INK);
        input.setHintTextColor(MUTED);
        input.setHint("Message your crew...");
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setBackground(round(FIELD, 24));
        compose.addView(input, new LinearLayout.LayoutParams(0, dp(INPUT_HEIGHT), 1f));
        FrameLayout send = new FrameLayout(this);
        send.setContentDescription("Send message");
        send.setBackground(round(OWN_BUBBLE, 23));  // dark red
        floatAbove(send, 6, OWN_BUBBLE);
        pressable(send);
        // Plain text glyph on its own view, so only the arrow is black, not the button.
        TextView sendArrow = label("➤" + TEXT_STYLE, 20, ICON, true);
        sendArrow.setGravity(Gravity.CENTER);
        send.addView(sendArrow, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(dp(46), dp(46));
        sendParams.leftMargin = dp(8);
        compose.addView(send, sendParams);
        send.setOnClickListener(v -> sendMessage(chat, input));
        input.setOnEditorActionListener((view, actionId, eventAction) -> {
            if (actionId != EditorInfo.IME_ACTION_SEND) return false;
            sendMessage(chat, input);
            return true;
        });
        return compose;
    }

    private void renderMessages(LocalChat chat) {
        if (chatMessagesContainer == null) return;
        chatMessagesContainer.removeAllViews();
        if (chat.messages.isEmpty()) {
            TextView empty = body("No messages yet. Send a hello to start planning.", 12);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(20), dp(18), dp(20));
            empty.setBackground(round(PALE, 14));
            chatMessagesContainer.addView(empty);
            return;
        }
        for (LocalMessage message : chat.messages) addMessageBubble(message);
        chatMessagesContainer.requestLayout();
        chatMessagesContainer.invalidate();
    }

    private void addMessageBubble(LocalMessage message) {
        LinearLayout bubbleWrap = column();
        TextView sender = label(message.own ? "You" : message.senderName, 10, MUTED, true);
        if (message.own) sender.setGravity(Gravity.RIGHT);
        bubbleWrap.addView(sender);
        TextView bubble = body(message.text, 13);
        bubble.setTextColor(BUBBLE_TEXT);  // light text on red bubbles, always
        bubble.setPadding(dp(13), dp(10), dp(13), dp(10));
        bubble.setBackground(round(message.own ? OWN_BUBBLE : ACCENT, 14));
        LinearLayout.LayoutParams bubbleParams = new LinearLayout.LayoutParams(-2, -2);
        if (message.own) bubbleParams.gravity = Gravity.RIGHT;
        bubbleParams.topMargin = dp(4);
        bubbleWrap.addView(bubble, bubbleParams);
        LinearLayout.LayoutParams wrapParams = new LinearLayout.LayoutParams(-1, -2);
        wrapParams.bottomMargin = dp(12);
        chatMessagesContainer.addView(bubbleWrap, wrapParams);
    }

    private void scrollChatToLatestMessage() {
        if (contentScroll == null || chatMessagesContainer == null) return;
        chatMessagesContainer.post(() -> {
            if (contentScroll == null || chatMessagesContainer == null) return;
            int targetY = chatMessagesContainer.getBottom() - contentScroll.getHeight();
            contentScroll.scrollTo(0, Math.max(0, targetY));
        });
    }

    private void sendMessage(
            LocalChat chat,
            EditText input) {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        if (text.length() > 1000) {
            Toast.makeText(this, "Messages can be up to 1000 characters.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        boolean wasEmpty = chat.messages.isEmpty();
        LocalMessage message = new LocalMessage(userName, text, true);
        chat.messages.add(message);
        persistChats();
        if (openChat == chat && chatMessagesContainer != null) {
            if (wasEmpty) chatMessagesContainer.removeAllViews();
            addMessageBubble(message);
            chatMessagesContainer.requestLayout();
            chatMessagesContainer.invalidate();
            scrollChatToLatestMessage();
        }
        input.setText("");
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(input.getWindowToken(), 0);
    }

    private void buildProfilePage() {
        addBrandHeader();
        add(label("A LITTLE ABOUT YOU", 10, ACCENT, true), 0, 18);
        add(title("Your profile", 28), 0, 6);
        add(body("A little about you helps us find your people.", 13), 0, 18);

        LinearLayout hero = row();
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(dp(16), dp(15), dp(16), dp(15));
        hero.setBackground(round(CARD, 14));
        View avatar = avatar("😊", 54, Color.WHITE);
        hero.addView(avatar);
        LinearLayout heroText = column();
        heroText.addView(title(userName + ", " + userAge, 17));
        heroText.addView(body("San Francisco, CA", 11));
        LinearLayout.LayoutParams heroTextParams = new LinearLayout.LayoutParams(0, -2, 1f);
        heroTextParams.leftMargin = dp(12);
        hero.addView(heroText, heroTextParams);
        TextView editLabel = label("EDIT", 10, ACCENT, true);
        hero.addView(editLabel);
        add(hero, 0, 20);

        add(sectionTitle("ABOUT YOU"), 0, 14);
        EditText name = inputField("Name", userName);
        add(name, 0, 8);
        EditText age = inputField("Age", userAge);
        age.setInputType(2);
        add(age, 0, 8);
        EditText contact = inputField("Email or phone", userContact);
        add(contact, 0, 12);
        Button save = primaryButton("Save profile");
        add(save, 0, 4);
        save.setOnClickListener(v -> {
            String newName = name.getText().toString().trim();
            String newAge = age.getText().toString().trim();
            String newContact = contact.getText().toString().trim();
            if (newName.isEmpty() || newAge.isEmpty() || newContact.isEmpty()) {
                Toast.makeText(this, "Please fill in your name, age, and contact.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (newName.length() > 40) {
                Toast.makeText(this, "Names can be up to 40 characters.", Toast.LENGTH_SHORT).show();
                return;
            }
            userName = newName;
            userAge = newAge;
            userContact = newContact;
            preferences.edit().putString("name", userName).putString("age", userAge)
                    .putString("contact", userContact).apply();
            Toast.makeText(this, "Profile saved", Toast.LENGTH_SHORT).show();
            render();
        });

        add(sectionTitle("INTERESTS & HOBBIES"), 0, 24);
        add(body("Pick a few things you love. We’ll use them to make better matches.", 12), 0, 10);
        LinearLayout interestList = column();
        for (String interest : INTERESTS) {
            CheckBox check = new CheckBox(this);
            check.setText(interest);
            check.setTextColor(INK);
            check.setTextSize(12);
            check.setButtonTintList(android.content.res.ColorStateList.valueOf(
                    selectedInterests.contains(interest) ? ACCENT : MUTED));
            check.setChecked(selectedInterests.contains(interest));
            check.setOnCheckedChangeListener((button, checked) -> {
                if (checked) selectedInterests.add(interest);
                else selectedInterests.remove(interest);
                check.setButtonTintList(android.content.res.ColorStateList.valueOf(
                        checked ? ACCENT : MUTED));
                preferences.edit().putStringSet("interests", new LinkedHashSet<>(selectedInterests)).apply();
            });
            interestList.addView(check, new LinearLayout.LayoutParams(-1, dp(44)));
        }
        add(interestList, 0, 10);
    }

    private void buildSettingsPage() {
        addBrandHeader();
        add(label("MAKE IT YOURS", 10, ACCENT, true), 0, 18);
        add(title("Settings", 28), 0, 6);
        add(body("Your experience, your way.", 13), 0, 22);

        add(sectionTitle("PREFERENCES"), 0, 10);
        addSettingRow("Push notifications", "Get updates about your event crews", notificationsEnabled, value -> {
            notificationsEnabled = value;
            preferences.edit().putBoolean("notifications", value).apply();
            Toast.makeText(this, value ? "Notifications enabled" : "Notifications paused", Toast.LENGTH_SHORT).show();
        });
        addSettingRow("Location", "Find events and people nearby", locationEnabled, value -> {
            locationEnabled = value;
            preferences.edit().putBoolean("location", value).apply();
            Toast.makeText(this, value ? "Nearby events enabled" : "Nearby events paused", Toast.LENGTH_SHORT).show();
        });

        add(sectionTitle("ACCOUNT"), 0, 22);
        addActionRow("Personal information", "Update your name, age, and contact", "›",
                () -> { currentTab = "Profile"; render(); });
        addActionRow("Interests & hobbies", "Choose what you’d love to do", "›",
                () -> { currentTab = "Profile"; render(); });

        add(sectionTitle("BUGS & FIXES"), 0, 22);
        addActionRow("Report a bug", "Tell us what went wrong", "↗",
                () -> showBugFixPage("Bug report"));
        addActionRow("Suggest a fix", "Share an improvement idea", "↗",
                () -> showBugFixPage("Fix suggestion"));

        add(sectionTitle("SAFETY & REPORTS"), 0, 22);
        addActionRow("Safety & reports", "Rate a completed hangout or report a concern", "›",
                () -> {
                    safetyReturnTab = "Settings";
                    safetyReturnChat = null;
                    currentTab = "Safety";
                    render();
                });

        add(sectionTitle("ABOUT"), 0, 22);
        addActionRow("Help & support", "Contact SideQuest support", "↗",
                () -> showBugFixPage("General support"));
        TextView version = body("SIDEQUEST  ·  VERSION 1.0.0", 10);
        version.setGravity(Gravity.CENTER);
        version.setLetterSpacing(0.08f);
        add(version, 0, 25);
    }

    private void showBugFixPage(String topic) {
        bugFixTopic = topic;
        currentTab = "Bugs & fixes";
        render();
    }

    private void buildBugFixPage() {
        addBrandHeader();
        TextView back = label("‹  Back to Settings", 12, ACCENT, true);
        back.setOnClickListener(v -> {
            currentTab = "Settings";
            render();
        });
        add(back, 0, 16);
        add(label("APP FEEDBACK", 10, ACCENT, true), 0, 12);
        add(title(bugFixTopic, 27), 0, 8);
        add(body("Describe the issue or improvement. We won’t attach profile or device data.", 13),
                0, 16);

        EditText details = new EditText(this);
        details.setHint("What happened, or what would you change?");
        details.setTextSize(13);
        details.setTextColor(INK);
        details.setHintTextColor(MUTED);
        details.setGravity(Gravity.TOP | Gravity.START);
        details.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        details.setMinLines(5);
        details.setMaxLines(9);
        details.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2000)});
        details.setPadding(dp(14), dp(12), dp(14), dp(12));
        details.setBackground(round(FIELD, 13));
        String draftKey = "bugfix_" + bugFixTopic;
        details.setText(draftPreferences.getString(draftKey, ""));
        saveDraftOnChange(details, draftKey);
        page.addView(details, new LinearLayout.LayoutParams(-1, dp(150)));

        String topic = bugFixTopic;
        Button sendButton = primaryButton("Send");
        add(sendButton, 0, 12);
        sendButton.setOnClickListener(v -> {
            String description = details.getText().toString().trim();
            if (description.isEmpty()) {
                Toast.makeText(this, "Add a few details first.", Toast.LENGTH_SHORT).show();
                return;
            }
            String title = emailTitle(topic);
            sendFeedback(sendButton, "SideQuest: " + title,
                    title + "\n\n" + description, () -> {
                        draftPreferences.edit().remove(draftKey).apply();
                        details.setText("");
                    });
        });
        add(body("Your message goes straight to the SideQuest team. Your text is kept on this "
                + "phone until it’s sent.", 11), 0, 18);
    }

    /** Email subject title for each feedback topic. */
    private static String emailTitle(String topic) {
        switch (topic) {
            case "Bug report": return "Bug Report";
            case "Fix suggestion": return "Fix Suggestion";
            case "General support": return "Support Request";
            default: return topic;
        }
    }

    private void saveDraftOnChange(EditText field, String key) {
        field.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(android.text.Editable s) {
                draftPreferences.edit().putString(key, s.toString()).apply();
            }
        });
    }

    private void sendFeedback(Button button, String subject, String message, Runnable onSent) {
        CharSequence label = button.getText();
        button.setEnabled(false);
        button.setText("Sending…");
        FeedbackSender.send(subject, message, (success, error) -> {
            if (isFinishing() || isDestroyed()) return;
            button.setEnabled(true);
            button.setText(label);
            if (success) {
                onSent.run();
                Toast.makeText(this, "Sent. Thank you!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void buildSafetyPage() {
        addBrandHeader();
        String backLabel = "Chat".equals(safetyReturnTab)
                ? "‹  Back to group chat"
                : "Hangout feedback".equals(safetyReturnTab)
                        ? "‹  Back to ratings" : "‹  Back to Settings";
        TextView back = label(backLabel, 12, ACCENT, true);
        back.setOnClickListener(v -> {
            if ("Chat".equals(safetyReturnTab) && safetyReturnChat != null) {
                openChat = safetyReturnChat;
                currentTab = "Chats";
            } else if ("Hangout feedback".equals(safetyReturnTab)
                    && safetyReturnChat != null) {
                feedbackChat = safetyReturnChat;
                currentTab = "Hangout feedback";
            } else {
                currentTab = "Settings";
            }
            safetyReturnTab = "Settings";
            safetyReturnChat = null;
            render();
        });
        add(back, 0, 16);
        add(label("COMMUNITY CARE", 10, ACCENT, true), 0, 12);
        add(title("Safety & reports", 27), 0, 8);
        add(body("Your comfort matters. Meet in public places, keep personal details private, and leave any situation that feels wrong.", 13), 0, 16);

        LinearLayout urgent = column();
        urgent.setPadding(dp(16), dp(14), dp(16), dp(14));
        urgent.setBackground(round(CARD, 14));
        urgent.addView(title("Immediate danger?", 14));
        TextView urgentText = body(
                "Contact local emergency services. This report form is not an emergency service.",
                12);
        urgentText.setPadding(0, dp(6), 0, 0);
        urgent.addView(urgentText);
        add(urgent, 0, 20);

        add(sectionTitle("REPORT A CONCERN"), 0, 8);
        add(body("Reports go straight to the SideQuest team. This isn’t emergency response, "
                + "and a reply time can’t be guaranteed.", 12), 0, 12);

        EditText target = inputField("Person, event, or chat",
                draftPreferences.getString("safety_target", ""));
        target.setFilters(new InputFilter[]{new InputFilter.LengthFilter(120)});
        saveDraftOnChange(target, "safety_target");
        add(target, 0, 10);

        String[] categories = {
                "Harassment or bullying",
                "Threatening behavior",
                "Inappropriate content",
                "Spam or scam",
                "Other safety concern"
        };
        Spinner category = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category.setAdapter(adapter);
        category.setSelection(Math.max(0, Arrays.asList(categories)
                .indexOf(draftPreferences.getString("safety_category", ""))));
        category.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view,
                                       int position, long id) {
                draftPreferences.edit().putString("safety_category", categories[position]).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        category.setPadding(dp(12), 0, dp(12), 0);
        category.setBackground(round(FIELD, 24));
        add(category, 0, 10);

        EditText details = new EditText(this);
        details.setHint("What happened? Include only details needed to understand the concern.");
        details.setTextSize(13);
        details.setTextColor(INK);
        details.setHintTextColor(MUTED);
        details.setGravity(Gravity.TOP | Gravity.START);
        details.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        details.setMinLines(4);
        details.setMaxLines(8);
        details.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2000)});
        details.setPadding(dp(14), dp(12), dp(14), dp(12));
        details.setBackground(round(FIELD, 13));
        details.setText(draftPreferences.getString("safety_details", ""));
        saveDraftOnChange(details, "safety_details");
        page.addView(details, new LinearLayout.LayoutParams(-1, dp(130)));
        Button reportButton = primaryButton("Send report");
        add(reportButton, 0, 12);
        reportButton.setOnClickListener(v -> {
            String reportedItem = target.getText().toString().trim();
            String description = details.getText().toString().trim();
            if (reportedItem.isEmpty() || description.isEmpty()) {
                Toast.makeText(this, "Add who or what you’re reporting and describe the concern.",
                        Toast.LENGTH_LONG).show();
                return;
            }
            String reportBody = "Safety Report\n\n"
                    + "Concern: " + category.getSelectedItem().toString() + "\n"
                    + "Person, event, or chat: " + reportedItem + "\n\n"
                    + "Details:\n" + description + "\n\n"
                    + "Please review this report.";
            sendFeedback(reportButton, "SideQuest: Safety Report", reportBody, () -> {
                draftPreferences.edit().remove("safety_target")
                        .remove("safety_category").remove("safety_details").apply();
                target.setText("");
                details.setText("");
                category.setSelection(0);
            });
        });
        add(body("The app doesn’t attach your profile or contact details. Your text is kept "
                + "on this phone until it’s sent.", 11), 0, 18);
    }

    private void showSafetyPage(String target, String returnTab, LocalChat chat) {
        draftPreferences.edit().putString("safety_target", target).apply();
        safetyReturnTab = returnTab;
        safetyReturnChat = chat;
        openChat = null;
        currentTab = "Safety";
        render();
    }

    private void buildHangoutFeedbackPage(LocalChat chat) {
        if (chat == null) {
            currentTab = "Chats";
            buildChatsPage();
            return;
        }
        addBrandHeader();
        add(label("AFTER THE HANGOUT", 10, ACCENT, true), 0, 18);
        add(title("How was your crew?", 27), 0, 8);
        add(body(chat.eventName + " · Rate each person privately on this phone.",
                13), 0, 14);
        addLocalNotice("Ratings aren’t shared with other users or used to affect matching.");

        for (String member : chat.memberNames) {
            LinearLayout card = column();
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            card.setBackground(round(PALE, 14));
            LinearLayout heading = row();
            heading.setGravity(Gravity.CENTER_VERTICAL);
            heading.addView(title(member, 15), new LinearLayout.LayoutParams(0, -2, 1f));
            TextView report = label("Report", 11, ACCENT, true);
            heading.addView(report);
            report.setOnClickListener(v -> showSafetyPage(
                    member + " · " + chat.eventName + " hangout",
                    "Hangout feedback", chat));
            card.addView(heading);

            LinearLayout stars = row();
            stars.setGravity(Gravity.CENTER_VERTICAL);
            int currentRating = chat.ratings.containsKey(member) ? chat.ratings.get(member) : 0;
            for (int value = 1; value <= 5; value++) {
                final int rating = value;
                TextView star = icon(value <= currentRating ? "★" : "☆", 27);
                star.setContentDescription("Rate " + member + " " + value + " out of 5");
                star.setPadding(dp(3), dp(4), dp(5), dp(4));
                star.setOnClickListener(v -> {
                    chat.ratings.put(member, rating);
                    persistChats();
                    feedbackChat = chat;
                    render();
                });
                stars.addView(star);
            }
            card.addView(stars);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
            cardParams.bottomMargin = dp(10);
            page.addView(card, cardParams);
        }

        if (chat.ratings.size() == chat.memberNames.size()) {
            add(body("Thanks for sharing your feedback.", 12), 0, 10);
        }
        Button done = primaryButton("Back to group chat");
        add(done, 0, 12);
        done.setOnClickListener(v -> {
            feedbackChat = null;
            openChat = chat;
            currentTab = "Chats";
            render();
        });
    }

    private interface ToggleHandler { void changed(boolean value); }

    private void addSettingRow(String title, String subtitle, boolean checked, ToggleHandler handler) {
        LinearLayout card = row();
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(15), dp(13), dp(12), dp(13));
        card.setBackground(round(PALE, 20));
        floatAbove(card, 2, ICON);
        LinearLayout text = column();
        text.addView(title(title, 14));
        TextView sub = body(subtitle, 11);
        sub.setPadding(0, dp(4), 0, 0);
        text.addView(sub);
        card.addView(text, new LinearLayout.LayoutParams(0, -2, 1f));
        CheckBox toggle = new CheckBox(this);
        toggle.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        toggle.setChecked(checked);
        toggle.setOnCheckedChangeListener((button, value) -> handler.changed(value));
        card.addView(toggle);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(9);
        page.addView(card, params);
    }

    private void addActionRow(String title, String subtitle, String action, Runnable callback) {
        LinearLayout card = row();
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(15), dp(14), dp(15), dp(14));
        card.setBackground(round(PALE, 20));
        floatAbove(card, 2, ICON);
        pressable(card);
        LinearLayout text = column();
        text.addView(title(title, 14));
        TextView sub = body(subtitle, 11);
        sub.setPadding(0, dp(4), 0, 0);
        text.addView(sub);
        card.addView(text, new LinearLayout.LayoutParams(0, -2, 1f));
        card.addView(icon(action, 19));
        card.setOnClickListener(v -> callback.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(9);
        page.addView(card, params);
    }

    private void addBrandHeader() {
        LinearLayout header = row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = label("s", 21, TEXT, true);
        mark.setGravity(Gravity.CENTER);
        mark.setTypeface(Typeface.SERIF, Typeface.BOLD);
        mark.setBackground(round(ACCENT, 10));
        header.addView(mark, new LinearLayout.LayoutParams(dp(32), dp(32)));
        TextView brand = label("sidequest", 20, INK, true);
        brand.setTypeface(Typeface.SERIF, Typeface.BOLD);
        LinearLayout.LayoutParams brandParams = new LinearLayout.LayoutParams(0, -2, 1f);
        brandParams.leftMargin = dp(9);
        header.addView(brand, brandParams);
        add(header, 0, 6);
    }

    private void addNavigation() {
        String[] names = {"Explore", "Match", "Chats", "Profile", "Settings"};
        int[] icons = {R.drawable.nav_explore, R.drawable.nav_match, R.drawable.nav_chat,
                R.drawable.nav_profile, R.drawable.nav_settings};
        for (int i = 0; i < names.length; i++) {
            final String name = names[i];
            boolean active = currentTab.equals(name);
            LinearLayout item = column();
            item.setGravity(Gravity.CENTER);
            if (active) item.setBackground(round(withAlpha(NAV_ICON, 0x2E), 26));
            pressable(item);
            android.widget.ImageView icon = new android.widget.ImageView(this);
            icon.setImageResource(icons[i]);
            icon.setImageTintList(android.content.res.ColorStateList.valueOf(NAV_ICON));
            icon.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
            icon.setAlpha(active ? 1f : 0.55f);
            icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            item.addView(icon, new LinearLayout.LayoutParams(dp(22), dp(22)));
            TextView text = label(names[i], 9, NAV_ICON, active);
            text.setAlpha(active ? 1f : 0.7f);
            text.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(-1, -2);
            textParams.topMargin = dp(3);
            item.addView(text, textParams);
            item.setOnClickListener(v -> {
                openChat = null;
                currentTab = name;
                render();
            });
            LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(0, -1, 1f);
            itemParams.setMargins(dp(2), 0, dp(2), 0);
            navigation.addView(item, itemParams);
        }
    }

    private void addRule() {
        View rule = new View(this);
        rule.setBackgroundColor(LINE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(1));
        params.bottomMargin = dp(1);
        page.addView(rule, params);
    }

    /**
     * Lifts a view off the page with a soft shadow tinted in its own colour, and lets the
     * shadow spill outside its parents instead of being cut off at their edges.
     */
    private void floatAbove(View view, int elevationDp, int shadowColor) {
        view.setElevation(dp(elevationDp));
        view.setOutlineAmbientShadowColor(shadowColor);
        view.setOutlineSpotShadowColor(shadowColor);
        view.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View v) {
                android.view.ViewParent parent = v.getParent();
                while (parent instanceof ViewGroup && parent != contentScroll) {
                    ((ViewGroup) parent).setClipChildren(false);
                    ((ViewGroup) parent).setClipToPadding(false);
                    parent = parent.getParent();
                }
            }
            @Override public void onViewDetachedFromWindow(View v) {}
        });
    }

    /** Shrinks slightly and settles down while pressed, then springs back. */
    private void pressable(View view) {
        float lift = view.getElevation();
        android.animation.StateListAnimator animator = new android.animation.StateListAnimator();
        animator.addState(new int[]{android.R.attr.state_pressed}, pressAnimation(view, 0.95f, -lift / 2));
        animator.addState(new int[]{}, pressAnimation(view, 1f, 0f));
        view.setStateListAnimator(animator);
    }

    private android.animation.Animator pressAnimation(View view, float scale, float z) {
        android.animation.AnimatorSet set = new android.animation.AnimatorSet();
        set.playTogether(
                android.animation.ObjectAnimator.ofFloat(view, "scaleX", scale),
                android.animation.ObjectAnimator.ofFloat(view, "scaleY", scale),
                android.animation.ObjectAnimator.ofFloat(view, "translationZ", z));
        set.setDuration(120);
        set.setInterpolator(new android.view.animation.DecelerateInterpolator());
        return set;
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    private EditText inputField(String hint, String value) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(13);
        input.setTextColor(INK);
        input.setHintTextColor(MUTED);
        input.setHint(hint);
        input.setText(value);
        // Same shape and height as the chat message box.
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setBackground(round(FIELD, 24));
        input.setMinHeight(dp(INPUT_HEIGHT));
        input.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(INPUT_HEIGHT)));
        return input;
    }

    private Button primaryButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(TEXT);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setBackground(round(ACCENT, 26));
        button.setStateListAnimator(null);
        floatAbove(button, 8, ACCENT);
        pressable(button);
        button.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(52)));
        return button;
    }

    private TextView chip(String text, boolean active) {
        TextView view = label(text, 11, TEXT, active);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(15), 0, dp(15), 0);
        GradientDrawable background = round(active ? ACCENT : PALE, 17);
        if (!active) background.setStroke(dp(1), LINE);
        view.setBackground(background);
        floatAbove(view, active ? 5 : 1, active ? ACCENT : ICON);
        pressable(view);
        return view;
    }

    private TextView roundControl(String text) {
        TextView view = label(text, 20, INK, true);
        view.setGravity(Gravity.CENTER);
        view.setBackground(round(PAPER, 19));
        floatAbove(view, 4, ICON);
        pressable(view);
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        return view;
    }

    private View avatar(String text, int size, int color) {
        FrameLayout tile = new FrameLayout(this);
        tile.setBackground(round(color, size / 3));
        tile.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        TextView glyph = icon(text, 22);
        glyph.setGravity(Gravity.CENTER);
        tile.addView(glyph, new FrameLayout.LayoutParams(-1, -1));
        return tile;
    }

    /** A symbol or emoji drawn in the single icon colour. */
    private TextView icon(String symbol, int size) {
        TextView view = label(symbol + TEXT_STYLE, size, ICON, true);
        view.setGravity(Gravity.CENTER);
        tintGlyphs(view, ICON);
        return view;
    }

    /**
     * Colour emojis ignore text colour, so draw the view through a colour filter that
     * keeps each glyph's shape and paints it in one colour. Only use on views without
     * a background, since the filter applies to everything the view draws.
     */
    private void tintGlyphs(View view, int color) {
        android.graphics.Paint paint = new android.graphics.Paint();
        paint.setColorFilter(new android.graphics.PorterDuffColorFilter(
                color, android.graphics.PorterDuff.Mode.SRC_IN));
        view.setLayerType(View.LAYER_TYPE_HARDWARE, paint);
    }

    private TextView sectionTitle(String text) {
        TextView view = label(text, 10, MUTED, true);
        view.setLetterSpacing(0.06f);
        return view;
    }

    private TextView title(String text, int size) {
        TextView view = label(text, size, INK, true);
        view.setTypeface(Typeface.SERIF, Typeface.BOLD);
        view.setLineSpacing(dp(2), 1f);
        return view;
    }

    private TextView body(String text, int size) {
        TextView view = label(text, size, MUTED, false);
        view.setLineSpacing(dp(2), 1f);
        return view;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private void add(View view, int topMargin, int bottomMargin) {
        boolean fixedInput = view instanceof EditText || view instanceof Spinner;
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1,
                fixedInput ? dp(INPUT_HEIGHT) : -2);
        params.topMargin = dp(topMargin);
        params.bottomMargin = dp(bottomMargin);
        page.addView(view, params);
    }

    private LinearLayout row() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        return layout;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int rgb(int red, int green, int blue) {
        return Color.rgb(red, green, blue);
    }

    private Event eventByName(String name) {
        for (Event event : events) if (event.name.equals(name)) return event;
        return events.get(0);
    }

    private static class Event {
        final String name, label, when, place, emoji, attending, category;
        final int color;

        Event(String name, String label, String when, String place, String emoji,
              int color, String attending, String category) {
            this.name = name;
            this.label = label;
            this.when = when;
            this.place = place;
            this.emoji = emoji;
            this.color = color;
            this.attending = attending;
            this.category = category;
        }
    }

    private static class LocalPerson {
        final String name;
        final String emoji;
        final List<String> interests;

        LocalPerson(String name, String emoji, String... interests) {
            this.name = name;
            this.emoji = emoji;
            this.interests = Arrays.asList(interests);
        }

        List<String> sharedInterests(Set<String> selected) {
            List<String> shared = new ArrayList<>();
            for (String interest : interests) {
                if (selected.contains(interest)) shared.add(interest);
            }
            return shared;
        }

        String sharedInterestsText(Set<String> selected) {
            List<String> shared = sharedInterests(selected);
            for (int i = 0; i < shared.size(); i++) {
                shared.set(i, shared.get(i).toLowerCase(java.util.Locale.ROOT));
            }
            return TextUtils.join(", ", shared);
        }
    }

    private static class LocalChat {
        final String id;
        final String eventName;
        final List<String> memberNames;
        final List<LocalMessage> messages = new ArrayList<>();
        final Map<String, Integer> ratings = new LinkedHashMap<>();
        boolean hangoutCompleted;

        LocalChat(String id, String eventName, List<String> memberNames) {
            this.id = id;
            this.eventName = eventName;
            this.memberNames = new ArrayList<>(memberNames);
        }

        String lastMessage() {
            return messages.isEmpty() ? "No messages yet"
                    : messages.get(messages.size() - 1).text;
        }

        String memberNamesText() {
            return memberNames.isEmpty() ? "Your event crew" : TextUtils.join(", ", memberNames);
        }
    }

    private static class LocalMessage {
        final String senderName;
        final String text;
        final boolean own;

        LocalMessage(String senderName, String text, boolean own) {
            this.senderName = senderName;
            this.text = text;
            this.own = own;
        }
    }

}
