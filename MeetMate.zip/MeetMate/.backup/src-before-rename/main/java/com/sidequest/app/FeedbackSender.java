package com.sidequest.app;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Sends feedback and safety reports straight to the team inbox through a
 * Formspree form, so the user never has to open an email app.
 *
 * The form ID is read at build time from {@code sidequest.formspreeId} in
 * local.properties and exposed as {@link BuildConfig#FORMSPREE_FORM_ID}.
 */
final class FeedbackSender {
    interface Callback {
        void done(boolean success, String error);
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private FeedbackSender() {}

    static boolean isConfigured() {
        return !BuildConfig.FORMSPREE_FORM_ID.isEmpty();
    }

    /** Sends asynchronously; the callback runs on the main thread. */
    static void send(String subject, String message, Callback callback) {
        if (!isConfigured()) {
            callback.done(false, "Sending isn’t set up in this build yet.");
            return;
        }
        new Thread(() -> {
            String error = post(subject, message);
            MAIN.post(() -> callback.done(error == null, error));
        }, "feedback-sender").start();
    }

    /** Returns null on success, or a user-facing error message. */
    private static String post(String subject, String message) {
        HttpURLConnection connection = null;
        try {
            JSONObject payload = new JSONObject();
            payload.put("_subject", subject);
            payload.put("subject", subject);
            payload.put("message", message);
            byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);

            URL url = new URL("https://formspree.io/f/" + BuildConfig.FORMSPREE_FORM_ID);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(15000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(body);
            }
            int status = connection.getResponseCode();
            if (status >= 200 && status < 300) return null;
            return "The message couldn’t be sent (error " + status + "). Your text is saved.";
        } catch (IOException | JSONException e) {
            return "No connection. Your text is saved, try again in a moment.";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
