# SideQuest Android app

## Requirements

- JDK 17
- Android SDK Platform 36

Install the SDK platform with Android Studio's SDK Manager, or set `ANDROID_HOME`
to the Android SDK directory. Keep any `local.properties` file local to your
computer; do not share a machine-specific `sdk.dir` value.

## Local group chat

The Match and Chats tabs use sample profiles and store chats on this device.
You can create a crew, send messages, leave the app, and return to the saved
conversation. Chats are not shared with other phones.

After a hangout, open its group chat and choose **Hangout finished? Rate your
crew**. Ratings are saved on this device only. Use **Report** beside a person
to raise a concern. Settings also includes **Report a bug** and **Suggest a
fix**.

The **Safety & reports** page offers basic safety guidance and a report form.
It is not an emergency service.

## Sending bug reports, fix suggestions and safety reports

Reports are sent straight from the app through a [Formspree](https://formspree.io)
form, which forwards each submission to the team inbox. No email app is needed.
Subjects are `SideQuest: Bug Report`, `SideQuest: Fix Suggestion`,
`SideQuest: Support Request`, or `SideQuest: Safety Report`. Text typed in these
forms is saved on the phone until it is sent successfully.

To enable sending:

1. Create a free Formspree form whose target email is the team inbox.
2. In the form settings, turn off reCAPTCHA (the app sends JSON, not a web page).
3. Add the form ID (the part after `formspree.io/f/`) to `local.properties`:

   ```properties
   sidequest.formspreeId=yourFormId
   ```

4. Rebuild the app. Without a form ID, the app shows "Sending isn’t set up".

## Build an APK for sharing

From this directory:

```sh
./gradlew assembleDebug
```

The installable, debug-signed APK is created at
`app/build/outputs/apk/debug/app-debug.apk`. It requires Android 16 (API 36)
or newer. Copy the APK to a compatible Android device and open it to install;
the device may ask you to allow installs from that file-sharing app. This
debug APK is for direct testing, not Google Play publishing.

The app targets API 36, as required for new Google Play apps and updates
submitted from August 31, 2026. A release upload also requires a release-signed
Android App Bundle and completion of the applicable Play Console requirements.

To install and launch directly on a connected Android device or running
emulator:

```sh
./gradlew installDebug
```
