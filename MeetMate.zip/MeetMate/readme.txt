MEETMATE — find events in Timișoara and meet people going to them
==================================================================

MeetMate is an Android app for discovering what's on in Timișoara (theatre, opera,
concerts, exhibitions, book talks, and food & drink events when they're listed) and for
finding a few people to go with. You create an account, join an event, see who else is
going, and start a group chat with the people who share your interests.

The project has two parts:
  - the Android app (folder app/), and
  - the events server (folder api-mcp-share/): it collects the events, stores who joined
    what, matches people, receives bug and safety reports, serves the app for download,
    and includes an MCP server so AI assistants (Kiro, GitHub Copilot) can search events.

Contents
  1. What's in this folder
  2. Installing the app
  3. Using the app
  4. Running the events server
  5. Where the events come from
  6. Reports by email
  7. MCP server (for AI assistants)
  8. Privacy and security
  9. Troubleshooting
 10. Building the app (developers)
 11. Known limitations


1. WHAT'S IN THIS FOLDER
------------------------

  apk/MeetMate.apk           The app, ready to install on an Android phone.
  apk/MeetMate-QR.png        (optional) QR code for a share link, see section 2, option C.
  readme.txt                 This file.
  README.md                  Shorter technical notes for developers.

  app/                       Android app source (Java, no external libraries)
    src/main/java/com/meetmate/app/
      MainActivity.java      All screens: sign-up, Explore, event page, Match, Chats,
                             Profile, Settings, reports, safety, hangout ratings.
      Event.java             One event: date, venue, category, photo, links.
      EventsApi.java         Talks to the events server.
      ImageLoader.java       Downloads, shrinks and caches event photos.
      FeedbackSender.java    Sends bug, fix, support and safety reports.
    src/main/assets/events.json   Events built into the app, used without a server.
    src/main/res/            Icons, launcher icon, network and backup settings.

  api-mcp-share/             Events server (Python)
    api.py                   REST API used by the app (also the install page).
    mcp_server.py            MCP server for AI assistants.
    event_source.py          Reads the Visit Timișoara events feed.
    philharmonic_source.py   Reads the Banatul Philharmonic concert programme.
    event_service.py         Refreshes both sources every 30 minutes.
    data_store.py            Saves events (SQLite) and people (JSON).
    report_mailer.py         Saves reports and emails them to the developer.
    import_event_addresses.py  Imports hand-checked venues, addresses, descriptions.
    make_apk_qr.py           Makes a QR code image for a download link.
    data/event_addresses.csv Venues, addresses and short descriptions, checked by hand.
    data/events.sqlite3      Cached events (refreshed automatically).
    data/users.json          People who joined events (sample profiles included).
    database/                Database schema and an SQL export of the events.
    README.md                Server details.

  icons/                     Original app icon and bottom-bar icons.
  .backup/                   Earlier versions of edited files (personal data masked).


2. INSTALLING THE APP
---------------------

Requirement: an Android phone with Android 16 or newer
(check in Settings → About phone → Android version).

OPTION A — Scan a QR code (same Wi-Fi, easiest at a demo)
  1. On the laptop with this folder, start the events server (section 4).
  2. On that laptop, open http://127.0.0.1:8000/install in a browser.
     It shows a QR code, the download link and the server address.
  3. Connect the phone to the same Wi-Fi as the laptop.
  4. Scan the QR code with the phone's camera and open the link: MeetMate.apk downloads.
  5. Open the downloaded file (notification or Files app).
  6. If Android asks, allow your browser to "install unknown apps", then tap Install.

OPTION B — Copy the file
  Get apk/MeetMate.apk onto the phone (OneDrive app, USB cable, email…), open it,
  and follow steps 5–6 above.

OPTION C — A download link that works anywhere
  1. In Finder, right-click apk/MeetMate.apk (the file, not the folder) →
     OneDrive → Share → "Anyone with the link", editing off → copy the link.
  2. Add download=1 to the end of the link (&download=1 if it already has a "?",
     otherwise ?download=1), so it downloads straight away instead of opening a preview.
     Only that one file is shared; nobody can browse the other folders.
  3. In api-mcp-share, run:  python make_apk_qr.py "PASTE-THE-LINK"
     This creates apk/MeetMate-QR.png to print or put on a slide.
  A university OneDrive may only allow links for people at the university; others
  would then have to sign in.

Good to know
  - Google Play Protect may warn about an unknown developer. This is normal for test
    apps that aren't on Google Play: tap "More details" → "Install anyway".
  - To update, install a newer MeetMate.apk over the old one. If Android says
    "App not installed", the APK was built on a different computer: uninstall first.
  - Older test versions called "SideQuest" are a different app; uninstall them.


3. USING THE APP
----------------

First launch: "Create your account"
  Name, age (16 or older), email or phone, and at least one interest. Tick the box to
  confirm you understand how sharing works. The account is saved on the phone; you can
  change it later in Profile (the same rules apply there).

  Explore   "Hello, <name>!", search, and filters (Theatre, Music, Art, Books, and Food
            when food events are listed). "Coming up" and "Live music & concerts" rows
            you swipe sideways, then all events grouped by day, with photos.
  Event     Tap an event: big photo, date and time, venue and address (tap for
            directions), description, tickets and organiser links, Share, and
            "Join this event". After joining: "Find your crew" and "Who's going".
  Match     Pick an event you joined and a group size; MeetMate suggests people going
            to the same event, ranked by shared interests. Start a group chat.
  Chats     Group chats (saved on the phone). After the hangout, rate your crew or
            report someone.
  Profile   Name, age, contact, interests. The round button with your initial (top
            right on Explore) also opens it.
  Settings  Notifications, dark mode, location, the events server address, bug reports,
            fix suggestions, safety & reports, help.

Connecting to the events server
  Settings → Timișoara events → enter the address shown on the install page (for
  example 192.168.1.20:8000) → Connect. Without a server the app shows the last event
  list it received (or the one built into the app), and Match uses sample profiles.

Navigation works like a normal Android app: the back gesture steps back through
screens, and rotating the phone or switching dark mode keeps where you are.


4. RUNNING THE EVENTS SERVER (on a laptop)
------------------------------------------

Needs Python 3.10 or newer. Keep the Python environment outside the OneDrive folder
(it contains your computer's paths). One-time setup, inside api-mcp-share:

  macOS / Linux:
      python3 -m venv ~/.cache/meetmate-api-venv
      ~/.cache/meetmate-api-venv/bin/python -m pip install -r requirements.txt

  Windows (PowerShell):
      python -m venv $HOME\.cache\meetmate-api-venv
      & $HOME\.cache\meetmate-api-venv\Scripts\python.exe -m pip install -r requirements.txt

Start it so phones on the same Wi-Fi can connect:

  macOS / Linux:
      PYTHONDONTWRITEBYTECODE=1 ~/.cache/meetmate-api-venv/bin/python -m uvicorn api:app --host 0.0.0.0 --port 8000

  Windows (PowerShell):
      $env:PYTHONDONTWRITEBYTECODE=1
      & $HOME\.cache\meetmate-api-venv\Scripts\python.exe -m uvicorn api:app --host 0.0.0.0 --port 8000

Keep the window open while people use the app. If the computer asks whether to allow
incoming connections, allow them. PYTHONDONTWRITEBYTECODE stops Python from writing
cache files (which contain your computer's paths) into the shared folder.

Useful pages while it runs
  http://127.0.0.1:8000/install   QR code and link to install the app
  http://127.0.0.1:8000/docs      Interactive API documentation

API endpoints
  GET  /events                       Upcoming events with venue, photo, links, attendee_count
  GET  /events/{id}                  One event and who joined (name and interests only)
  POST /users                        Save a profile and joined events (needs the phone's secret)
  GET  /match/people/{event}/{user}  People at the same event, ranked by shared interests
  GET  /match/events/{user}          Events ranked by a person's interests
  POST /reports                      Bug, fix, support or safety report
  GET  /install, /download/MeetMate.apk   Installing the app


5. WHERE THE EVENTS COME FROM
-----------------------------

  - Visit Timișoara (visit-timisoara.com), the city's official events feed: theatre,
    opera, exhibitions, books, and food & drink when listed. The server reads the 500
    newest listings and keeps the 30 soonest upcoming events, with their photos.
  - Banatul Philharmonic Timișoara (filarmonicabanatul.ro), its public concert
    programme: the next 60 days, up to 15 concerts, with venue, full address, photo
    and ticket link.

Both refresh automatically every 30 minutes. If a source is down, the last saved list
is used. The Visit Timișoara feed doesn't include venues, so venues, street addresses
and short descriptions are added by hand in data/event_addresses.csv (checked on the
organisers' and ticket sellers' pages) and imported with:
    python import_event_addresses.py data/event_addresses.csv
They're kept when the feed refreshes. Events announced only on Facebook may show
"Venue to be confirmed".

To refresh the event list built into the app (used without a server), see README.md,
then rebuild the app.


6. REPORTS BY EMAIL
-------------------

Bug reports, fix suggestions, support requests and safety reports written in the app
are sent to the events server, which saves them in data/reports.jsonl and emails them
to the developer, with subjects such as "MeetMate: Bug Report".

Email settings are environment variables, set when starting the server (never stored
in the folder or the app). With Gmail: turn on 2-step verification, create an app
password at https://myaccount.google.com/apppasswords, then:

    export MEETMATE_REPORT_TO="where reports should arrive"
    export MEETMATE_SMTP_USER="sending.account@gmail.com"
    export MEETMATE_SMTP_PASSWORD="the 16-letter app password"

(Other providers: also MEETMATE_SMTP_HOST and MEETMATE_SMTP_PORT.) Without these,
reports are only saved to data/reports.jsonl. Limits: 5 reports per device every
10 minutes, 200 a day in total.


7. MCP SERVER (for AI assistants)
---------------------------------

mcp_server.py is an MCP server called "meetmate-events" with four tools:
search_events, get_event_attendees, recommend_matches_for_user (read-only) and
add_new_event (adds an event; use a tag like "food-drink" to list it under Food).

Kiro (macOS/Linux): add this to .kiro/settings/mcp.json in the project, or to your own
~/.kiro/settings/mcp.json. It assumes the Python environment from section 4:

  {
    "mcpServers": {
      "meetmate-events": {
        "command": "sh",
        "args": ["-c", "cd api-mcp-share && exec \"$HOME/.cache/meetmate-api-venv/bin/python\" mcp_server.py"],
        "env": { "PYTHONDONTWRITEBYTECODE": "1" },
        "autoApprove": ["search_events", "get_event_attendees", "recommend_matches_for_user"]
      }
    }
  }

VS Code (GitHub Copilot) on Windows: api-mcp-share/.vscode/mcp.json, using a .venv
inside api-mcp-share.


8. PRIVACY AND SECURITY
-----------------------

What leaves the phone
  - When you join an event: a random ID, a random secret, your name, your interests
    and the events you joined. Other people going see only your name and interests.
  - Reports: the text you write, without your profile or contact details.
  - Your age, email and phone number never leave the phone.
  - App data is excluded from cloud backups and device-to-device transfer.

Server protections
  - Each phone's random secret is required to change its profile (only a hash is
    stored), so nobody can take over someone else's profile.
  - Limits: 30 profile updates per device every 10 minutes, at most 2000 people;
    report limits as in section 6. Oversized or malformed input is rejected.
  - Websites can't call the server from a browser (no cross-site access).
  - The app opens only http/https links, accepts only https photos, and rejects
    oversized or malformed data from the server.

Be aware
  - The server has no login and uses plain HTTP on the local network: people on the
    same Wi-Fi could read what the app sends. Use a trusted network (or a phone
    hotspot) for demos. For the internet, run the server behind HTTPS.
  - The shared APK is a debug build: someone with USB access to an unlocked phone
    could read the app's data.

Shared folder hygiene
  This folder is shared through OneDrive. After every app build, a step called
  maskPersonalData masks computer paths, user names and email addresses in build
  output, .backup/ and Python cache folders.


9. TROUBLESHOOTING
------------------

  "App not installed" / nothing happens
      Android 15 or older (MeetMate needs Android 16), or an older MeetMate built on
      another computer is installed: uninstall it first.

  The QR code link doesn't open
      Phone and laptop must be on the same Wi-Fi, and the server must be started with
      --host 0.0.0.0. University and guest Wi-Fi often block devices from reaching each
      other; use a phone hotspot instead.

  "Can't reach the events server"
      Check the address in Settings (the laptop's Wi-Fi address and :8000), that the
      server window is still open, and the Wi-Fi.

  "The events server answered with error 403" when joining
      The server already has this profile ID with a different secret (for example the
      server's data was copied from another phone). Clearing the app's data creates a
      new account with a new ID.

  No photos
      Photos load from the organisers' websites, so the phone needs internet the first
      time; after that they're saved on the phone.

  Show the sign-up screen again (for a demo)
      Android Settings → Apps → MeetMate → Storage → Clear storage, or reinstall.


10. BUILDING THE APP (developers)
---------------------------------

Needs JDK 17 and the Android SDK (platform 36). From this folder:

    ./gradlew --project-cache-dir ~/.cache/meetmate-gradle assembleDebug

The new APK is copied to apk/MeetMate.apk, then personal data is masked in the build
output. Keeping Gradle's cache outside the folder (the --project-cache-dir part)
stops your computer's paths from being shared. Optional settings go in
local.properties (OneDrive syncs it too, so put no passwords or personal data there):
    meetmate.eventsServer=http://192.168.1.20:8000   default server address in the app
    meetmate.formspreeId=yourFormId                  send reports through Formspree instead


11. KNOWN LIMITATIONS
---------------------

  - Group chats are saved on each phone only; the people you match with don't receive
    your messages.
  - Accounts live on the phone; there's no password or login across phones.
  - Food & drink events appear only when Visit Timișoara lists upcoming ones.
  - Some events have no venue yet (announced only on Facebook).
  - The events server must run on a laptop on the same network as the phones.

12.DEVELOPERS
---------------------

Ursein Andrei Cătălin
Pele Mihnea Alexandru 
Schiopu Raul Ștefan