# Build rule

After every code change, rebuild the debug APK:

```sh
./gradlew --project-cache-dir ~/.cache/meetmate-gradle assembleDebug
```

The shareable APK is copied to `apk/MeetMate.apk`. Tell the user the build time.

This folder is shared with the team through OneDrive and everything stays in it.
Never write machine-specific paths, user names, or personal data into project files.
The `maskPersonalData` task masks paths and emails in build output and `.backup/`
after each build; check with a scan that nothing personal remains after changes.
