# MeetMate Android app

## Requirements

- JDK 17
- Android SDK Platform 36

Install the SDK platform with Android Studio's SDK Manager, or set `ANDROID_HOME`
to the Android SDK directory. Keep any `local.properties` file local to your
computer; do not share a machine-specific `sdk.dir` value.

## Timișoara events

**Explore** lists upcoming events in Timișoara from Visit Timișoara, with the venue,
street address, tickets and event links where known. Tap an event to see its details,
get directions, share it, or **Join** it. **Match** then finds a few people who joined
the same event, ranked by shared interests.

Live events and the people going come from the MeetMate events server in
`api-mcp-share` (see its README for how to run it). In the app, open
**Settings → Timișoara events**, enter the address of the computer running the server
(for example `192.168.1.20:8000`) and tap **Connect**. Without a server the app shows
the last list it received, or the list bundled in `app/src/main/assets/events.json`,
and Match uses sample profiles on the phone.

Joining shares only the display name, interests and joined events with the server and
with people going to the same events; age, email and phone number stay on the phone.

To refresh the bundled list, run this from `api-mcp-share` and rebuild:

```sh
PYTHONDONTWRITEBYTECODE=1 ~/.cache/meetmate-api-venv/bin/python -c "import json; from data_store import read_events; keep=['id','title','description','date','location','address','tags','source_url','ticket_url']; print(json.dumps([{k: e[k] for k in keep} for e in read_events()], ensure_ascii=False, indent=1))" > ../app/src/main/assets/events.json
```

## Group chat

Chats are stored on this device. You can create a crew, send messages, leave the
app, and return to the saved conversation. Chats are not shared with other phones.

After a hangout, open its group chat and choose **Hangout finished? Rate your
crew**. Ratings are saved on this device only. Use **Report** beside a person
to raise a concern. Settings also includes **Report a bug** and **Suggest a
fix**.

**Settings → Dark mode** switches the app between light and dark colours. Until
it is changed, the app follows the phone's own dark mode setting.

The **Safety & reports** page offers basic safety guidance and a report form.
It is not an emergency service.

## Sending bug reports, fix suggestions and safety reports

Reports are sent straight from the app to the developer's email; no email app is
needed. Subjects are `MeetMate: Bug Report`, `MeetMate: Fix Suggestion`,
`MeetMate: Support Request`, or `MeetMate: Safety Report`. Text typed in these
forms is saved on the phone until it is sent successfully.

By default the app sends reports to the MeetMate events server it is connected to
(Settings → Timișoara events), which saves and emails them. See
"Reports sent by email" in `api-mcp-share/README.md` to set the developer address.

Alternatively, reports can go through a [Formspree](https://formspree.io) form, which
works without the events server. To use it instead:

1. Create a free Formspree form whose target email is the team inbox.
2. In the form settings, turn off reCAPTCHA (the app sends JSON, not a web page).
3. Add the form ID (the part after `formspree.io/f/`) to `local.properties`:

   ```properties
   meetmate.formspreeId=yourFormId
   ```

4. Rebuild the app. Without a form ID, the app shows "Sending isn’t set up".

## Build an APK for sharing

From this directory:

```sh
./gradlew assembleDebug
```

The installable, debug-signed APK is created at
`app/build/outputs/apk/debug/app-debug.apk` and copied to `apk/MeetMate.apk`.

This folder is shared through OneDrive, build output included. After every build,
the `maskPersonalData` task masks personal data in `build/`, `app/build/` and
`.backup/` and any `__pycache__` folder: the build computer's folder paths become
`[project]` and `~`, user names in other computers' paths become asterisks, and email
addresses keep only their first letter and domain. Gradle's own cache can't be
masked safely, so build with it outside the shared folder:

```sh
./gradlew --project-cache-dir ~/.cache/meetmate-gradle assembleDebug
```

The APK requires Android 16 (API 36) or newer. Copy the APK to a compatible Android device and open it to install;
the device may ask you to allow installs from that file-sharing app. This
debug APK is for direct testing, not Google Play publishing.

The app targets API 36, as required for new Google Play apps and updates
submitted from August 31, 2026. A release upload also requires a release-signed
Android App Bundle and completion of the applicable Play Console requirements.

To install and launch directly on a connected Android device or running
emulator:

```sh
./gradlew installDebug
```
